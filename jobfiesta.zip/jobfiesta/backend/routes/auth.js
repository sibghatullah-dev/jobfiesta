const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { authenticate } = require('../middleware/auth');

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log('Login attempt:', { email, password });
    const user = await User.findOne({ email });
    if (!user) {
      console.log('User not found:', email);
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    console.log('User found:', { email: user.email, userType: user.userType });
    const passwordMatch = await bcrypt.compare(password, user.password);
    console.log('Password match:', passwordMatch);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const token = jwt.sign(
      { userId: user._id, userType: user.userType },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );
    res.json({ token, userType: user.userType, userId: user._id });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/register/jobseeker', async (req, res) => {
  try {
    const {
      email,
      password,
      name,
      skills,
      experience,
      jobTitle,
      location,
      jobType,
      desiredSalaryRange,
      preferredIndustry,
      education,
      gender,
      city,
      languages,
      institution,
      completionYear,
      address,
      experienceLevel,
      goals,
    } = req.body;
    if (await User.findOne({ email })) {
      return res.status(400).json({ message: 'Email already exists' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      email,
      password: hashedPassword,
      name,
      userType: 'jobseeker',
      skills,
      experience,
      jobTitle,
      location,
      jobType,
      desiredSalaryRange,
      preferredIndustry,
      education,
      gender,
      city,
      languages,
      institution,
      completionYear,
      address,
      experienceLevel,
      goals,
    });
    await user.save();
    res.status(201).json({ message: 'Job seeker registered successfully' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/register/recruiter', async (req, res) => {
  try {
    const { email, password, name, companyName, companyDetails } = req.body;
    if (await User.findOne({ email })) {
      return res.status(400).json({ message: 'Email already exists' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      email,
      password: hashedPassword,
      name,
      userType: 'recruiter',
      companyName,
      companyDetails,
    });
    await user.save();
    res.status(201).json({ message: 'Recruiter registered successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/me', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;