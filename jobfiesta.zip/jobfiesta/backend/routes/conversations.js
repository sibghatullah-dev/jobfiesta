const express = require('express');
  const router = express.Router();
  const Conversation = require('../models/Conversation');
  const Message = require('../models/Message');
  const { authenticate } = require('../middleware/auth');

  // Create or Get Conversation
  router.post('/', authenticate, async (req, res) => {
    try {
      const { participantId } = req.body;
      let conversation = await Conversation.findOne({
        participants: { $all: [req.user.userId, participantId] }
      });
      if (!conversation) {
        conversation = new Conversation({
          participants: [req.user.userId, participantId]
        });
        await conversation.save();
      }
      res.json(conversation);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Get User Conversations
  router.get('/', authenticate, async (req, res) => {
    try {
      const conversations = await Conversation.find({
        participants: req.user.userId
      })
        .populate('participants', 'name userType')
        .populate('lastMessage', 'content timestamp');
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Get Messages in a Conversation
  router.get('/:id/messages', authenticate, async (req, res) => {
    try {
      const conversation = await Conversation.findById(req.params.id);
      if (!conversation || !conversation.participants.includes(req.user.userId)) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const messages = await Message.find({ conversationId: req.params.id })
        .populate('senderId', 'name');
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  module.exports = router;