const express = require('express');
const router = express.Router();
const Job = require('../models/Job');
const User = require('../models/User');
const { authenticate, restrictTo } = require('../middleware/auth');

// Get Job Recommendations (Job Seeker only)
router.get('/jobs', authenticate, restrictTo('jobseeker'), async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    const jobs = await Job.find({ skillsRequired: { $in: user.skills } })
      .populate('postedBy', 'companyName');
    // Simple match score based on skill overlap
    const recommendations = jobs.map(job => ({
      ...job._doc,
      matchScore: job.skillsRequired.filter(skill => user.skills.includes(skill)).length / job.skillsRequired.length
    })).sort((a, b) => b.matchScore - a.matchScore);
    res.json(recommendations);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get Candidate Recommendations (Recruiter only)
router.get('/candidates/:jobId', authenticate, restrictTo('recruiter'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.jobId); // <-- FIXED HERE
    if (!job || job.postedBy.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }

    const candidates = await User.find({
      userType: 'jobseeker',
      skills: { $in: job.skillsRequired }
    });

    const recommendations = candidates.map(candidate => ({
      ...candidate._doc,
      matchScore: job.skillsRequired.filter(skill => candidate.skills.includes(skill)).length / job.skillsRequired.length
    })).sort((a, b) => b.matchScore - a.matchScore);

    res.json(recommendations);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


module.exports = router;