const express = require('express');
  const router = express.Router();
  const resumeController = require('../controllers/resumeController');
  const { authenticate } = require('../middleware/auth');

  // Generate resume PDF (authenticated)
  router.post('/generate', authenticate, resumeController.generateResume);

  // Get all resumes (authenticated)
  router.get('/', authenticate, resumeController.getAllResumes);

  // Get single resume (authenticated)
  router.get('/:id', authenticate, resumeController.getResume);

  // Enhance profile (authenticated)
  router.post('/enhance-profile', authenticate, resumeController.enhanceProfile);

  module.exports = router;