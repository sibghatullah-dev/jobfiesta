import React, { createContext, useState, useEffect, useContext } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);

  useEffect(() => {
    console.log('AuthProvider mounted');
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
      axios.get('/api/auth/me', {
        headers: { Authorization: `Bearer ${storedToken}` }
      }).then(res => setUser(res.data))
        .catch(() => {
          localStorage.removeItem('token');
          setToken(null);
        });
    }
  }, []);

  const login = async (email, password) => {
    try {
      console.log('Sending login request:', { email, password });
      const res = await axios.post('/api/auth/login', { email, password });
      console.log('Login response:', res.data);
      setToken(res.data.token);
      setUser(res.data);
      localStorage.setItem('token', res.data.token);
      return { success: true };
    } catch (error) {
      console.error('Login error:', error.response ? error.response.data : error.message);
      return { success: false, message: error.response?.data?.message || 'Server error' };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
      <div style={{ color: 'green' }}>AuthProvider is active</div>
    </AuthContext.Provider>
  );
};