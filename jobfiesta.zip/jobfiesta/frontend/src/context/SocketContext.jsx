import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
  import io from 'socket.io-client';

  const SocketContext = createContext();

  export const useSocket = () => useContext(SocketContext);

  export const SocketProvider = ({ children, userId }) => {
    const [socket, setSocket] = useState(null);
    const userIdRef = useRef(userId);

    useEffect(() => {
      console.log('SocketProvider mounted with userId:', userId);
      if (userId && userId !== userIdRef.current) {
        userIdRef.current = userId;
        if (socket) socket.disconnect();
        const newSocket = io(import.meta.env.VITE_API_URL || 'http://localhost:5000', {
          query: { userId }
        });
        setSocket(newSocket);
      }
      return () => {
        if (socket) socket.disconnect();
      };
    }, [userId, socket]);

    return (
      <SocketContext.Provider value={socket}>
        {children}
        <div style={{ color: 'blue' }}>SocketProvider is active</div>
      </SocketContext.Provider>
    );
  };