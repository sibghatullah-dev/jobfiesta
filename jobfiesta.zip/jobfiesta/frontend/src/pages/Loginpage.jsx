import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import PasswordInput from "./components/PasswordField";
import { Link } from 'react-router-dom';
const Loginpage = () => {
  const [email, setEmail] = useState("alice.jobseeker@example.com");
  const [password, setPassword] = useState("Password123");
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleLogin = async () => {
    console.log('Login inputs:', { email, password }); // Debug input values
    setError(null);
    const result = await login(email, password);
    if (result.success) {
      const userType = localStorage.getItem("userType");
      if (userType === "jobseeker") {
        navigate("/jobseeker-dashboard");
      } else if (userType === "recruiter") {
        navigate("/recruiter-dashboard");
      }
    } else {
      setError(result.message);
    }
  };

  return (
    <>
      <div
        id="_3327_3632__Login_page"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          height: "1320.0px",
          width: "100%",
        }}
      >
        {error && (
          <div
            style={{
              color: "red",
              marginBottom: "10px",
              position: "absolute",
              left: "124.03px",
              top: "720px",
            }}
          >
            {error}
          </div>
        )}
        <span
          id="_3327_3652__Login_to_your_Accoun"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "497.00px",
            position: "absolute",
            left: "calc(50% - 621.00px)",
            top: "128.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Login to your Account
          </span>
        </span>
        <span
          id="_3327_3653__Welcome_back__Select"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "22.00px",
            width: "527.00px",
            position: "absolute",
            left: "calc(50% - 621.00px)",
            top: "193.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            Welcome back! Select the below login methods.
          </span>
        </span>
        <div
          id="_3327_3655__Rectangle_3"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "40px",
            boxShadow: "0.0px 10.0px 40.0px 0.0px rgba(0, 0, 0, 0.15)",
            height: "1020.09px",
            width: "1313.80px",
            left: "calc(50% - 657.00px)",
            top: "234.00px",
          }}
        ></div>
        <div
          id="_3327_3658__Frame_16"
          style={{
            position: "absolute",
            height: "24.00px",
            width: "381.73px",
            left: "216.00px",
            top: "1154.61px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "8px",
          }}
        >
          <span
            id="_3327_3659__Don_t_have_an_accoun"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "277.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(19, 114, 178, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "23.289939880371094px",
                fontWeight: "400",
                lineHeight: "23.29px",
              }}
            >
              Don’t have an account?
            </span>
          </span>
          <span
            id="_3327_3660__Register"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "96.00px",
              position: "relative",
            }}
          >
          <Link
            to="/register-jobseeker"
            style={{
              whiteSpace: "nowrap",
              background: "rgba(17, 17, 17, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "23.29px",
              fontWeight: "500",
              lineHeight: "23.29px",
              textDecoration: "underline",
              cursor: "pointer", // shows pointer on hover
            }}
          >
            Register
          </Link>
          </span>
        </div>
        <button
          id="_3327_3661__Frame_6"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "8px",
            height: "24.58px",
            width: "173.59px",
            left: "124.03px",
            top: "745.49px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "14px",
            padding: "23px 216px",
          }}
          onClick={handleLogin}
        >
          <span
            id="_3327_3662__Login"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "center",
              height: "24.00px",
              width: "65.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "23.289939880371094px",
                fontWeight: "700",
                lineHeight: "23.29px",
              }}
            >
              Login
            </span>
          </span>
        </button>
        <span
          id="_3327_3664__Email_ID___Username"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "28.40px",
            width: "269.37px",
            position: "absolute",
            left: "124.03px",
            top: "310.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(19, 114, 178, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "500",
              lineHeight: "24.00px",
            }}
          >
            Email ID / Username
          </span>
        </span>
        <div
          id="_3327_3665__Frame_29"
          style={{
            position: "absolute",
            borderColor: "#acb2b972",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "8px",
            height: "31.24px",
            width: "545.59px",
            left: "calc(50% - 595.97px)",
            top: "354.79px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "21px",
            padding: "23px 29px",
          }}
        >
          <input
            type="email"
            placeholder="Enter email id / username"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "20px",
              fontWeight: "400",
              lineHeight: "20px",
              color: "#121224",
              width: "100%",
              backgroundColor: "transparent",
            }}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div
          id="_3327_3667__Frame_12"
          style={{
            position: "absolute",
            height: "102.73px",
            width: "606.00px",
            left: "calc(50% - 596.00px)",
            top: "499.63px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "8px",
          }}
        >
          <span
            id="_3327_3668__Password"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "117.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(19, 114, 178, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Password
            </span>
          </span>
          <PasswordInput onChange={(value) => setPassword(value)} />
        </div>
        <span
          id="_3327_3672__Forgot_Password_"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "center",
            height: "21.30px",
            width: "168.60px",
            position: "absolute",
            left: "560.87px",
            top: "655.55px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(17, 17, 17, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "17.46745491027832px",
              fontWeight: "400",
              lineHeight: "17.47px",
              textDecoration: "underline",
            }}
          >
            Forgot Password?
          </span>
        </span>
        <span
          id="_3327_3673__Remember_me"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "23.67px",
            width: "164.23px",
            position: "absolute",
            left: "calc(50% - 569.69px)",
            top: "654.37px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "400",
              lineHeight: "20.00px",
            }}
          >
            Remember me
          </span>
        </span>
        <span
          id="_3327_3675__or_login_with"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "26.03px",
            width: "159.85px",
            position: "absolute",
            left: "calc(50% - 373.46px)",
            top: "900.52px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            or login with
          </span>
        </span>
        <img
          id="_3327_3676__Line_3"
          src="assets/loginpageimages/line_3.svg"
          alt="Line_3"
          style={{
            position: "absolute",
            transform: "scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "329.38px",
            top: "913.54px",
          }}
        />
        <img
          id="_3327_3677__Line_4"
          src="assets/loginpageimages/line_4.svg"
          alt="Line_4"
          style={{
            position: "absolute",
            transform: "scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "729.48px",
            top: "913.54px",
          }}
        />
        <img
          id="_3327_3678__Vector"
          src="assets/loginpageimages/vector.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.09)",
            top: "calc(100% * 0.50)",
          }}
        />
        <img
          id="_3327_3684__Group_14068"
          src="assets/loginpageimages/group_14068.svg"
          alt="Group_14068"
          style={{
            position: "absolute",
            left: "calc(100% * 0.27)",
            top: "calc(100% * 0.74)",
          }}
        />
        <div
          id="_3328_4727__Sign_In"
          style={{
            position: "absolute",
            height: "549.00px",
            width: "445.00px",
            left: "868.00px",
            top: "562.00px",
          }}
        >
          <div
            id="I3328_4727_11_3666__Sign_In_1"
            style={{
              position: "absolute",
              overflow: "hidden",
              height: "375.00px",
              width: "375.00px",
              left: "0.00px",
              top: "0.00px",
            }}
          >
            <img
              id="I3328_4727_11_3668__Blob"
              src="assets/loginpageimages/blob.svg"
              alt="Blob"
              style={{
                position: "absolute",
                left: "calc(100% * 0.13)",
                top: "calc(100% * 0.13)",
              }}
            />
            <img
              id="I3328_4727_11_3669__Path"
              src="assets/loginpageimages/path.svg"
              alt="Path"
              style={{
                position: "absolute",
                left: "calc(100% * 0.58)",
                top: "calc(100% * 0.21)",
              }}
            />
            <img
              id="I3328_4727_11_3670__Path"
              src="assets/loginpageimages/path_1.svg"
              alt="Path"
              style={{
                position: "absolute",
                left: "calc(100% * 0.31)",
                top: "calc(100% * 0.17)",
              }}
            />
            <img
              id="I3328_4727_11_3671__Path"
              src="assets/loginpageimages/path_2.svg"
              alt="Path"
              style={{
                position: "absolute",
                left: "calc(100% * 0.18)",
                top: "calc(100% * 0.12)",
              }}
            />
            <img
              id="I3328_4727_11_3672__Path_169"
              src="assets/loginpageimages/path_169.svg"
              alt="Path_169"
              style={{
                position: "absolute",
                left: "calc(100% * 0.44)",
                top: "calc(100% * 0.58)",
              }}
            />
            <img
              id="I3328_4727_11_3673__Path_168"
              src="assets/loginpageimages/path_168.svg"
              alt="Path_168"
              style={{
                position: "absolute",
                left: "calc(100% * 0.58)",
                top: "calc(100% * 0.49)",
              }}
            />
            <img
              id="I3328_4727_11_3674__Path"
              src="assets/loginpageimages/path_3.svg"
              alt="Path"
              style={{
                position: "absolute",
                left: "calc(100% * 0.64)",
                top: "calc(100% * 0.63)",
              }}
            />
            <img
              id="I3328_4727_11_3675__Oval"
              src="assets/loginpageimages/oval.svg"
              alt="Oval"
              style={{
                position: "absolute",
                left: "calc(100% * 0.47)",
                top: "calc(100% * 0.50)",
              }}
            />
            <img
              id="I3328_4727_11_3676__Oval"
              src="assets/loginpageimages/oval_1.svg"
              alt="Oval"
              style={{
                position: "absolute",
                left: "calc(100% * 0.55)",
                top: "calc(100% * 0.51)",
              }}
            />
            <img
              id="I3328_4727_11_3677__Group"
              src="assets/loginpageimages/group.svg"
              alt="Group"
              style={{
                position: "absolute",
                left: "calc(100% * 0.13)",
                top: "calc(100% * 0.12)",
              }}
            />
          </div>
        </div>
        <span
          id="_3378_2717__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "48.00px",
            width: "80.00px",
            position: "absolute",
            left: "1054.00px",
            top: "141.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job
          </span>
        </span>
        <span
          id="_3378_2718__Fiesta"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "61.00px",
            width: "266.00px",
            position: "absolute",
            left: "1060.00px",
            top: "128.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "40.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>
      </div>
    </>
  );
};

export default Loginpage;