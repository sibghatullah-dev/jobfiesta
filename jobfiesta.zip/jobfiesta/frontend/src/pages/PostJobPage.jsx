import React from "react";

const PostJobPage = () => {
  return (
    <>
      <div
        id="_3345_7652__Post_Job_Page"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          borderRadius: "15px",
          height: "2289.0px",
          width: "100%",
        }}
      >
        <span
          id="_3327_3147__Post_a_job"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "222.00px",
            position: "absolute",
            left: "calc(50% - 600.00px)",
            top: "154.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Post a job
          </span>
        </span>
        <span
          id="_3327_3148__Find_the_best_talent"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "22.00px",
            width: "413.00px",
            position: "absolute",
            left: "calc(50% - 600.00px)",
            top: "219.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            Find the best talent for your company
          </span>
        </span>

        <div
          id="_3378_2585__Rectangle_4"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "40px",
            boxShadow: "0.0px 10.0px 40.0px 0.0px rgba(0, 0, 0, 0.15)",
            height: "1951.00px",
            width: "1267.00px",
            left: "calc(50% - 634.00px)",
            top: "289.00px",
          }}
        ></div>

        <div
          id="_3327_3216__Button__Post_"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "82.00px",
            width: "320.00px",
            left: "814.00px",
            top: "2040.00px",
          }}
        >
          <span
            id="_3327_3217__Post_Job"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "46.00px",
              width: "144.00px",
              position: "absolute",
              left: "calc(50% - 72.00px)",
              top: "22.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "33.74409866333008px",
                fontWeight: "700",
                lineHeight: "45.29px",
              }}
            >
              Post Job
            </span>
          </span>
        </div>

        <div
          id="_3347_7631__Button__submitbtn_"
          style={{
            position: "absolute",
            background: "rgba(233, 25, 29, 1.00)",
            borderRadius: "15px",
            height: "82.00px",
            width: "320.00px",
            left: "236.00px",
            top: "2040.00px",
          }}
        >
          <span
            id="_3347_7632__Cancel"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "41.00px",
              width: "104.00px",
              position: "absolute",
              left: "calc(50% - 52.00px)",
              top: "20.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "30.45404624938965px",
                fontWeight: "700",
                lineHeight: "40.88px",
              }}
            >
              Cancel
            </span>
          </span>
        </div>

        <div
          id="_3347_7634__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "396.00px",
          }}
        >
          <span
            id="_3347_7635__Job_Title"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "100.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Job Title
            </span>
          </span>
        </div>

        <div
          id="_3347_7637__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "781.00px",
            top: "395.00px",
          }}
        >
          <span
            id="_3347_7638__Type_of_Role"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "145.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Type of Role
            </span>
          </span>
        </div>

        <div
          id="_3347_7640__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "538.00px",
          }}
        >
          <span
            id="_3347_7641__Company_Name"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "200.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Company Name
            </span>
          </span>
        </div>

        <div
          id="_3347_7643__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "790.00px",
            top: "538.00px",
          }}
        >
          <span
            id="_3347_7644__location"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "98.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              location
            </span>
          </span>
        </div>

        <div
          id="_3347_7646__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "685.00px",
          }}
        >
          <span
            id="_3347_7647__Desired_Salary_Range"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "256.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Desired Salary Range
            </span>
          </span>
          <div
            id="_3363_5282__d61036a8-af03-49af-8"
            style={{
              position: "absolute",
              background:
                "url(assets/jobpostimages/d61036a8af0349af80a17424d4136dba_3.png) 100% / cover no-repeat",
              height: "52.00px",
              width: "87.00px",
              left: "305.00px",
              top: "12.00px",
            }}
          ></div>
        </div>

        <div
          id="_3347_7649__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "832.00px",
          }}
        >
          <span
            id="_3347_7650__Work_Environment"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "217.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Work Environment
            </span>
          </span>
        </div>

        <div
          id="_3347_7652__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "166.00px",
            top: "974.00px",
          }}
        >
          <span
            id="_3347_7653__Job_Application_Proc"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "293.00px",
              position: "absolute",
              left: "32.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Job Application Process
            </span>
          </span>
        </div>

        <span
          id="_3353_5692__Job_Experience_Level"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            height: "24.00px",
            width: "253.00px",
            position: "absolute",
            left: "187.00px",
            top: "1287.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(18, 18, 36, 0.50)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "400",
              lineHeight: "24.00px",
            }}
          >
            Job Experience Level
          </span>
        </span>
        <div
          id="_3347_7658__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "1121.00px",
          }}
        >
          <span
            id="_3347_7659__Marital_Status"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "165.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Marital Status
            </span>
          </span>
        </div>

        <div
          id="_3347_7661__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "781.00px",
            top: "1124.00px",
          }}
        >
          <span
            id="_3347_7662__Required_Gender"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "203.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Required Gender
            </span>
          </span>
        </div>

        <div
          id="_3347_7664__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "790.00px",
            top: "676.00px",
          }}
        >
          <span
            id="_3347_7665__Job_Type"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "109.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Job Type
            </span>
          </span>
        </div>

        <div
          id="_3347_7667__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "790.00px",
            top: "835.00px",
          }}
        >
          <span
            id="_3347_7668__Job_Benefits"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "146.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Job Benefits
            </span>
          </span>
        </div>

        <div
          id="_3347_7670__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "781.00px",
            top: "974.00px",
          }}
        >
          <span
            id="_3347_7671__Application_Deadline"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "250.00px",
              position: "absolute",
              left: "17.00px",
              top: "26.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Application Deadline
            </span>
          </span>
          <div
            id="_3353_5053__85616160-3bae-4f2b-9"
            style={{
              position: "absolute",
              background:
                "url(assets/jobpostimages/856161603bae4f2b95c783ce8ddc15db_1.png) 100% / cover no-repeat",
              height: "58.00px",
              width: "65.00px",
              left: "306.00px",
              top: "9.00px",
            }}
          ></div>
        </div>

        <div
          id="_3353_5693__Div__formField_"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "299.00px",
            width: "512.00px",
            left: "170.00px",
            top: "1478.00px",
          }}
        >
          <span
            id="_3353_5695__Terms_and_Conditions"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "280.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(240, 65, 65, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Terms and Conditions*
            </span>
          </span>

          <div
            id="_3353_5696__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "88.91px",
              width: "472.91px",
              left: "0.00px",
              top: "59.00px",
            }}
          >
            <span
              id="_3353_5697__Conditions1"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                height: "24.00px",
                width: "137.00px",
                position: "absolute",
                left: "17.00px",
                top: "26.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(18, 18, 36, 0.50)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "400",
                  lineHeight: "24.00px",
                }}
              >
                Conditions1
              </span>
            </span>
          </div>

          <div
            id="_3353_5701__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "88.91px",
              width: "472.91px",
              left: "0.00px",
              top: "164.00px",
            }}
          >
            <span
              id="_3353_5702__Conditions2"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                height: "24.00px",
                width: "144.00px",
                position: "absolute",
                left: "17.00px",
                top: "26.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(18, 18, 36, 0.50)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "400",
                  lineHeight: "24.00px",
                }}
              >
                Conditions2
              </span>
            </span>
          </div>
        </div>

        <div
          id="_3347_8589__Div__formField_"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "355.00px",
            width: "477.00px",
            left: "781.00px",
            top: "1323.00px",
          }}
        >
          <span
            id="_3347_8591__Skills_Required__"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "193.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(240, 65, 65, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Skills Required *
            </span>
          </span>

          <div
            id="_3347_8592__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "88.91px",
              width: "472.91px",
              left: "0.00px",
              top: "59.00px",
            }}
          >
            <span
              id="_3347_8593__Skill1"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                height: "24.00px",
                width: "52.00px",
                position: "absolute",
                left: "17.00px",
                top: "26.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(18, 18, 36, 0.50)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "400",
                  lineHeight: "24.00px",
                }}
              >
                Skill1
              </span>
            </span>
          </div>

          <div
            id="_3347_8594__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "88.91px",
              width: "472.91px",
              left: "0.00px",
              top: "164.00px",
            }}
          >
            <span
              id="_3347_8595__SKill2"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                height: "24.00px",
                width: "60.00px",
                position: "absolute",
                left: "17.00px",
                top: "26.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(18, 18, 36, 0.50)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "400",
                  lineHeight: "24.00px",
                }}
              >
                SKill2
              </span>
            </span>
          </div>

          <span
            id="_3378_2587__Skill__"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "71.00px",
              position: "absolute",
              left: "17.00px",
              top: "287.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(0, 0, 0, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Skill +
            </span>
          </span>
        </div>

        <div
          id="_3353_5706__Div__formInput_"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "177.00px",
            width: "1083.00px",
            left: "135.00px",
            top: "1823.00px",
          }}
        >
          <div
            id="_3353_5707__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "89.91px",
              width: "1078.91px",
              left: "0.00px",
              top: "45.39px",
            }}
          ></div>

          <span
            id="_3353_5708__Job_Description_"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "201.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span>
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(48, 48, 48, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "500",
                  lineHeight: "24.00px",
                }}
              >
                Job Description
              </span>
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(240, 65, 65, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "500",
                  lineHeight: "24.00px",
                }}
              >
                *
              </span>
            </span>
          </span>
        </div>

        <div
          id="_3353_5712__arrow_back"
          style={{
            position: "absolute",
            height: "24.00px",
            width: "24.00px",
            left: "41.00px",
            top: "121.00px",
          }}
        >
          <img
            id="I3353_5712_54616_25400__icon"
            src="assets/jobpostimages/icon.svg"
            alt="icon"
            style={{
              position: "absolute",
              left: "calc(100% * 0.17)",
              top: "calc(100% * 0.17)",
            }}
          />
        </div>

        <div
          id="_3356_6163__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "89.00px",
            width: "1449.00px",
            left: "-9.00px",
            top: "-10.00px",
          }}
        ></div>

        <div
          id="_3356_6200__Frame_27"
          style={{
            position: "absolute",
            height: "50.00px",
            width: "345.65px",
            left: "calc(50% - 180.59px)",
            top: "17.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3356_6201__Frame_5"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3356_6202__Home"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </span>
          </div>

          <div
            id="_3356_6203__Frame_4"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3356_6204__Jobs"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </span>
          </div>

          <div
            id="_3356_6205__Frame_3"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3356_6206__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>

          <div
            id="_3356_6207__Frame_10"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>

        <div
          id="_3356_6209__Frame_10"
          style={{
            position: "absolute",
            height: "30.00px",
            width: "85.66px",
            left: "1120.01px",
            top: "17.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3356_6210__Browse_jobs"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "120.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(12, 70, 59, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "700",
                lineHeight: "150.00%",
              }}
            >
              Browse jobs
            </span>
          </span>
        </div>

        <span
          id="_3356_6211__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "52.00px",
            position: "absolute",
            left: "30.00px",
            top: "24.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job&nbsp;
          </span>
        </span>
        <span
          id="_3356_6212__Fiesta"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "124.00px",
            position: "absolute",
            left: "76.00px",
            top: "19.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>

        <div
          id="_3357_5266__Menu_with_Text_field"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "296.00px",
            width: "332.00px",
            left: "166.00px",
            top: "1254.00px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            padding: "8px 0px 0px 0px",
          }}
        >
          <div
            id="I3357_5266_54061_37014__Text_field"
            style={{
              position: "relative",
              borderTopLeftRadius: "4.0px",
              borderTopRightRadius: "4.0px",
              height: "56.00px",
              width: "calc(100% - 0px - 0px)",
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
            }}
          >
            <div
              id="I3357_5266_54061_37014_52798_24672__Text_field"
              style={{
                position: "relative",
                borderColor: "#65558fff",
                borderStyle: "solid",
                borderWidth: "3px",
                borderRadius: "4px",
                width: "calc(100% - 0px - 0px)",
                flex: "1",
                display: "flex",
                flexDirection: "column",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
              }}
            >
              <div
                id="I3357_5266_54061_37014_52798_24673__State-layer"
                style={{
                  position: "relative",
                  borderTopLeftRadius: "4.0px",
                  borderTopRightRadius: "4.0px",
                  width: "calc(100% - 16px - 0px)",
                  flex: "1",
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "flex-start",
                  alignItems: "flex-start",
                  flexWrap: "nowrap",
                  gap: "4px",
                  padding: "4px 0px 4px 16px",
                }}
              >
                <div
                  id="I3357_5266_54061_37014_52798_24674__Content"
                  style={{
                    position: "relative",
                    height: "40.00px",
                    flex: "1",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "flex-start",
                    flexWrap: "nowrap",
                    padding: "4px 0px",
                  }}
                >
                  <div
                    id="I3357_5266_54061_37014_52798_24675__Input_text_container"
                    style={{
                      position: "relative",
                      width: "calc(100% - 0px - 0px)",
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "flex-start",
                      alignItems: "center",
                      flexWrap: "nowrap",
                    }}
                  >
                    <span
                      id="I3357_5266_54061_37014_52798_24676__Input_text"
                      style={{
                        display: "flex",
                        justifyContent: "flex-start",
                        textAlign: "left",
                        alignItems: "center",
                        height: "24.00px",
                        width: "0.00px",
                        position: "relative",
                      }}
                    ></span>
                  </div>

                  <div
                    id="I3357_5266_54061_37014_52798_24678__Label_text_container"
                    style={{
                      position: "absolute",
                      background: "rgba(254, 247, 255, 1.00)",
                      height: "16.00px",
                      width: "31.00px",
                      left: "-4.00px",
                      top: "-12.00px",
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "flex-start",
                      alignItems: "center",
                      flexWrap: "nowrap",
                      padding: "0px 4px",
                    }}
                  >
                    <span
                      id="I3357_5266_54061_37014_52798_24679__Label_text"
                      style={{
                        display: "flex",
                        justifyContent: "flex-start",
                        textAlign: "left",
                        alignItems: "flex-start",
                        height: "16.00px",
                        width: "31.00px",
                        position: "relative",
                      }}
                    >
                      <span
                        style={{
                          whiteSpace: "nowrap",
                          background: "rgba(101, 85, 143, 1.00)",
                          backgroundClip: "text",
                          WebkitBackgroundClip: "text",
                          textFillColor: "transparent",
                          WebkitTextFillColor: "transparent",
                          fontFamily: "Roboto",
                          fontStyle: "normal",
                          fontSize: "12.0px",
                          fontWeight: "400",
                          lineHeight: "16.00px",
                          letterSpacing: "0.4000000059604645px",
                        }}
                      >
                        Label
                      </span>
                    </span>
                  </div>
                </div>

                <div
                  id="I3357_5266_54061_37014_52798_24680__Trailing_icon"
                  style={{
                    position: "relative",
                    height: "48.00px",
                    width: "48.00px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    flexWrap: "nowrap",
                    gap: "10px",
                  }}
                >
                  <div
                    id="I3357_5266_54061_37014_52798_24680_51525_5219__container"
                    style={{
                      position: "relative",
                      overflow: "hidden",
                      borderRadius: "100px",
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "center",
                      alignItems: "center",
                      flexWrap: "nowrap",
                      gap: "10px",
                    }}
                  >
                    <div
                      id="I3357_5266_54061_37014_52798_24680_51525_5220__state-layer"
                      style={{
                        position: "relative",
                        height: "24.00px",
                        width: "24.00px",
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "center",
                        alignItems: "center",
                        flexWrap: "nowrap",
                        gap: "10px",
                        padding: "8px",
                      }}
                    >
                      <div
                        id="I3357_5266_54061_37014_52798_24680_51525_5221__Icon"
                        style={{
                          position: "relative",
                          height: "24.00px",
                          width: "24.00px",
                        }}
                      >
                        <img
                          id="I3357_5266_54061_37014_52798_24680_51525_5221_54616_25504__icon"
                          src="assets/jobpostimages/icon_2.svg"
                          alt="icon"
                          style={{
                            position: "absolute",
                            left: "calc(100% * 0.08)",
                            top: "calc(100% * 0.08)",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            id="I3357_5266_54061_37015__Menu"
            style={{
              position: "relative",
              background: "rgba(255, 255, 255, 1.00)",
              borderRadius: "4px",
              boxShadow:
                "0.0px 2.0px 6.0px 2.0px rgba(0, 0, 0, 0.15), 0.0px 1.0px 2.0px 0.0px rgba(0, 0, 0, 0.30)",
              height: "224.00px",
              width: "200.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              padding: "8px 0px",
            }}
          ></div>
        </div>

        <span
          id="_3357_5304__Begineer_level"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "54.00px",
            width: "320.00px",
            position: "absolute",
            left: "186.00px",
            top: "1379.00px",
          }}
        >
          <span
            style={{
              background: "rgba(122, 110, 110, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "700",
            }}
          >
            Begineer level
          </span>
        </span>
        <span
          id="_3357_5310__Advanced_level"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "54.00px",
            width: "320.00px",
            position: "absolute",
            left: "182.00px",
            top: "1441.00px",
          }}
        >
          <span
            style={{
              background: "rgba(122, 110, 110, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "700",
            }}
          >
            Advanced level
          </span>
        </span>
      </div>
    </>
  );
};
export default PostJobPage;
