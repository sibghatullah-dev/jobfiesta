import { useNavigate } from "react-router-dom";
import React from "react";

const RecruiterDashBoardPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <div
        id="_3362_5870__Recruiter_DashBoard_"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          height: "2460.0px",
          width: "100%",
        }}
      >
        <div
          id="_3362_5873__Rectangle_34625586"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "1.5665795803070068px",
            borderRadius: "50px",
            height: "83.87px",
            width: "1196.87px",
            left: "120.00px",
            top: "319.00px",
          }}
        ></div>

        <div
          id="_3362_5875__Frame_13966"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "15.54px",
            width: "37.88px",
            left: "1192.00px",
            top: "335.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 53px",
          }}
        >
          <span
            id="_3362_5876__Search"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "16.00px",
              width: "58.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.0px",
                fontWeight: "600",
                lineHeight: "16.00px",
              }}
            >
              Search
            </span>
          </span>
        </div>

        <img
          id="_3362_5878__Line_5"
          src="assets/recruiterdashboardimages/line_5_3.svg"
          alt="Line_5"
          style={{
            position: "absolute",
            transform: "rotate(-90.00deg) scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "362.00px",
            top: "343.00px",
          }}
        />
        <img
          id="_3362_5879__Line_6"
          src="assets/recruiterdashboardimages/line_6_3.svg"
          alt="Line_6"
          style={{
            position: "absolute",
            transform: "rotate(-90.00deg) scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "806.00px",
            top: "339.33px",
          }}
        />
        <span
          id="_3362_5883__Enter_Job_title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "20.00px",
            width: "135.00px",
            position: "absolute",
            left: "195.00px",
            top: "354.33px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(127, 127, 127, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "400",
              lineHeight: "20.00px",
            }}
          >
            Enter Job title
          </span>
        </span>

        <img
          id="_3362_5884__Vector"
          src="assets/recruiterdashboardimages/vector_108.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.12)",
            top: "calc(100% * 0.19)",
          }}
        />

        <span
          id="_3362_5888__Enter_location"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "19.83px",
            width: "137.00px",
            position: "absolute",
            left: "645.00px",
            top: "351.92px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(127, 127, 127, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "400",
              lineHeight: "20.00px",
            }}
          >
            Enter location
          </span>
        </span>

        <img
          id="_3362_5889__Vector"
          src="assets/recruiterdashboardimages/vector_109.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.42)",
            top: "calc(100% * 0.19)",
          }}
        />

        <div
          id="_3362_5890__Rectangle_34625589"
          style={{
            position: "absolute",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "2px",
            borderRadius: "10px",
            height: "45.00px",
            width: "169.00px",
            left: "1188.00px",
            top: "493.00px",
          }}
        ></div>

        <span
          id="_3362_5893__Job_Search"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "268.00px",
            position: "absolute",
            left: "calc(50% - 620.50px)",
            top: "187.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Job Search
          </span>
        </span>
        <span
          id="_3362_5894__Search_for_your_desi"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "22.00px",
            width: "520.00px",
            position: "absolute",
            left: "calc(50% - 620.50px)",
            top: "252.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            Search for your desired job matching your skills
          </span>
        </span>

        <div
          id="_3362_5895__Filter_text"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "477.00px",
            width: "700.00px",
            left: "362.00px",
            top: "505.00px",
          }}
        >
          <span
            id="_3362_5896__Top_Talent_Suggestio"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "26.79px",
              width: "269.05px",
              position: "absolute",
              left: "calc(50% - 198.72px)",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "600",
                lineHeight: "24.00px",
              }}
            >
              Top Talent Suggestions&nbsp;
            </span>
          </span>
          <span
            id="_3362_5897__Clear_all"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "2.33%",
              width: "55.70px",
              position: "absolute",
              left: "calc(50% - 312.00px)",
              top: "calc(100% * 0.02)",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(127, 127, 127, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.0px",
                fontWeight: "500",
                lineHeight: "11.00px",
              }}
            >
              Clear all
            </span>
          </span>
          <span
            id="_3362_6357__View_more"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "64.00px",
              width: "161.00px",
              position: "absolute",
              left: "512.00px",
              top: "413.00px",
            }}
          >
            <span
              style={{
                background: "rgba(12, 70, 59, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "16.00px",
                textDecoration: "underline",
              }}
            >
              View more
            </span>
          </span>
        </div>

        <span
          id="_3362_5898__View_more"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "16.00px",
            width: "129.00px",
            position: "absolute",
            left: "875.00px",
            top: "1775.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "500",
              lineHeight: "16.00px",
              textDecoration: "underline",
            }}
          >
            View more
          </span>
        </span>
        <span
          id="_3362_5900__Popular"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "17.00px",
            width: "63.00px",
            position: "absolute",
            left: "1207.00px",
            top: "509.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.031837463378906px",
              fontWeight: "500",
              lineHeight: "16.03px",
            }}
          >
            Popular
          </span>
        </span>

        <div
          id="_3362_5903__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "524.00px",
            top: "565.00px",
          }}
        ></div>

        <div
          id="_3362_5904__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "541.76px",
            top: "595.61px",
          }}
        ></div>

        <div
          id="_3362_5908__MapPin"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "18.90px",
            width: "18.78px",
            left: "538.00px",
            top: "695.00px",
          }}
        >
          <img
            id="I3362_5908_1502_72218__MapPin"
            src="assets/recruiterdashboardimages/mappin_12.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3362_5909__Lahore_Pakistan"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.99px",
            width: "116.00px",
            position: "absolute",
            left: "560.95px",
            top: "697.10px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            Lahore,Pakistan
          </span>
        </span>

        <div
          id="_3362_5910__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "875.02px",
            top: "583.90px",
          }}
        >
          <img
            id="I3362_5910_1502_74271__BookmarkSimple"
            src="assets/recruiterdashboardimages/bookmarksimple_12.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_5912__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "542.00px",
            top: "638.00px",
          }}
        >
          <div
            id="_3362_5913__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "46.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3362_5914__Skills"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "46.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Skills
              </span>
            </span>
          </div>

          <span
            id="_3365_5684__Web_Development__App"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "276.00px",
              position: "absolute",
              left: "77.00px",
              top: "5.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(11, 160, 44, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Web Development, App Development
            </span>
          </span>
        </div>

        <span
          id="_3362_5916__Name__Furqan_Zeeshan"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "541.83px",
            top: "592.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Name: Furqan Zeeshan
          </span>
        </span>
        <div
          id="_3362_5927__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "632.15px",
            top: "813.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5928__View_Profile"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "87.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View Profile
            </span>
          </span>
        </div>

        <span
          id="_3362_6249__Applications_in_Prog"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "24.00px",
            width: "295.00px",
            position: "absolute",
            left: "calc(50% - 212.50px)",
            top: "911.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "600",
              lineHeight: "24.00px",
            }}
          >
            Applications in Progress
          </span>
        </span>

        <span
          id="_3362_5915__Salary__20_000_PKR_-"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "15.00px",
            width: "227.00px",
            position: "absolute",
            left: "542.00px",
            top: "758.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            Salary: 20,000 PKR - 25,000 PKR
          </span>
        </span>
        <img
          id="_3362_6083__Arrow_2"
          src="assets/recruiterdashboardimages/arrow_2_2.svg"
          alt="Arrow_2"
          style={{
            position: "absolute",
            left: "calc(100% * 0.89)",
            top: "calc(100% * 0.27)",
          }}
        />
        <div
          id="_3362_6136__Nav_Bar"
          style={{
            position: "absolute",
            overflow: "hidden",
            background: "rgba(12, 70, 59, 1.00)",
            height: "1037.00px",
            width: "248.00px",
            left: "92.00px",
            top: "554.00px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "62px",
            padding: "40px 20px",
          }}
        >
          <div
            id="_3362_6137__Frame_183"
            style={{
              position: "relative",
              background: "rgba(12, 70, 59, 1.00)",
              borderRadius: "10px",
              width: "calc(100% - 10px - 10px)",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3362_6138__Text"
              onClick={() => navigate("/AccountsettingsPage")}
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "27.00px",
                width: "136.00px",
                position: "relative",
                cursor: "pointer",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(255, 255, 255, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Nunito Sans",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "600",
                  letterSpacing: "0.30000001192092896px",
                }}
              >
                Profile Update
              </span>
            </span>
          </div>

          <div
            id="_3362_6139__Frame_184"
            onClick={() => navigate("/ChatInterface1")}
            style={{
              position: "relative",
              borderRadius: "10px",
              width: "calc(100% - 10px - 10px)",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3362_6140__Text"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "27.00px",
                width: "93.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(255, 255, 255, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Nunito Sans",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "600",
                  letterSpacing: "0.30000001192092896px",
                }}
              >
                Messages
              </span>
            </span>
          </div>

          <div
            id="_3362_6141__Frame_185"
            onClick={() => navigate("/AccountsettingsPage")}
            style={{
              position: "relative",
              borderRadius: "10px",
              width: "calc(100% - 10px - 10px)",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3362_6142__Text"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "27.00px",
                width: "160.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(255, 255, 255, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Nunito Sans",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "600",
                  letterSpacing: "0.30000001192092896px",
                }}
              >
                Account Settings
              </span>
            </span>
          </div>
        </div>

        <div
          id="_3362_6331__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "985.00px",
            top: "565.00px",
          }}
        ></div>

        <div
          id="_3362_6332__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "1002.76px",
            top: "595.61px",
          }}
        ></div>

        <div
          id="_3362_6335__MapPin"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "18.90px",
            width: "18.78px",
            left: "999.00px",
            top: "695.00px",
          }}
        >
          <img
            id="I3362_6335_1502_72218__MapPin"
            src="assets/recruiterdashboardimages/mappin_13.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3362_6336__Lahore__Pakistan"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "15.00px",
            width: "147.00px",
            position: "absolute",
            left: "1022.00px",
            top: "697.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            Lahore, Pakistan
          </span>
        </span>

        <div
          id="_3362_6337__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "1335.02px",
            top: "583.90px",
          }}
        >
          <img
            id="I3362_6337_1502_74271__BookmarkSimple"
            src="assets/recruiterdashboardimages/bookmarksimple_13.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_6339__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "1003.00px",
            top: "638.00px",
          }}
        >
          <div
            id="_3362_6340__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "46.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3362_6341__Skills"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "46.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Skills
              </span>
            </span>
          </div>

          <span
            id="_3362_6342__Mern_Stack_Developer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "160.00px",
              position: "absolute",
              left: "77.00px",
              top: "5.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(11, 160, 44, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Mern Stack Developer
            </span>
          </span>
        </div>

        <span
          id="_3362_6343__Name__Muhammad_Ali"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "1002.83px",
            top: "592.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Name: Muhammad Ali
          </span>
        </span>
        <div
          id="_3362_6345__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1106.15px",
            top: "813.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_6346__View_Profile"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "87.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View Profile
            </span>
          </span>
        </div>

        <span
          id="_3368_5442__Salary__40_000_PKR_-"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "15.00px",
            width: "228.00px",
            position: "absolute",
            left: "993.00px",
            top: "753.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            Salary: 40,000 PKR - 55,000 PKR
          </span>
        </span>

        <div
          id="_3368_5446__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "524.00px",
            top: "995.00px",
          }}
        ></div>

        <div
          id="_3368_5447__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "541.76px",
            top: "1025.61px",
          }}
        ></div>

        <div
          id="_3368_5452__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "875.02px",
            top: "1013.90px",
          }}
        >
          <img
            id="I3368_5452_1502_74271__BookmarkSimple"
            src="assets/recruiterdashboardimages/bookmarksimple_14.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3368_5454__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "535.00px",
            top: "1091.00px",
          }}
        >
          <div
            id="_3368_5455__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "90.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3368_5456__Applied_for"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "90.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Applied for
              </span>
            </span>
          </div>

          <span
            id="_3368_5457__UX_Designer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "118.00px",
              position: "absolute",
              left: "143.00px",
              top: "2.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(11, 160, 44, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              UX Designer
            </span>
          </span>
        </div>

        <span
          id="_3368_5458__Name__Rehan_Sajid"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "541.83px",
            top: "1022.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Name: Rehan Sajid
          </span>
        </span>
        <div
          id="_3368_5460__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "632.15px",
            top: "1243.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3368_5461__View_Application"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "126.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View Application
            </span>
          </span>
        </div>

        <div
          id="_3376_2576__Frame_676"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "538.00px",
            top: "1165.00px",
          }}
        >
          <div
            id="_3376_2577__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "56.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2578__Status"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "56.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Status
              </span>
            </span>
          </div>

          <span
            id="_3376_2579__Under_Review"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "118.00px",
              position: "absolute",
              left: "143.00px",
              top: "5.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Under Review
            </span>
          </span>
        </div>

        <div
          id="_3376_2583__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "991.00px",
            top: "982.00px",
          }}
        ></div>

        <div
          id="_3376_2584__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "1008.76px",
            top: "1012.61px",
          }}
        ></div>

        <div
          id="_3376_2585__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "1341.02px",
            top: "1000.90px",
          }}
        >
          <img
            id="I3376_2585_1502_74271__BookmarkSimple"
            src="assets/recruiterdashboardimages/bookmarksimple_15.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3376_2587__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "1002.00px",
            top: "1078.00px",
          }}
        >
          <div
            id="_3376_2588__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "90.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2589__Applied_for"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "90.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Applied for
              </span>
            </span>
          </div>

          <span
            id="_3376_2590__Web_Developer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "118.00px",
              position: "absolute",
              left: "143.00px",
              top: "2.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(11, 160, 44, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Web Developer
            </span>
          </span>
        </div>

        <span
          id="_3376_2591__Name__Zeeshan"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "1008.83px",
            top: "1009.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Name: Zeeshan
          </span>
        </span>
        <div
          id="_3376_2593__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1112.15px",
            top: "1230.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3376_2594__View_Application"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "126.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View Application
            </span>
          </span>
        </div>

        <div
          id="_3376_2595__Frame_676"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "1005.00px",
            top: "1152.00px",
          }}
        >
          <div
            id="_3376_2596__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "56.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2597__Status"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "56.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Status
              </span>
            </span>
          </div>

          <span
            id="_3376_2598__Under_Review"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "118.00px",
              position: "absolute",
              left: "143.00px",
              top: "5.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Under Review
            </span>
          </span>
        </div>

        <div
          id="_3376_2605__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "524.00px",
            top: "1334.00px",
          }}
        ></div>

        <div
          id="_3376_2606__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "541.76px",
            top: "1364.61px",
          }}
        ></div>

        <div
          id="_3376_2607__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "875.02px",
            top: "1352.90px",
          }}
        >
          <img
            id="I3376_2607_1502_74271__BookmarkSimple"
            src="assets/recruiterdashboardimages/bookmarksimple_16.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3376_2609__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "331.88px",
            left: "545.45px",
            top: "1430.00px",
          }}
        >
          <div
            id="_3376_2610__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "90.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2611__Applied_for"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "90.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Applied for
              </span>
            </span>
          </div>

          <span
            id="_3376_2612__Graphic_Designer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "151.00px",
              position: "absolute",
              left: "143.00px",
              top: "2.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(11, 160, 44, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Graphic Designer
            </span>
          </span>
        </div>

        <span
          id="_3376_2613__Name__Shan"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "262.79px",
            position: "absolute",
            left: "552.08px",
            top: "1361.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Name: Shan
          </span>
        </span>
        <div
          id="_3376_2615__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(24, 25, 28, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "27.78px",
            left: "528.00px",
            top: "1583.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3376_2616__Rate"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "35.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Rate
            </span>
          </span>
        </div>

        <div
          id="_3376_2617__Frame_676"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "331.88px",
            left: "548.36px",
            top: "1504.00px",
          }}
        >
          <div
            id="_3376_2618__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "56.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2619__Status"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "56.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Status
              </span>
            </span>
          </div>

          <span
            id="_3376_2620__Reviewed"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "118.00px",
              position: "absolute",
              left: "143.00px",
              top: "5.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Reviewed
            </span>
          </span>
        </div>

        <div
          id="_3376_2654__Favorite"
          style={{
            position: "absolute",
            background:
              "url(assets/recruiterdashboardimages/favorite.png) 100% / contain no-repeat",
            height: "29.00px",
            width: "34.91px",
            left: "763.10px",
            top: "1588.00px",
          }}
        ></div>

        <div
          id="_3376_2656__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "34.91px",
            left: "798.97px",
            top: "1588.00px",
          }}
        ></div>

        <div
          id="_3386_801__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "36.00px",
            left: "862.00px",
            top: "1589.00px",
          }}
        ></div>

        <div
          id="_3376_2658__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "36.00px",
            left: "832.00px",
            top: "1588.00px",
          }}
        ></div>

        <div
          id="_3376_2627__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "382.61px",
            left: "996.05px",
            top: "1334.00px",
          }}
        ></div>

        <div
          id="_3376_2628__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "262.57px",
            left: "1018.15px",
            top: "1340.61px",
          }}
        ></div>

        <div
          id="_3376_2629__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.79px",
            left: "1353.38px",
            top: "1353.00px",
          }}
        >
          <img
            id="I3376_2629_1502_74271__BookmarkSimple"
            src="assets/recruiterdashboardimages/bookmarksimple_17.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3376_2631__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "347.62px",
            left: "1011.28px",
            top: "1430.00px",
          }}
        >
          <div
            id="_3376_2632__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "90.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2633__Applied_for"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "90.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Applied for
              </span>
            </span>
          </div>

          <span
            id="_3376_2634__Software_Engineer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "180.00px",
              position: "absolute",
              left: "143.00px",
              top: "2.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(11, 160, 44, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Software Engineer
            </span>
          </span>
        </div>

        <div
          id="_3376_2637__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(24, 25, 28, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "34.31px",
            left: "1018.00px",
            top: "1583.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3376_2638__Rate"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "35.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Rate
            </span>
          </span>
        </div>

        <div
          id="_3376_2639__Frame_676"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "347.62px",
            left: "1011.28px",
            top: "1504.00px",
          }}
        >
          <div
            id="_3376_2640__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "56.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3376_2641__Status"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "56.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Status
              </span>
            </span>
          </div>

          <span
            id="_3376_2642__Reviewed"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "118.00px",
              position: "absolute",
              left: "143.00px",
              top: "5.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Reviewed
            </span>
          </span>
          <div
            id="_3376_2664__Favorite"
            style={{
              position: "absolute",
              background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
              height: "29.00px",
              width: "36.00px",
              left: "232.72px",
              top: "84.00px",
            }}
          ></div>

          <div
            id="_3376_2668__Favorite"
            style={{
              position: "absolute",
              background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
              height: "29.00px",
              width: "36.00px",
              left: "297.00px",
              top: "84.00px",
            }}
          ></div>
        </div>

        <div
          id="_3376_2660__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "36.57px",
            left: "1193.00px",
            top: "1589.00px",
          }}
        ></div>

        <div
          id="_3376_2662__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "36.57px",
            left: "1226.00px",
            top: "1589.00px",
          }}
        ></div>

        <span
          id="_3376_2635__Name__Ahsan"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "1021.00px",
            top: "1361.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Name: Ahsan
          </span>
        </span>
        <div
          id="_3376_2652__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "36.00px",
            left: "709.00px",
            top: "1588.00px",
          }}
        ></div>

        <div
          id="_3376_2666__Favorite"
          style={{
            position: "absolute",
            background: "url(assets/recruiterdashboardimages/null) 100% / contain no-repeat",
            height: "29.00px",
            width: "36.00px",
            left: "1294.00px",
            top: "1588.00px",
          }}
        ></div>

        <div
          id="_3362_6197__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "89.00px",
            width: "1440.00px",
            left: "0.00px",
            top: "0.00px",
          }}
        ></div>

        <div
          id="_3362_6234__Frame_27"
          style={{
            position: "absolute",
            height: "50.00px",
            width: "343.50px",
            left: "calc(50% - 174.50px)",
            top: "27.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3362_6235__Frame_5"
            onClick={() => navigate("/")}
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3362_6236__Home"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </span>
          </div>

          <div
            id="_3362_6237__Frame_4"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3362_6238__Jobs"
              onClick={() => navigate("/SearchPage")}
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
                cursor: "pointer",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </span>
          </div>

          <div
            id="_3362_6239__Frame_3"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3362_6240__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>

          <div
            id="_3362_6241__Frame_10"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>

        <span
          id="_3362_6245__Job"
          onClick={() => navigate("/")}
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "51.68px",
            position: "absolute",
            left: "38.76px",
            top: "34.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job&nbsp;
          </span>
        </span>
        <span
          id="_3362_6246__Fiesta"
          onClick={() => navigate("/")}
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "123.23px",
            position: "absolute",
            left: "84.47px",
            top: "29.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>
        <img
          id="_3377_2793__Group_6"
          src="assets/recruiterdashboardimages/group_6_7.svg"
          alt="Group_6"
          style={{
            position: "absolute",
            left: "calc(100% * 0.96)",
            top: "calc(100% * 0.00)",
          }}
        />
        <div
          id="_3377_2798__Frame_28"
          onClick={() => navigate("/PostJobPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "35.00px",
            width: "149.00px",
            left: "1234.00px",
            top: "20.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3377_2799__Post_a_Job"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "101.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Post a Job
            </span>
          </span>
          <img
            id="_3377_2800__Group"
            src="assets/recruiterdashboardimages/group_33.svg"
            alt="Group"
            style={{ position: "relative" }}
          />
        </div>

        <span
          id="_3377_2835__Browse_jobs"
          onClick={() => navigate("/SearchPage")}
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "30.00px",
            width: "120.00px",
            position: "absolute",
            left: "1030.00px",
            top: "37.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Browse jobs
          </span>
        </span>
      </div>
    </>
  );
};
export default RecruiterDashBoardPage;
