import { useNavigate } from "react-router-dom";
import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import PasswordInput from "./components/PasswordField";

const RegistrationForjobseekerPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth(); // Use login to auto-login after registration
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    skills: "",
    experience: "",
    jobTitle: "",
    location: "",
    jobType: "",
    desiredSalaryRange: "",
    preferredIndustry: "",
    education: "",
    gender: "",
    city: "",
    languages: "",
    institution: "",
    completionYear: "",
    address: "",
    goals: "",
  });
  const [error, setError] = useState(null);
  const [photo, setPhoto] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePhotoChange = (e) => {
    setPhoto(e.target.files[0]);
  };

  const handleSubmit = async () => {
    setError(null);
    try {
      // Prepare data for backend
      const dataToSend = {
        email: formData.email,
        password: formData.password,
        name: formData.name,
        skills: formData.skills.split(",").map((skill) => skill.trim()),
        experience: formData.experience,
        jobTitle: formData.jobTitle,
        location: formData.location,
        jobType: formData.jobType,
        desiredSalaryRange: formData.desiredSalaryRange,
        preferredIndustry: formData.preferredIndustry,
        education: formData.education,
        gender: formData.gender,
        city: formData.city,
        languages: formData.languages.split(",").map((lang) => lang.trim()),
        institution: formData.institution,
        completionYear: formData.completionYear,
        address: formData.address,
        goals: formData.goals,
      };

      // Send registration request
      const response = await fetch("/api/auth/register/jobseeker", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dataToSend),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }

      const result = await response.json();
      console.log("Registration successful:", result);

      // Auto-login after registration
      const loginResult = await login(formData.email, formData.password);
      if (loginResult.success) {
        navigate("/jobseeker-dashboard");
      } else {
        throw new Error(loginResult.message || "Auto-login failed");
      }
    } catch (err) {
      setError(err.message);
      console.error("Registration error:", err);
    }
  };

  const handleCancel = () => {
    navigate("/RegistrationPage");
  };

  return (
    <>
      <div
        id="_3357_5312__Registration_For_job"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          borderRadius: "15px",
          height: "2289.0px",
          width: "100%",
        }}
      >
        {error && (
          <div
            style={{
              color: "red",
              marginBottom: "10px",
              position: "absolute",
              left: "162px",
              top: "1900px",
            }}
          >
            {error}
          </div>
        )}
        <span
          id="_3357_5314__Registration_Form_Fo"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "772.00px",
            position: "absolute",
            left: "calc(50% - 608.50px)",
            top: "145.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Registration Form For Job seekers
          </span>
        </span>
        <div
          id="_3378_2573__Rectangle_3"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "40px",
            boxShadow: "0.0px 10.0px 40.0px 0.0px rgba(0, 0, 0, 0.15)",
            height: "1939.00px",
            width: "1270.00px",
            left: "calc(50% - 626.50px)",
            top: "257.00px",
          }}
        ></div>
        <div
          id="_3357_5316__Button__Post_"
          onClick={handleSubmit}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "90.86px",
            width: "320.00px",
            left: "839.00px",
            top: "1987.00px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3357_5317__Sign_Up"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "46.00px",
              width: "128.00px",
              position: "absolute",
              left: "calc(50% - 72.00px)",
              top: "22.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "33.74409866333008px",
                fontWeight: "700",
                lineHeight: "45.29px",
              }}
            >
              Sign Up
            </span>
          </span>
        </div>
        <div
          id="_3357_5318__Button__submitbtn_"
          onClick={handleCancel}
          style={{
            position: "absolute",
            background: "rgba(233, 25, 29, 1.00)",
            borderRadius: "15px",
            height: "82.00px",
            width: "320.00px",
            left: "268.00px",
            top: "1992.00px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3357_5319__Cancel"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "41.00px",
              width: "104.00px",
              position: "absolute",
              left: "calc(50% - 52.00px)",
              top: "20.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "30.45404624938965px",
                fontWeight: "700",
                lineHeight: "40.88px",
              }}
            >
              Cancel
            </span>
          </span>
        </div>
        <div
          id="_3357_5320__Input__email_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "324.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="Email"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5322__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "327.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <PasswordInput
            onChange={(value) => setFormData((prev) => ({ ...prev, password: value }))}
          />
        </div>
        <div
          id="_3357_5324__Input__name_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "478.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Name"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5326__Input__skills_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "481.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="skills"
            value={formData.skills}
            onChange={handleInputChange}
            placeholder="Skills (comma-separated)"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5328__Input__experience_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "629.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="experience"
            value={formData.experience}
            onChange={handleInputChange}
            placeholder="Experience (e.g., 2 years)"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5330__Input__jobTitle_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "628.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="jobTitle"
            value={formData.jobTitle}
            onChange={handleInputChange}
            placeholder="Job Title"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5335__Input__location_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "780.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleInputChange}
            placeholder="Location"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5337__Input__jobType_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "780.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="jobType"
            value={formData.jobType}
            onChange={handleInputChange}
            placeholder="Job Type"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5339__Input__desiredSalaryRange_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "943.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="desiredSalaryRange"
            value={formData.desiredSalaryRange}
            onChange={handleInputChange}
            placeholder="Desired Salary Range"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5341__Input__preferredIndustry_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "946.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="preferredIndustry"
            value={formData.preferredIndustry}
            onChange={handleInputChange}
            placeholder="Preferred Industry"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5343__Input__education_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "1100.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="education"
            value={formData.education}
            onChange={handleInputChange}
            placeholder="Education"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5326__Input__gender_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "1100.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <select
            name="gender"
            value={formData.gender}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div
          id="_3357_5328__Input__city_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "1250.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleInputChange}
            placeholder="City"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5330__Input__languages_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "1250.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="languages"
            value={formData.languages}
            onChange={handleInputChange}
            placeholder="Languages (comma-separated)"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5335__Input__institution_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "1400.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="institution"
            value={formData.institution}
            onChange={handleInputChange}
            placeholder="Institution"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5337__Input__completionYear_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "787.00px",
            top: "1400.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="completionYear"
            value={formData.completionYear}
            onChange={handleInputChange}
            placeholder="Completion Year"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5339__Input__address_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "637.91px",
            left: "162.00px",
            top: "1550.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleInputChange}
            placeholder="Address"
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>
        <div
          id="_3357_5341__Input__experienceLevel_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "162.00px",
            top: "1700.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <select
            name="experienceLevel"
            value={formData.experienceLevel}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              width: "100%",
              background: "transparent",
            }}
          >
            <option value="">Select Experience Level</option>
            <option value="Beginner">Beginner</option>
            <option value="Advanced">Advanced</option>
          </select>
        </div>
        <div
          id="_3357_5360__Div__formInput_"
          style={{
            position: "absolute",
            height: "177.00px",
            width: "1171.00px",
            left: "128.00px",
            top: "1850.00px",
          }}
        >
          <div
            id="_3357_5361__Input__goals_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "89.91px",
              width: "1166.91px",
              left: "0.00px",
              top: "45.00px",
              display: "flex",
              alignItems: "center",
              padding: "0 17px",
            }}
          >
            <textarea
              name="goals"
              value={formData.goals}
              onChange={handleInputChange}
              placeholder="Goals"
              style={{
                border: "none",
                outline: "none",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24px",
                fontWeight: "400",
                lineHeight: "24px",
                width: "100%",
                background: "transparent",
                resize: "none",
                height: "80px",
              }}
            />
          </div>
          <span
            id="_3357_5362__Goals_"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "82.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(240, 65, 65, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Goals*
            </span>
          </span>
        </div>
        <div
          id="_3357_5353__Div__formField_"
          style={{
            position: "absolute",
            height: "239.00px",
            width: "413.00px",
            left: "869.00px",
            top: "1700.00px",
          }}
        >
          <span
            id="_3357_5355__Upload_Photo_"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "181.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(240, 65, 65, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Upload Photo *
            </span>
          </span>
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoChange}
            style={{
              position: "absolute",
              left: "0px",
              top: "40px",
              fontFamily: "Poppins",
              fontSize: "20px",
            }}
          />
        </div>
        <div
          id="_3357_5363__arrow_back"
          onClick={() => navigate("/RegistrationPage")}
          style={{
            position: "absolute",
            height: "24.00px",
            width: "24.00px",
            left: "41.00px",
            top: "121.00px",
            cursor: "pointer",
          }}
        >
          <img
            id="I3357_5363_54616_25400__icon"
            src="assets/images/icon_15.svg"
            alt="icon"
            style={{
              position: "absolute",
              left: "calc(100% * 0.17)",
              top: "calc(100% * 0.17)",
            }}
          />
        </div>
        <div
          id="_3357_5365__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "89.00px",
            width: "1449.00px",
            left: "-9.00px",
            top: "-10.00px",
          }}
        ></div>
        <div
          id="_3399_794__Frame_10"
          style={{
            position: "absolute",
            height: "30.00px",
            width: "85.66px",
            left: "1120.01px",
            top: "17.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3399_795__Browse_jobs"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "120.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(12, 70, 59, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "700",
                lineHeight: "150.00%",
              }}
            >
              Browse jobs
            </span>
          </span>
        </div>
        <div
          id="_3357_5402__Frame_27"
          style={{
            position: "absolute",
            height: "50.00px",
            width: "345.65px",
            left: "calc(50% - 180.09px)",
            top: "17.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3357_5403__Frame_5"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3357_5404__Home"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </span>
          </div>
          <div
            id="_3357_5405__Frame_4"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3357_5406__Jobs"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </span>
          </div>
          <div
            id="_3357_5407__Frame_3"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3357_5408__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>
          <div
            id="_3357_5409__Frame_10"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>
        <span
          id="_3357_5413__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "52.00px",
            position: "absolute",
            left: "30.00px",
            top: "24.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job
          </span>
        </span>
        <span
          id="_3357_5414__Fiesta"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "124.00px",
            position: "absolute",
            left: "76.00px",
            top: "19.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>
      </div>
    </>
  );
};

export default RegistrationForjobseekerPage;