import { useNavigate } from "react-router-dom";
import React, { useState } from "react";

const SearchPage = () => {
  const navigate = useNavigate();
  const [searchBtnHover, setSearchBtnHover] = useState(false);

  return (
    <>
      <div
        id="_3327_3218__search_Page"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          height: "2460.0px",
          width: "100%",
        }}
      >
        <div
          id="_3327_3221__Rectangle_34625586"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "1.5665795803070068px",
            borderRadius: "50px",
            height: "83.87px",
            width: "1196.87px",
            left: "120.00px",
            top: "319.00px",
          }}
        ></div>

        <div
          id="_3327_3223__Frame_13966"
          style={{
            position: "absolute",
            background: searchBtnHover ? "#21806e" : "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "15.54px",
            width: "37.88px",
            left: "1192.00px",
            top: "335.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 53px",
            cursor: "pointer",
            transition: "background 0.2s",
          }}
          onMouseEnter={() => setSearchBtnHover(true)}
          onMouseLeave={() => setSearchBtnHover(false)}
        >
          <span
            id="_3327_3224__Search"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "16.00px",
              width: "58.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.0px",
                fontWeight: "600",
                lineHeight: "16.00px",
              }}
            >
              Search
            </span>
          </span>
        </div>

        <img
          id="_3327_3226__Line_5"
          src="assets/searchimages/line_5.svg"
          alt="Line_5"
          style={{
            position: "absolute",
            transform: "rotate(-90.00deg) scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "362.00px",
            top: "343.00px",
          }}
        />
        <img
          id="_3341_10180__Line_6"
          src="assets/searchimages/line_6.svg"
          alt="Line_6"
          style={{
            position: "absolute",
            transform: "rotate(-90.00deg) scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "806.00px",
            top: "339.33px",
          }}
        />
        {/* Job Title Input Field */}
        <input
          id="_3327_3231__Enter_Job_title"
          type="text"
          placeholder="Enter Job title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "20.00px",
            width: "135.00px",
            position: "absolute",
            left: "195.00px",
            top: "354.33px",
            whiteSpace: "nowrap",
            background: "rgba(255,255,255,1.00)",
            color: "#7f7f7f",
            fontFamily: "Poppins",
            fontStyle: "normal",
            fontSize: "20.0px",
            fontWeight: "400",
            lineHeight: "20.00px",
            border: "none",
            outline: "none",
          }}
        />

        <img
          id="_3327_3232__Vector"
          src="assets/searchimages/vector_64.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.12)",
            top: "calc(100% * 0.19)",
          }}
        />

        {/* Location Input Field */}
        <input
          id="_3327_3236__Enter_location"
          type="text"
          placeholder="Enter location"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "19.83px",
            width: "137.00px",
            position: "absolute",
            left: "645.00px",
            top: "351.92px",
            whiteSpace: "nowrap",
            background: "rgba(255,255,255,1.00)",
            color: "#7f7f7f",
            fontFamily: "Poppins",
            fontStyle: "normal",
            fontSize: "20.0px",
            fontWeight: "400",
            lineHeight: "20.00px",
            border: "none",
            outline: "none",
          }}
        />

        <img
          id="_3327_3237__Vector"
          src="assets/searchimages/vector_65.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.42)",
            top: "calc(100% * 0.19)",
          }}
        />

        <div
          id="_3327_3243__Rectangle_34625587"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "1.5px",
            borderRadius: "15px",
            height: "1272.00px",
            width: "332.00px",
            left: "120.00px",
            top: "569.00px",
          }}
        ></div>

        <div
          id="_3327_3244__Rectangle_34625589"
          style={{
            position: "absolute",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "2px",
            borderRadius: "10px",
            height: "45.00px",
            width: "169.00px",
            left: "1188.00px",
            top: "493.00px",
          }}
        ></div>

        <span
          id="_3327_3247__Job_Search"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "268.00px",
            position: "absolute",
            left: "calc(50% - 620.50px)",
            top: "187.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Job Search
          </span>
        </span>
        <span
          id="_3327_3248__Search_for_your_desi"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "22.00px",
            width: "520.00px",
            position: "absolute",
            left: "calc(50% - 620.50px)",
            top: "252.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            Search for your desired job matching your skills
          </span>
        </span>

        <span
          id="_3327_3250__Filter"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "24.00px",
            width: "60.00px",
            position: "absolute",
            left: "calc(50% - 619.50px)",
            top: "505.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "600",
              lineHeight: "24.00px",
            }}
          >
            Filter
          </span>
        </span>
        <span
          id="_3327_3251__All_Jobs__2310_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "24.00px",
            width: "176.00px",
            position: "absolute",
            left: "calc(50% - 244.50px)",
            top: "505.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "600",
              lineHeight: "24.00px",
            }}
          >
            All Jobs (2310)
          </span>
        </span>
        <span
          id="_3327_3252__Clear_all"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "0.48%",
            width: "59.00px",
            position: "absolute",
            left: "calc(50% - 378.50px)",
            top: "calc(100% * 0.27)",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(127, 127, 127, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "500",
              lineHeight: "11.00px",
            }}
          >
            Clear all
          </span>
        </span>

        <div
          id="_3327_3257__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "149.00px",
            top: "816.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3258__Checkbox"
            style={{
              position: "relative",
              background: "rgba(12, 70, 59, 1.00)",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          >
            <img
              id="_3327_3259__Vector"
              src="assets/searchimages/vector_66.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.19)",
                top: "calc(100% * 0.25)",
              }}
            />
          </div>
        </div>

        <span
          id="_3327_3260__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "67.00px",
            position: "absolute",
            left: "calc(50% - 567.50px)",
            top: "821.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            All (2567)
          </span>
        </span>
        <div
          id="_3327_3261__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "149.00px",
            top: "844.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3262__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3263__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "108.00px",
            position: "absolute",
            left: "calc(50% - 567.50px)",
            top: "849.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Full-Time (450)
          </span>
        </span>
        <div
          id="_3327_3264__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "149.00px",
            top: "872.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3265__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3266__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "109.00px",
            position: "absolute",
            left: "calc(50% - 567.50px)",
            top: "877.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Part-Time (145)
          </span>
        </span>
        <div
          id="_3327_3267__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "149.00px",
            top: "900.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3268__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <div
          id="_3327_3269__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "150.00px",
            top: "928.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3270__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3271__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "104.00px",
            position: "absolute",
            left: "calc(50% - 567.50px)",
            top: "905.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Internship (65)
          </span>
        </span>
        <span
          id="_3327_3272__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "92.00px",
            position: "absolute",
            left: "calc(50% - 566.50px)",
            top: "933.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Contract (12)
          </span>
        </span>

        <span
          id="_3327_3273__Job_Type"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "65.00px",
            position: "absolute",
            left: "149.00px",
            top: "787.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "600",
              lineHeight: "14.00px",
            }}
          >
            Job Type
          </span>
        </span>

        <div
          id="_3327_3276__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1081.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3277__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3278__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "54.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1086.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            On-Site
          </span>
        </span>
        <div
          id="_3327_3279__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1109.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3280__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3281__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "93.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1114.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Remote (180)
          </span>
        </span>
        <div
          id="_3327_3282__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1137.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3283__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3284__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "88.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1142.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Hybrid (200)
          </span>
        </span>

        <span
          id="_3327_3285__Work_Mode"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "81.00px",
            position: "absolute",
            left: "148.00px",
            top: "1052.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "600",
              lineHeight: "14.00px",
            }}
          >
            Work Mode
          </span>
        </span>

        <div
          id="_3327_3287__Text_input"
          style={{
            position: "absolute",
            overflow: "hidden",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#dde1e3ff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "6px",
            height: "30.00px",
            width: "130.00px",
            left: "149.00px",
            top: "655.00px",
          }}
        >
          <span
            id="_3327_3288__Value"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "24.00px",
              width: "calc(100% - 24.00px)",
              position: "absolute",
              left: "12.00px",
              top: "4.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(154, 166, 172, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "14.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
                letterSpacing: "0px",
              }}
            >
              Min
            </span>
          </span>
        </div>

        <div
          id="_3327_3289__Text_input"
          style={{
            position: "absolute",
            overflow: "hidden",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#dde1e3ff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "6px",
            height: "30.00px",
            width: "130.00px",
            left: "293.00px",
            top: "655.00px",
          }}
        >
          <span
            id="_3327_3290__Value"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "24.00px",
              width: "calc(100% - 24.00px)",
              position: "absolute",
              left: "12.00px",
              top: "4.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(154, 166, 172, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "14.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
                letterSpacing: "0px",
              }}
            >
              Max
            </span>
          </span>
        </div>

        <span
          id="_3327_3291__Salary_Range"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "95.00px",
            position: "absolute",
            left: "149.00px",
            top: "627.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "600",
              lineHeight: "14.00px",
            }}
          >
            Salary Range
          </span>
        </span>

        <img
          id="_3327_3292__Line_4"
          src="assets/searchimages/line_4.svg"
          alt="Line_4"
          style={{
            position: "absolute",
            transform: "scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "428.00px",
            top: "1002.00px",
          }}
        />
        <img
          id="_3327_3293__Line_7"
          src="assets/searchimages/line_7.svg"
          alt="Line_7"
          style={{
            position: "absolute",
            transform: "scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "428.00px",
            top: "737.00px",
          }}
        />
        <img
          id="_3327_3294__Line_6"
          src="assets/searchimages/line_6_1.svg"
          alt="Line_6"
          style={{
            position: "absolute",
            transform: "scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "428.00px",
            top: "1211.00px",
          }}
        />
        <div
          id="_3327_3315__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1279.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3316__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3317__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "177.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1284.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Fresher/Entry-Level (265)
          </span>
        </span>
        <div
          id="_3327_3318__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1307.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3319__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3320__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "72.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1312.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Junior (21)
          </span>
        </span>
        <div
          id="_3327_3321__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1335.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3322__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3323__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "105.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1340.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Mid-Level (212)
          </span>
        </span>
        <div
          id="_3327_3324__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "148.00px",
            top: "1363.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3325__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <div
          id="_3327_3326__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "149.00px",
            top: "1391.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3327__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <div
          id="_3327_3328__Box"
          style={{
            position: "absolute",
            height: "16.00px",
            width: "16.00px",
            left: "149.00px",
            top: "1419.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "4px 0px",
          }}
        >
          <div
            id="_3327_3329__Checkbox"
            style={{
              position: "relative",
              background: "rgba(246, 247, 248, 1.00)",
              borderColor: "#b0b9beff",
              borderStyle: "solid",
              borderWidth: "1px",
              borderRadius: "4px",
              height: "14.00px",
              width: "14.00px",
            }}
          ></div>
        </div>

        <span
          id="_3327_3330__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "73.00px",
            position: "absolute",
            left: "calc(50% - 568.50px)",
            top: "1368.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Senior (12)
          </span>
        </span>
        <span
          id="_3327_3331__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "154.00px",
            position: "absolute",
            left: "calc(50% - 567.50px)",
            top: "1396.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Lead/Managerial (24)
          </span>
        </span>
        <span
          id="_3327_3332__Title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "157.00px",
            position: "absolute",
            left: "calc(50% - 567.50px)",
            top: "1424.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "14.00px",
            }}
          >
            Director/Executive (10)
          </span>
        </span>

        <span
          id="_3327_3333__Experience_Level"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.00px",
            width: "117.00px",
            position: "absolute",
            left: "148.00px",
            top: "1250.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "600",
              lineHeight: "14.00px",
            }}
          >
            Experience Level
          </span>
        </span>

        <img
          id="_3327_3334__Line_5"
          src="assets/searchimages/line_5_1.svg"
          alt="Line_5"
          style={{
            position: "absolute",
            transform: "scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "428.00px",
            top: "1476.00px",
          }}
        />

        <span
          id="_3327_3335__Expand_all"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "14.00px",
            width: "83.00px",
            position: "absolute",
            left: "246.00px",
            top: "1646.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.0px",
              fontWeight: "500",
              lineHeight: "16.00px",
              textDecoration: "underline",
            }}
          >
            Expand all
          </span>
        </span>

        <span
          id="_3327_3336__View_more"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "16.00px",
            width: "129.00px",
            position: "absolute",
            left: "875.00px",
            top: "1775.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "500",
              lineHeight: "16.00px",
              textDecoration: "underline",
            }}
          >
            View more
          </span>
        </span>
        <span
          id="_3327_3338__Popular"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "17.00px",
            width: "63.00px",
            position: "absolute",
            left: "1207.00px",
            top: "509.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.031837463378906px",
              fontWeight: "500",
              lineHeight: "16.03px",
            }}
          >
            Popular
          </span>
        </span>

        <div
          id="_3327_3341__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "516.00px",
            top: "569.00px",
          }}
        ></div>

        <div
          id="_3327_3342__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "533.76px",
            top: "599.61px",
          }}
        ></div>

        <span
          id="_3327_3345__Google_Inc_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "16.98px",
            width: "95.00px",
            position: "absolute",
            left: "595.30px",
            top: "675.14px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.81928253173828px",
              fontWeight: "500",
              lineHeight: "16.82px",
            }}
          >
            Google Inc.
          </span>
        </span>
        <div
          id="_3327_3346__MapPin"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "18.90px",
            width: "18.78px",
            left: "592.42px",
            top: "700.34px",
          }}
        >
          <img
            id="I3327_3346_1502_72218__MapPin"
            src="assets/searchimages/mappin.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3327_3347__New_Delhi__India"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.99px",
            width: "116.00px",
            position: "absolute",
            left: "615.37px",
            top: "702.44px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            New Delhi, India
          </span>
        </span>

        <div
          id="_3327_3348__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "867.02px",
            top: "587.90px",
          }}
        >
          <img
            id="I3327_3348_1502_74271__BookmarkSimple"
            src="assets/searchimages/bookmarksimple.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3327_3350__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "533.83px",
            top: "621.51px",
          }}
        >
          <div
            id="_3327_3351__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "80.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3327_3352__Part-time"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "80.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Part-time
              </span>
            </span>
          </div>

          <span
            id="_3327_3353__Salary__20_000_INR_-"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "220.00px",
              position: "absolute",
              left: "96.71px",
              top: "4.20px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Salary: 20,000 INR - 25,000 INR
            </span>
          </span>
        </div>

        <span
          id="_3327_3354__Technical_Support_Sp"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "533.83px",
            top: "596.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Technical Support Specialist
          </span>
        </span>
        <div
          id="_3327_3355__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "53.49px",
            width: "58.50px",
            left: "533.85px",
            top: "667.06px",
          }}
        >
          <div
            id="_3327_3356__Employers_Logo"
            style={{
              position: "absolute",
              overflow: "hidden",
              height: "38.57px",
              width: "38.57px",
              left: "12.61px",
              top: "8.66px",
            }}
          >
            <img
              id="I3327_3356_132_14668__Vector"
              src="assets/searchimages/vector_67.svg"
              alt="Vector"
              style={{ position: "absolute", top: "calc(100% * 0.27)" }}
            />
            <img
              id="I3327_3356_132_14669__Vector"
              src="assets/searchimages/vector_68.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.51)",
                top: "calc(100% * 0.41)",
              }}
            />
            <img
              id="I3327_3356_132_14670__Vector"
              src="assets/searchimages/vector_69.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.06)",
                top: "calc(100% * 0.60)",
              }}
            />
            <img
              id="I3327_3356_132_14671__Vector"
              src="assets/searchimages/vector_70.svg"
              alt="Vector"
              style={{ position: "absolute", left: "calc(100% * 0.06)" }}
            />
          </div>
        </div>

        <img
          id="_3327_3358__Group_14041"
          src="assets/searchimages/group_14041.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.31)",
          }}
        />
        <span
          id="_3327_3363__10__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "92.86px",
            position: "absolute",
            left: "601.81px",
            top: "761.81px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            10+ applicants
          </span>
        </span>

        <div
          id="_3327_3365__Frame_13965"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "735.15px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3327_3366__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3327_3367__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "548.05px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3368__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3327_3371__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "969.24px",
            top: "569.00px",
          }}
        ></div>

        <div
          id="_3327_3372__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "987.29px",
            top: "599.61px",
          }}
        >
          <div
            id="_3327_3373__Frame_675"
            style={{
              position: "absolute",
              height: "36.79px",
              width: "344.80px",
              left: "-0.50px",
              top: "25.23px",
            }}
          >
            <div
              id="_3327_3374__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1536154747009277px",
                height: "15.41px",
                width: "74.82px",
                left: "0.00px",
                top: "0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3327_3375__Full-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "74.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.716872215270996px",
                    fontWeight: "600",
                    lineHeight: "14.72px",
                    textTransform: "uppercase",
                  }}
                >
                  Full-time
                </span>
              </span>
            </div>

            <span
              id="_3327_3376__Salary___30_000_-__5"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "185.00px",
                position: "absolute",
                left: "96.71px",
                top: "4.20px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "400",
                  lineHeight: "14.72px",
                }}
              >
                Salary: $30,000 - $55,000
              </span>
            </span>
          </div>

          <span
            id="_3327_3377__Senior_UI_UX_Designe"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "208.00px",
              position: "absolute",
              left: "-0.50px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.921693801879883px",
                fontWeight: "500",
                lineHeight: "18.92px",
              }}
            >
              Senior UI/UX Designer
            </span>
          </span>
        </div>

        <div
          id="_3327_3378__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "54.41px",
            width: "199.31px",
            left: "983.66px",
            top: "669.82px",
          }}
        >
          <div
            id="_3327_3379__apple-logo_1"
            style={{
              position: "absolute",
              background:
                "url(assets/searchimages/applelogo_1.png) 100% / cover no-repeat",
              height: "41.66px",
              width: "41.66px",
              left: "8.73px",
              top: "7.68px",
            }}
          ></div>

          <span
            id="_3327_3381__Apple"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "17.00px",
              width: "50.00px",
              position: "absolute",
              left: "64.92px",
              top: "7.29px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.81928253173828px",
                fontWeight: "500",
                lineHeight: "16.82px",
              }}
            >
              Apple
            </span>
          </span>
          <div
            id="_3327_3382__MapPin"
            style={{
              position: "absolute",
              height: "18.92px",
              width: "18.92px",
              left: "62.02px",
              top: "32.51px",
            }}
          >
            <img
              id="I3327_3382_1502_72218__MapPin"
              src="assets/searchimages/mappin_1.svg"
              alt="MapPin"
              style={{ position: "absolute" }}
            />
          </div>

          <span
            id="_3327_3383__Boston__USA"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "86.00px",
              position: "absolute",
              left: "85.15px",
              top: "34.62px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Boston, USA
            </span>
          </span>
        </div>

        <img
          id="_3327_3385__Group_14041"
          src="assets/searchimages/group_14041_1.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.66)",
            top: "calc(100% * 0.31)",
          }}
        />
        <span
          id="_3327_3390__9__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "88.69px",
            position: "absolute",
            left: "1067.77px",
            top: "765.11px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            9+ applicants
          </span>
        </span>

        <div
          id="_3327_3392__Frame_13965"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1187.39px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3327_3393__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3327_3394__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "1001.29px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3395__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3327_3396__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "25.75px",
            width: "29.75px",
            left: "1313.41px",
            top: "588.81px",
          }}
        >
          <img
            id="I3327_3396_1502_74271__BookmarkSimple"
            src="assets/searchimages/bookmarksimple_1.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3327_3399__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "516.00px",
            top: "1356.26px",
          }}
        ></div>

        <div
          id="_3327_3400__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "533.76px",
            top: "1386.87px",
          }}
        ></div>

        <span
          id="_3327_3403__Google_Inc_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "16.98px",
            width: "95.00px",
            position: "absolute",
            left: "595.30px",
            top: "1462.40px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.81928253173828px",
              fontWeight: "500",
              lineHeight: "16.82px",
            }}
          >
            Google Inc.
          </span>
        </span>
        <div
          id="_3327_3404__MapPin"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "18.90px",
            width: "18.78px",
            left: "592.42px",
            top: "1487.61px",
          }}
        >
          <img
            id="I3327_3404_1502_72218__MapPin"
            src="assets/searchimages/mappin_2.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3327_3405__New_Delhi__India"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.99px",
            width: "116.00px",
            position: "absolute",
            left: "615.37px",
            top: "1489.71px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            New Delhi, India
          </span>
        </span>

        <div
          id="_3327_3406__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "867.02px",
            top: "1375.17px",
          }}
        >
          <img
            id="I3327_3406_1502_74271__BookmarkSimple"
            src="assets/searchimages/bookmarksimple_2.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3327_3408__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "533.74px",
            top: "1408.77px",
          }}
        >
          <div
            id="_3327_3409__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "80.82px",
              left: "0.00px",
              top: "-0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3327_3410__Part-time"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "80.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Part-time
              </span>
            </span>
          </div>

          <span
            id="_3327_3411__Salary__20_000_INR_-"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "220.00px",
              position: "absolute",
              left: "96.71px",
              top: "4.20px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Salary: 20,000 INR - 25,000 INR
            </span>
          </span>
        </div>

        <span
          id="_3327_3412__Technical_Support_Sp"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "533.74px",
            top: "1383.57px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Technical Support Specialist
          </span>
        </span>
        <div
          id="_3327_3413__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "53.49px",
            width: "58.50px",
            left: "533.85px",
            top: "1454.33px",
          }}
        >
          <div
            id="_3327_3414__Employers_Logo"
            style={{
              position: "absolute",
              overflow: "hidden",
              height: "38.57px",
              width: "38.57px",
              left: "12.61px",
              top: "8.66px",
            }}
          >
            <img
              id="I3327_3414_132_14668__Vector"
              src="assets/searchimages/vector_71.svg"
              alt="Vector"
              style={{ position: "absolute", top: "calc(100% * 0.27)" }}
            />
            <img
              id="I3327_3414_132_14669__Vector"
              src="assets/searchimages/vector_72.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.51)",
                top: "calc(100% * 0.41)",
              }}
            />
            <img
              id="I3327_3414_132_14670__Vector"
              src="assets/searchimages/vector_73.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.06)",
                top: "calc(100% * 0.60)",
              }}
            />
            <img
              id="I3327_3414_132_14671__Vector"
              src="assets/searchimages/vector_74.svg"
              alt="Vector"
              style={{ position: "absolute", left: "calc(100% * 0.06)" }}
            />
          </div>
        </div>

        <img
          id="_3327_3416__Group_14041"
          src="assets/searchimages/group_14041_2.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.63)",
          }}
        />
        <span
          id="_3327_3421__10__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "92.86px",
            position: "absolute",
            left: "601.71px",
            top: "1549.07px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            10+ applicants
          </span>
        </span>

        <div
          id="_3327_3423__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "735.15px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3424__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3327_3425__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "548.05px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3426__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3327_3429__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "969.24px",
            top: "1356.26px",
          }}
        ></div>

        <div
          id="_3327_3430__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "987.29px",
            top: "1386.87px",
          }}
        >
          <div
            id="_3327_3431__Frame_675"
            style={{
              position: "absolute",
              height: "36.79px",
              width: "344.80px",
              left: "-0.50px",
              top: "25.23px",
            }}
          >
            <div
              id="_3327_3432__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1536154747009277px",
                height: "15.41px",
                width: "74.82px",
                left: "0.00px",
                top: "0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3327_3433__Full-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "74.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.716872215270996px",
                    fontWeight: "600",
                    lineHeight: "14.72px",
                    textTransform: "uppercase",
                  }}
                >
                  Full-time
                </span>
              </span>
            </div>

            <span
              id="_3327_3434__Salary___30_000_-__5"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "185.00px",
                position: "absolute",
                left: "96.71px",
                top: "4.20px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "400",
                  lineHeight: "14.72px",
                }}
              >
                Salary: $30,000 - $55,000
              </span>
            </span>
          </div>

          <span
            id="_3327_3435__Senior_UI_UX_Designe"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "208.00px",
              position: "absolute",
              left: "-0.50px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.921693801879883px",
                fontWeight: "500",
                lineHeight: "18.92px",
              }}
            >
              Senior UI/UX Designer
            </span>
          </span>
        </div>

        <div
          id="_3327_3436__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "54.41px",
            width: "199.31px",
            left: "983.66px",
            top: "1457.08px",
          }}
        >
          <div
            id="_3327_3437__apple-logo_1"
            style={{
              position: "absolute",
              background: "url(assets/searchimages/null) 100% / cover no-repeat",
              height: "41.66px",
              width: "41.66px",
              left: "8.73px",
              top: "7.68px",
            }}
          ></div>

          <span
            id="_3327_3439__Apple"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "17.00px",
              width: "50.00px",
              position: "absolute",
              left: "64.92px",
              top: "7.29px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.81928253173828px",
                fontWeight: "500",
                lineHeight: "16.82px",
              }}
            >
              Apple
            </span>
          </span>
          <div
            id="_3327_3440__MapPin"
            style={{
              position: "absolute",
              height: "18.92px",
              width: "18.92px",
              left: "62.02px",
              top: "32.51px",
            }}
          >
            <img
              id="I3327_3440_1502_72218__MapPin"
              src="assets/searchimages/mappin_3.svg"
              alt="MapPin"
              style={{ position: "absolute" }}
            />
          </div>

          <span
            id="_3327_3441__Boston__USA"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "86.00px",
              position: "absolute",
              left: "85.15px",
              top: "34.62px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Boston, USA
            </span>
          </span>
        </div>

        <img
          id="_3327_3443__Group_14041"
          src="assets/searchimages/group_14041_3.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.66)",
            top: "calc(100% * 0.63)",
          }}
        />
        <span
          id="_3327_3448__9__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "88.69px",
            position: "absolute",
            left: "1067.77px",
            top: "1552.37px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            9+ applicants
          </span>
        </span>

        <div
          id="_3327_3450__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1187.39px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3451__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3327_3452__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "1001.29px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3453__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3327_3454__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "25.75px",
            width: "29.75px",
            left: "1313.41px",
            top: "1376.07px",
          }}
        >
          <img
            id="I3327_3454_1502_74271__BookmarkSimple"
            src="assets/searchimages/bookmarksimple_3.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3327_3459__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "965.45px",
            top: "962.63px",
          }}
        ></div>

        <div
          id="_3327_3460__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "983.50px",
            top: "993.24px",
          }}
        >
          <div
            id="_3327_3461__Frame_675"
            style={{
              position: "absolute",
              height: "36.79px",
              width: "344.80px",
              left: "-0.50px",
              top: "25.23px",
            }}
          >
            <div
              id="_3327_3462__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1536154747009277px",
                height: "15.41px",
                width: "74.82px",
                left: "0.00px",
                top: "-0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3327_3463__Full-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "74.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.716872215270996px",
                    fontWeight: "600",
                    lineHeight: "14.72px",
                    textTransform: "uppercase",
                  }}
                >
                  Full-time
                </span>
              </span>
            </div>

            <span
              id="_3327_3464__Salary___30_000_-__5"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "185.00px",
                position: "absolute",
                left: "96.71px",
                top: "4.20px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "400",
                  lineHeight: "14.72px",
                }}
              >
                Salary: $30,000 - $55,000
              </span>
            </span>
          </div>

          <span
            id="_3327_3465__Senior_UI_UX_Designe"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "208.00px",
              position: "absolute",
              left: "-0.50px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.921693801879883px",
                fontWeight: "500",
                lineHeight: "18.92px",
              }}
            >
              Senior UI/UX Designer
            </span>
          </span>
        </div>

        <div
          id="_3327_3466__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "54.41px",
            width: "199.31px",
            left: "979.87px",
            top: "1063.45px",
          }}
        >
          <div
            id="_3327_3467__apple-logo_1"
            style={{
              position: "absolute",
              background: "url(assets/searchimages/null) 100% / cover no-repeat",
              height: "41.66px",
              width: "41.66px",
              left: "8.73px",
              top: "7.68px",
            }}
          ></div>

          <span
            id="_3327_3469__Apple"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "17.00px",
              width: "50.00px",
              position: "absolute",
              left: "64.92px",
              top: "7.29px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.81928253173828px",
                fontWeight: "500",
                lineHeight: "16.82px",
              }}
            >
              Apple
            </span>
          </span>
          <div
            id="_3327_3470__MapPin"
            style={{
              position: "absolute",
              height: "18.92px",
              width: "18.92px",
              left: "62.02px",
              top: "32.51px",
            }}
          >
            <img
              id="I3327_3470_1502_72218__MapPin"
              src="assets/searchimages/mappin_4.svg"
              alt="MapPin"
              style={{ position: "absolute" }}
            />
          </div>

          <span
            id="_3327_3471__Boston__USA"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "86.00px",
              position: "absolute",
              left: "85.15px",
              top: "34.62px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Boston, USA
            </span>
          </span>
        </div>

        <img
          id="_3327_3473__Group_14041"
          src="assets/searchimages/group_14041_4.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.66)",
            top: "calc(100% * 0.47)",
          }}
        />
        <span
          id="_3327_3478__9__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "88.69px",
            position: "absolute",
            left: "1063.97px",
            top: "1158.74px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            9+ applicants
          </span>
        </span>

        <div
          id="_3327_3480__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1183.60px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3481__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3327_3482__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "997.50px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3327_3483__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3327_3484__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "25.75px",
            width: "29.75px",
            left: "1309.61px",
            top: "982.44px",
          }}
        >
          <img
            id="I3327_3484_1502_74271__BookmarkSimple"
            src="assets/searchimages/bookmarksimple_4.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3327_3486__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0338482856750488px",
            borderRadius: "15px",
            height: "311.93px",
            width: "376.69px",
            left: "519.15px",
            top: "962.63px",
          }}
        ></div>

        <div
          id="_3327_3487__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "536.45px",
            top: "993.24px",
          }}
        >
          <div
            id="_3327_3488__Frame_675"
            style={{
              position: "absolute",
              height: "36.18px",
              width: "339.10px",
              left: "0.07px",
              top: "24.81px",
            }}
          >
            <div
              id="_3327_3489__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1015446186065674px",
                height: "15.27px",
                width: "79.54px",
                left: "-0.00px",
                top: "-0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3327_3490__Part-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "79.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.47387409210205px",
                    fontWeight: "600",
                    lineHeight: "14.47px",
                    textTransform: "uppercase",
                  }}
                >
                  Part-time
                </span>
              </span>
            </div>

            <span
              id="_3327_3491__Salary__15_000_INR_-"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "213.00px",
                position: "absolute",
                left: "95.11px",
                top: "4.14px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.47387409210205px",
                  fontWeight: "400",
                  lineHeight: "14.47px",
                }}
              >
                Salary: 15,000 INR - 35,000 INR
              </span>
            </span>
          </div>

          <span
            id="_3327_3492__Marketing_Officer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "161.00px",
              position: "absolute",
              left: "0.07px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.60926628112793px",
                fontWeight: "500",
                lineHeight: "18.61px",
              }}
            >
              Marketing Officer
            </span>
          </span>
        </div>

        <img
          id="_3327_3494__Group_14049"
          src="assets/searchimages/group_14049.svg"
          alt="Group_14049"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.56)",
          }}
        />
        <span
          id="_3327_3505__Intel_Corp"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "17.12px",
            width: "82.43px",
            position: "absolute",
            left: "604.09px",
            top: "1068.70px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.54157257080078px",
              fontWeight: "500",
              lineHeight: "16.54px",
            }}
          >
            Intel Corp
          </span>
        </span>
        <div
          id="_3327_3506__MapPin"
          style={{
            position: "absolute",
            borderRadius: "14.999999046325684px",
            height: "18.90px",
            width: "18.78px",
            left: "601.21px",
            top: "1093.90px",
          }}
        >
          <img
            id="I3327_3506_1502_72218__MapPin"
            src="assets/searchimages/mappin_5.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3327_3507__Bangalore__India"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "15.11px",
            width: "118.95px",
            position: "absolute",
            left: "624.16px",
            top: "1096.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.47387409210205px",
              fontWeight: "400",
              lineHeight: "14.47px",
            }}
          >
            Bangalore, India
          </span>
        </span>

        <img
          id="_3327_3509__Group_14041"
          src="assets/searchimages/group_14041_5.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.47)",
          }}
        />
        <span
          id="_3327_3514__30__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "95.99px",
            position: "absolute",
            left: "604.49px",
            top: "1158.74px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.40617847442627px",
              fontWeight: "500",
              lineHeight: "12.41px",
            }}
          >
            30+ applicants
          </span>
        </span>

        <div
          id="_3327_3516__Frame_13965"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "0.81px",
            width: "34.08px",
            left: "737.26px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 54px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3327_3517__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "78.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.47387409210205px",
                fontWeight: "600",
                lineHeight: "14.47px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3327_3518__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0338482856750488px",
            borderRadius: "15px",
            height: "-1.26px",
            width: "32.01px",
            left: "550.16px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 54px",
          }}
        >
          <span
            id="_3327_3519__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "90.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.47387409210205px",
                fontWeight: "600",
                lineHeight: "14.47px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3327_3520__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.25px",
            width: "31.47px",
            left: "863.62px",
            top: "981.28px",
          }}
        >
          <img
            id="I3327_3520_1502_74271__BookmarkSimple"
            src="assets/searchimages/bookmarksimple_5.svg"
            alt="BookmarkSimple"
            style={{
              position: "absolute",
              left: "calc(100% * 0.25)",
              top: "calc(100% * 0.16)",
            }}
          />
        </div>

        <img
          id="_3327_3539__Arrow_3"
          src="assets/searchimages/arrow_3.svg"
          alt="Arrow_3"
          style={{
            position: "absolute",
            left: "calc(100% * 0.28)",
            top: "calc(100% * 0.41)",
          }}
        />
        <img
          id="_3327_3540__Arrow_2"
          src="assets/searchimages/arrow_2.svg"
          alt="Arrow_2"
          style={{
            position: "absolute",
            left: "calc(100% * 0.89)",
            top: "calc(100% * 0.27)",
          }}
        />
        <img
          id="_3327_3542__Arrows"
          src="assets/searchimages/arrows.svg"
          alt="Arrows"
          style={{
            position: "absolute",
            left: "calc(100% * 0.15)",
            top: "calc(100% * 0.55)",
          }}
        />
        <div
          id="_3329_864__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "74.34px",
            width: "1440.00px",
            left: "0.00px",
            top: "0.00px",
          }}
        ></div>

        <div
          id="_3406_675__Frame_11"
          onClick={() => navigate("/ResumeGenerationPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "26.00px",
            width: "209.00px",
            left: "1144.00px",
            top: "12.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3406_676__Generate_Resume"
            onClick={() => navigate("/ResumeGenerationPage")}
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "173.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Generate Resume
            </span>
          </span>
          <img
            id="_3406_677__Group"
            src="assets/searchimages/group_25.svg"
            alt="Group"
            style={{ position: "relative" }}
          />
        </div>

        <div
          id="_3329_901__Frame_27"
          style={{
            position: "absolute",
            height: "41.76px",
            width: "343.50px",
            left: "calc(50% - 171.50px)",
            top: "16.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3329_902__Frame_5"
            onClick={() => navigate("/")}
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3329_903__Home"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </span>
          </div>

          <div
            id="_3329_904__Frame_4"
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3329_905__Jobs"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </span>
          </div>

          <div
            id="_3329_906__Frame_3"
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3329_907__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>

          <div
            id="_3329_908__Frame_10"
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>

        <span
          id="_3329_912__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "27.56px",
            width: "51.68px",
            position: "absolute",
            left: "39.00px",
            top: "28.18px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job&nbsp;
          </span>
        </span>
        <span
          id="_3329_913__Fiesta"
          onClick={() => navigate("/")}
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "28.00px",
            width: "131.00px",
            position: "absolute",
            left: "85.00px",
            top: "24.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>

        <div
          id="_3377_2696__Frame_53"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "75.00px",
            width: "80.00px",
            left: "1402.00px",
            top: "4.00px",
          }}
        >
          <img
            id="_3377_2697__Group_6"
            src="assets/searchimages/group_6_1.svg"
            alt="Group_6"
            onClick={() => navigate("/AccountsettingsPage")}
            style={{
              position: "absolute",
              left: "calc(100% * 0.01)",
              top: "calc(100% * 0.01)",
              cursor: "pointer",
            }}
          />
        </div>
      </div>
    </>
  );
};
export default SearchPage;
