require('dotenv').config();
  const express = require('express');
  const cors = require('cors');
  const mongoose = require('mongoose');
  const http = require('http');
  const { Server } = require('socket.io');
  const authRoutes = require('./routes/auth');
  const jobRoutes = require('./routes/jobs');
  const applicationRoutes = require('./routes/applications');
  const conversationRoutes = require('./routes/conversations');
  const ratingRoutes = require('./routes/ratings');
  const recommendationRoutes = require('./routes/recommendations');
  const resumeRoutes = require('./routes/resume');
  const Message = require('./models/Message');
  const Conversation = require('./models/Conversation');

  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, {
    cors: {
      origin: 'http://localhost:3000', // Replace with your React frontend URL
      methods: ['GET', 'POST']
    }
  });

  const PORT = process.env.PORT || 5000;

  // Middleware
  app.use(cors({ origin: 'http://localhost:3000' }));
  app.use(express.json());

  // MongoDB Connection
  mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

  // Socket.IO Events
  io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    socket.on('joinConversation', ({ conversationId, userId }) => {
      socket.join(conversationId);
      console.log(`User ${userId} joined conversation ${conversationId}`);
    });

    socket.on('sendMessage', async ({ conversationId, senderId, receiverId, content }) => {
      try {
        const message = new Message({
          conversationId,
          senderId,
          receiverId,
          content,
          timestamp: new Date()
        });
        await message.save();

        await Conversation.findByIdAndUpdate(conversationId, {
          lastMessage: message._id
        });

        io.to(conversationId).emit('receiveMessage', {
          conversationId,
          senderId,
          content,
          timestamp: message.timestamp
        });
      } catch (error) {
        console.error('Error saving message:', error);
      }
    });

    socket.on('disconnect', () => {
      console.log(`User disconnected: ${socket.id}`);
    });
  });

  // Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/jobs', jobRoutes);
  app.use('/api/applications', applicationRoutes);
  app.use('/api/conversations', conversationRoutes);
  app.use('/api/ratings', ratingRoutes);
  app.use('/api/recommendations', recommendationRoutes);
  app.use('/api/resume', resumeRoutes);

  app.get('/api', (req, res) => {
    res.json({ message: 'Welcome to the backend API!' });
  });

  server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });