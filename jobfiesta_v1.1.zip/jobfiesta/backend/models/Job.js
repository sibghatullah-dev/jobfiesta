const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  skillsRequired: [{ type: String, required: true }],
  location: { type: String, required: true },
  salary: { type: Number },
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
  roleType: { type: String },
  companyName: { type: String },
  workEnvironment: { type: String },
  applicationProcess: { type: String },
  maritalStatus: { type: String },
  gender: { type: String },
  jobType: { type: String },
  jobBenefits: { type: String },
  applicationDeadline: { type: String },
  experienceLevel: { type: String },
  termsAndConditions: { type: String }
});