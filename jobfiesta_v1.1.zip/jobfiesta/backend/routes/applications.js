const express = require('express');
const router = express.Router();
const Application = require('../models/Application');
const Job = require('../models/Job');
const { authenticate, restrictTo } = require('../middleware/auth');

// Submit Application (Job Seeker only)
router.post('/', authenticate, restrictTo('jobseeker'), async (req, res) => {
  try {
    const { jobId } = req.body;
    const existingApplication = await Application.findOne({
      jobId,
      jobSeekerId: req.user.userId
    });
    if (existingApplication) {
      return res.status(400).json({ message: 'Already applied to this job' });
    }
    const application = new Application({
      jobId,
      jobSeekerId: req.user.userId
    });
    await application.save();
    res.status(201).json({ message: 'Application submitted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get User Applications (Job Seeker only)
router.get('/', authenticate, restrictTo('jobseeker'), async (req, res) => {
  try {
    const applications = await Application.find({ jobSeekerId: req.user.userId })
      .populate('jobId', 'title');
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get Applications for a Job (Recruiter only)
router.get('/:id/applications', authenticate, restrictTo('recruiter'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job || job.postedBy.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }
    const applications = await Application.find({ jobId: req.params.id })
      .populate('jobSeekerId', 'name skills');
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;    