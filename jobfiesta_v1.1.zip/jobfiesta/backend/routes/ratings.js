const express = require('express');
  const router = express.Router();
  const Rating = require('../models/Rating');
  const Message = require('../models/Message');
  const { authenticate, restrictTo } = require('../middleware/auth');

  // Submit Rating (Recruiter only)
  router.post('/', authenticate, restrictTo('recruiter'), async (req, res) => {
    try {
      const { jobSeekerId, rating, review } = req.body;

      // Check message count
      const conversation = await Conversation.findOne({
        participants: { $all: [req.user.userId, jobSeekerId] }
      });
      if (!conversation) {
        return res.status(400).json({ message: 'No conversation found' });
      }
      const messages = await Message.find({ conversationId: conversation._id });
      const jobSeekerMessages = messages.filter(m => m.senderId.toString() === jobSeekerId).length;
      const recruiterMessages = messages.filter(m => m.senderId.toString() === req.user.userId).length;
      if (jobSeekerMessages < 5 || recruiterMessages < 5) {
        return res.status(400).json({ message: 'Minimum 5 messages required from each participant' });
      }

      const newRating = new Rating({
        jobSeekerId,
        recruiterId: req.user.userId,
        rating,
        review
      });
      await newRating.save();
      res.status(201).json({ message: 'Rating submitted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Get Ratings for a Job Seeker
  router.get('/:jobSeekerId', async (req, res) => {
    try {
      const ratings = await Rating.find({ jobSeekerId: req.params.jobSeekerId })
        .populate('recruiterId', 'companyName');
      res.json(ratings);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  module.exports = router;