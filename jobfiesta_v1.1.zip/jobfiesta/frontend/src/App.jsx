import React from 'react';
  import { Routes, Route } from 'react-router-dom';
  import { AuthProvider } from './context/AuthContext.jsx';
  import { SocketProvider } from './context/SocketContext.jsx';
  import ErrorBoundary from './components/errorboundary.jsx';
  import LandingPage from './pages/LandingPage.jsx';
  import ChatInterface1 from './pages/ChatInterface1.jsx';
  import ChatInterface2 from './pages/ChatInterface2.jsx';
  import RecruiterDashBoardPage from './pages/RecruiterDashBoardPage.jsx';
  import RegistrationForjobseekerPage from './pages/RegistrationForjobseekerPage.jsx';
  import JobdetailsPage from './pages/JobdetailsPage.jsx';
  import AccountsettingsPage from './pages/AccountsettingsPage.jsx';
  import ChatMainPage from './pages/ChatMainPage.jsx';
  import Loginpage from './pages/Loginpage.jsx';
  import PostJobPage from './pages/PostJobPage.jsx';
  import JobSeekerDashBoardPage from './pages/JobSeekerDashBoardPage.jsx';
  import SearchPage from './pages/SearchPage.jsx';
  import ViewApplicationsPage from './pages/ViewApplicationsPage.jsx';
  import ResumeGenerationPage from './pages/ResumeGenerationPage.jsx';
  //import ResumeComponent from './components/ResumeComponent.jsx';

  function App() {
    return (
      <ErrorBoundary>
        <AuthProvider>
          <SocketProvider userId={localStorage.getItem('userId')}>
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<Loginpage />} />
              <Route path="/post-job" element={<PostJobPage />} />
              <Route path="/recruiter-dashboard" element={<RecruiterDashBoardPage />} />
              <Route path="/register-jobseeker" element={<RegistrationForjobseekerPage />} />
              <Route path="/job-details" element={<JobdetailsPage />} />
              <Route path="/account-settings" element={<AccountsettingsPage />} />
              <Route path="/chat-main" element={<ChatMainPage />} />
              <Route path="/chat-interface1" element={<ChatInterface1 />} />
              <Route path="/chat-interface2" element={<ChatInterface2 />} />
              <Route path="/jobseeker-dashboard" element={<JobSeekerDashBoardPage />} />
              <Route path="/SearchPage" element={<SearchPage />} />
              <Route path="/ViewApplicationsPage" element={<ViewApplicationsPage />} />
              <Route path="/ResumeGenerationPage" element={<ResumeGenerationPage />} />
              {/* <Route path="/ViewApplicationsPage" element={<ViewApplicationsPage />} />
              <Route path="/ViewApplicationsPage" element={<ViewApplicationsPage />} />
              <Route path="/ViewApplicationsPage" element={<ViewApplicationsPage />} /> */}
              {/* <Route path="/resume" element={<ResumeComponent />} /> */}
              <Route path="*" element={<div>Page not found</div>} />
            </Routes>
            <div style={{ color: 'red' }}>App is running!</div> {/* Debug */}
          </SocketProvider>
        </AuthProvider>
      </ErrorBoundary>
    );
  }

  export default App;