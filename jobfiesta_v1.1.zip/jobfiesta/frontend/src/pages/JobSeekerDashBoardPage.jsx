import { useNavigate } from "react-router-dom";
import React from "react";

const JobSeekerDashBoardPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <div
        id="_3362_5405__Job_Seeker_DashBoard"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          height: "2460.0px",
          width: "100%",
        }}
      >
        <div
          id="_3362_5408__Rectangle_34625586"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "1.5665795803070068px",
            borderRadius: "50px",
            height: "83.87px",
            width: "1196.87px",
            left: "120.00px",
            top: "319.00px",
          }}
        ></div>

        <div
          id="_3362_5410__Frame_13966"
          onClick={() => navigate("/SearchPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "15.54px",
            width: "37.88px",
            left: "1193.00px",
            top: "335.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 53px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5411__Search"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "16.00px",
              width: "58.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.0px",
                fontWeight: "600",
                lineHeight: "16.00px",
              }}
            >
              Search
            </span>
          </span>
        </div>

        <img
          id="_3362_5413__Line_5"
          src="assets/images/line_5_2.svg"
          alt="Line_5"
          style={{
            position: "absolute",
            transform: "rotate(-90.00deg) scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "362.00px",
            top: "343.00px",
          }}
        />
        <img
          id="_3362_5414__Line_6"
          src="assets/images/line_6_2.svg"
          alt="Line_6"
          style={{
            position: "absolute",
            transform: "rotate(-90.00deg) scale(-1.0, -1.0)",
            transformOrigin: "0 0",
            left: "806.00px",
            top: "339.33px",
          }}
        />
        <span
          id="_3362_5418__Enter_Job_title"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "20.00px",
            width: "135.00px",
            position: "absolute",
            left: "195.00px",
            top: "354.33px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(127, 127, 127, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "400",
              lineHeight: "20.00px",
            }}
          >
            Enter Job title
          </span>
        </span>

        <img
          id="_3362_5419__Vector"
          src="assets/images/vector_98.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.12)",
            top: "calc(100% * 0.19)",
          }}
        />

        <span
          id="_3362_5423__Enter_location"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "19.83px",
            width: "137.00px",
            position: "absolute",
            left: "645.00px",
            top: "351.92px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(127, 127, 127, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "400",
              lineHeight: "20.00px",
            }}
          >
            Enter location
          </span>
        </span>

        <img
          id="_3362_5424__Vector"
          src="assets/images/vector_99.svg"
          alt="Vector"
          style={{
            position: "absolute",
            left: "calc(100% * 0.42)",
            top: "calc(100% * 0.19)",
          }}
        />

        <div
          id="_3362_5426__Rectangle_34625589"
          style={{
            position: "absolute",
            borderColor: "#f2f2f2ff",
            borderStyle: "solid",
            borderWidth: "2px",
            borderRadius: "10px",
            height: "45.00px",
            width: "169.00px",
            left: "1189.00px",
            top: "493.00px",
          }}
        ></div>

        <span
          id="_3362_5429__Job_Search"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "268.00px",
            position: "absolute",
            left: "calc(50% - 621.00px)",
            top: "187.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Job Search
          </span>
        </span>
        <span
          id="_3362_5430__Search_for_your_desi"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "22.00px",
            width: "520.00px",
            position: "absolute",
            left: "calc(50% - 621.00px)",
            top: "252.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            Search for your desired job matching your skills
          </span>
        </span>

        <span
          id="_3362_5433__Top_Jobs"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "24.00px",
            width: "110.00px",
            position: "absolute",
            left: "calc(50% - 245.00px)",
            top: "505.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "600",
              lineHeight: "24.00px",
            }}
          >
            Top Jobs&nbsp;
          </span>
        </span>
        <span
          id="_3362_5434__Clear_all"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "0.48%",
            width: "59.00px",
            position: "absolute",
            left: "calc(50% - 379.00px)",
            top: "calc(100% * 0.27)",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(127, 127, 127, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "500",
              lineHeight: "11.00px",
            }}
          >
            Clear all
          </span>
        </span>

        <span
          id="_3362_5500__View_more"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "center",
            height: "16.00px",
            width: "129.00px",
            position: "absolute",
            left: "875.00px",
            top: "1775.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "500",
              lineHeight: "16.00px",
              textDecoration: "underline",
            }}
          >
            View more
          </span>
        </span>
        <span
          id="_3362_5502__Popular"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "17.00px",
            width: "63.00px",
            position: "absolute",
            left: "1208.00px",
            top: "509.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.031837463378906px",
              fontWeight: "500",
              lineHeight: "16.03px",
            }}
          >
            Popular
          </span>
        </span>

        <div
          id="_3362_5505__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "516.00px",
            top: "569.00px",
          }}
        ></div>

        <div
          id="_3362_5506__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "533.76px",
            top: "599.61px",
          }}
        ></div>

        <span
          id="_3362_5509__Google_Inc_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "16.98px",
            width: "95.00px",
            position: "absolute",
            left: "595.30px",
            top: "675.14px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.81928253173828px",
              fontWeight: "500",
              lineHeight: "16.82px",
            }}
          >
            Google Inc.
          </span>
        </span>
        <div
          id="_3362_5510__MapPin"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "18.90px",
            width: "18.78px",
            left: "592.42px",
            top: "700.34px",
          }}
        >
          <img
            id="I3362_5510_1502_72218__MapPin"
            src="assets/images/mappin_6.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3362_5511__New_Delhi__India"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.99px",
            width: "116.00px",
            position: "absolute",
            left: "615.37px",
            top: "702.44px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            New Delhi, India
          </span>
        </span>

        <div
          id="_3362_5512__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "867.02px",
            top: "587.90px",
          }}
        >
          <img
            id="I3362_5512_1502_74271__BookmarkSimple"
            src="assets/images/bookmarksimple_6.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_5514__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "533.83px",
            top: "621.51px",
          }}
        >
          <div
            id="_3362_5515__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "80.82px",
              left: "0.00px",
              top: "0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3362_5516__Part-time"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "80.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Part-time
              </span>
            </span>
          </div>

          <span
            id="_3362_5517__Salary__20_000_INR_-"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "220.00px",
              position: "absolute",
              left: "96.71px",
              top: "4.20px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Salary: 20,000 INR - 25,000 INR
            </span>
          </span>
        </div>

        <span
          id="_3362_5518__Technical_Support_Sp"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "533.83px",
            top: "596.30px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Technical Support Specialist
          </span>
        </span>
        <div
          id="_3362_5519__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "53.49px",
            width: "58.50px",
            left: "533.85px",
            top: "667.06px",
          }}
        >
          <div
            id="_3362_5520__Employers_Logo"
            style={{
              position: "absolute",
              overflow: "hidden",
              height: "38.57px",
              width: "38.57px",
              left: "12.61px",
              top: "8.66px",
            }}
          >
            <img
              id="I3362_5520_132_14668__Vector"
              src="assets/images/vector_100.svg"
              alt="Vector"
              style={{ position: "absolute", top: "calc(100% * 0.27)" }}
            />
            <img
              id="I3362_5520_132_14669__Vector"
              src="assets/images/vector_101.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.51)",
                top: "calc(100% * 0.41)",
              }}
            />
            <img
              id="I3362_5520_132_14670__Vector"
              src="assets/images/vector_102.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.06)",
                top: "calc(100% * 0.60)",
              }}
            />
            <img
              id="I3362_5520_132_14671__Vector"
              src="assets/images/vector_103.svg"
              alt="Vector"
              style={{ position: "absolute", left: "calc(100% * 0.06)" }}
            />
          </div>
        </div>

        <img
          id="_3362_5522__Group_14041"
          src="assets/images/group_14041_6.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.31)",
          }}
        />
        <span
          id="_3362_5527__10__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "92.86px",
            position: "absolute",
            left: "601.81px",
            top: "761.81px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            10+ applicants
          </span>
        </span>

        <div
          id="_3362_5529__Frame_13965"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "735.15px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5530__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3362_5531__Frame_13966"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "548.05px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5532__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3362_5535__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "969.24px",
            top: "569.00px",
          }}
        ></div>

        <div
          id="_3362_5536__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "987.29px",
            top: "599.61px",
          }}
        >
          <div
            id="_3362_5537__Frame_675"
            style={{
              position: "absolute",
              height: "36.79px",
              width: "344.80px",
              left: "-0.50px",
              top: "25.23px",
            }}
          >
            <div
              id="_3362_5538__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1536154747009277px",
                height: "15.41px",
                width: "74.82px",
                left: "0.00px",
                top: "0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3362_5539__Full-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "74.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.716872215270996px",
                    fontWeight: "600",
                    lineHeight: "14.72px",
                    textTransform: "uppercase",
                  }}
                >
                  Full-time
                </span>
              </span>
            </div>

            <span
              id="_3362_5540__Salary___30_000_-__5"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "185.00px",
                position: "absolute",
                left: "96.71px",
                top: "4.20px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "400",
                  lineHeight: "14.72px",
                }}
              >
                Salary: $30,000 - $55,000
              </span>
            </span>
          </div>

          <span
            id="_3362_5541__Senior_UI_UX_Designe"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "208.00px",
              position: "absolute",
              left: "-0.50px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.921693801879883px",
                fontWeight: "500",
                lineHeight: "18.92px",
              }}
            >
              Senior UI/UX Designer
            </span>
          </span>
        </div>

        <div
          id="_3362_5542__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "54.41px",
            width: "199.31px",
            left: "983.66px",
            top: "669.82px",
          }}
        >
          <div
            id="_3362_5543__apple-logo_1"
            style={{
              position: "absolute",
              background: "url(assets/images/null) 100% / cover no-repeat",
              height: "41.66px",
              width: "41.66px",
              left: "8.73px",
              top: "7.68px",
            }}
          ></div>

          <span
            id="_3362_5545__Apple"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "17.00px",
              width: "50.00px",
              position: "absolute",
              left: "64.92px",
              top: "7.29px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.81928253173828px",
                fontWeight: "500",
                lineHeight: "16.82px",
              }}
            >
              Apple
            </span>
          </span>
          <div
            id="_3362_5546__MapPin"
            style={{
              position: "absolute",
              height: "18.92px",
              width: "18.92px",
              left: "62.02px",
              top: "32.51px",
            }}
          >
            <img
              id="I3362_5546_1502_72218__MapPin"
              src="assets/images/mappin_7.svg"
              alt="MapPin"
              style={{ position: "absolute" }}
            />
          </div>

          <span
            id="_3362_5547__Boston__USA"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "86.00px",
              position: "absolute",
              left: "85.15px",
              top: "34.62px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Boston, USA
            </span>
          </span>
        </div>

        <img
          id="_3362_5549__Group_14041"
          src="assets/images/group_14041_7.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.66)",
            top: "calc(100% * 0.31)",
          }}
        />
        <span
          id="_3362_5554__9__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "88.69px",
            position: "absolute",
            left: "1068.77px",
            top: "765.11px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            9+ applicants
          </span>
        </span>

        <div
          id="_3362_5556__Frame_13965"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1188.39px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5557__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3362_5558__Frame_13966"
          onClick={() => navigate("/JobdetailsPage")}
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "1001.29px",
            top: "817.89px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5559__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3362_5560__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "25.75px",
            width: "29.75px",
            left: "1314.41px",
            top: "588.81px",
          }}
        >
          <img
            id="I3362_5560_1502_74271__BookmarkSimple"
            src="assets/images/bookmarksimple_7.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_5563__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "516.00px",
            top: "1356.26px",
          }}
        ></div>

        <div
          id="_3362_5564__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "533.76px",
            top: "1386.87px",
          }}
        ></div>

        <span
          id="_3362_5567__Google_Inc_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "16.98px",
            width: "95.00px",
            position: "absolute",
            left: "595.30px",
            top: "1462.40px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.81928253173828px",
              fontWeight: "500",
              lineHeight: "16.82px",
            }}
          >
            Google Inc.
          </span>
        </span>
        <div
          id="_3362_5568__MapPin"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "18.90px",
            width: "18.78px",
            left: "592.42px",
            top: "1487.61px",
          }}
        >
          <img
            id="I3362_5568_1502_72218__MapPin"
            src="assets/images/mappin_8.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3362_5569__New_Delhi__India"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "14.99px",
            width: "116.00px",
            position: "absolute",
            left: "615.37px",
            top: "1489.71px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.716872215270996px",
              fontWeight: "400",
              lineHeight: "14.72px",
            }}
          >
            New Delhi, India
          </span>
        </span>

        <div
          id="_3362_5570__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.30px",
            width: "31.30px",
            left: "867.02px",
            top: "1375.17px",
          }}
        >
          <img
            id="I3362_5570_1502_74271__BookmarkSimple"
            src="assets/images/bookmarksimple_8.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_5572__Frame_675"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "36.76px",
            width: "342.24px",
            left: "533.74px",
            top: "1408.77px",
          }}
        >
          <div
            id="_3362_5573__Type"
            style={{
              position: "absolute",
              background: "rgba(231, 246, 234, 1.00)",
              borderRadius: "3.1536154747009277px",
              height: "15.41px",
              width: "80.82px",
              left: "0.00px",
              top: "-0.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "4px 8px",
            }}
          >
            <span
              id="_3362_5574__Part-time"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "80.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(11, 160, 44, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "600",
                  lineHeight: "14.72px",
                  textTransform: "uppercase",
                }}
              >
                Part-time
              </span>
            </span>
          </div>

          <span
            id="_3362_5575__Salary__20_000_INR_-"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "220.00px",
              position: "absolute",
              left: "96.71px",
              top: "4.20px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Salary: 20,000 INR - 25,000 INR
            </span>
          </span>
        </div>

        <span
          id="_3362_5576__Technical_Support_Sp"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "18.98px",
            width: "271.00px",
            position: "absolute",
            left: "533.74px",
            top: "1383.57px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(24, 25, 28, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "18.921693801879883px",
              fontWeight: "500",
              lineHeight: "18.92px",
            }}
          >
            Technical Support Specialist
          </span>
        </span>
        <div
          id="_3362_5577__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "53.49px",
            width: "58.50px",
            left: "533.85px",
            top: "1454.33px",
          }}
        >
          <div
            id="_3362_5578__Employers_Logo"
            style={{
              position: "absolute",
              overflow: "hidden",
              height: "38.57px",
              width: "38.57px",
              left: "12.61px",
              top: "8.66px",
            }}
          >
            <img
              id="I3362_5578_132_14668__Vector"
              src="assets/images/vector_104.svg"
              alt="Vector"
              style={{ position: "absolute", top: "calc(100% * 0.27)" }}
            />
            <img
              id="I3362_5578_132_14669__Vector"
              src="assets/images/vector_105.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.51)",
                top: "calc(100% * 0.41)",
              }}
            />
            <img
              id="I3362_5578_132_14670__Vector"
              src="assets/images/vector_106.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.06)",
                top: "calc(100% * 0.60)",
              }}
            />
            <img
              id="I3362_5578_132_14671__Vector"
              src="assets/images/vector_107.svg"
              alt="Vector"
              style={{ position: "absolute", left: "calc(100% * 0.06)" }}
            />
          </div>
        </div>

        <img
          id="_3362_5580__Group_14041"
          src="assets/images/group_14041_8.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.63)",
          }}
        />
        <span
          id="_3362_5585__10__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "92.86px",
            position: "absolute",
            left: "601.71px",
            top: "1549.07px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            10+ applicants
          </span>
        </span>

        <div
          id="_3362_5587__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "735.15px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5588__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3362_5589__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "548.05px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5590__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3362_5593__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "969.24px",
            top: "1356.26px",
          }}
        ></div>

        <div
          id="_3362_5594__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "987.29px",
            top: "1386.87px",
          }}
        >
          <div
            id="_3362_5595__Frame_675"
            style={{
              position: "absolute",
              height: "36.79px",
              width: "344.80px",
              left: "-0.50px",
              top: "25.23px",
            }}
          >
            <div
              id="_3362_5596__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1536154747009277px",
                height: "15.41px",
                width: "74.82px",
                left: "0.00px",
                top: "0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3362_5597__Full-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "74.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.716872215270996px",
                    fontWeight: "600",
                    lineHeight: "14.72px",
                    textTransform: "uppercase",
                  }}
                >
                  Full-time
                </span>
              </span>
            </div>

            <span
              id="_3362_5598__Salary___30_000_-__5"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "185.00px",
                position: "absolute",
                left: "96.71px",
                top: "4.20px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "400",
                  lineHeight: "14.72px",
                }}
              >
                Salary: $30,000 - $55,000
              </span>
            </span>
          </div>

          <span
            id="_3362_5599__Senior_UI_UX_Designe"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "208.00px",
              position: "absolute",
              left: "-0.50px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.921693801879883px",
                fontWeight: "500",
                lineHeight: "18.92px",
              }}
            >
              Senior UI/UX Designer
            </span>
          </span>
        </div>

        <div
          id="_3362_5600__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "54.41px",
            width: "199.31px",
            left: "983.66px",
            top: "1457.08px",
          }}
        >
          <div
            id="_3362_5601__apple-logo_1"
            style={{
              position: "absolute",
              background: "url(assets/images/null) 100% / cover no-repeat",
              height: "41.66px",
              width: "41.66px",
              left: "8.73px",
              top: "7.68px",
            }}
          ></div>

          <span
            id="_3362_5603__Apple"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "17.00px",
              width: "50.00px",
              position: "absolute",
              left: "64.92px",
              top: "7.29px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.81928253173828px",
                fontWeight: "500",
                lineHeight: "16.82px",
              }}
            >
              Apple
            </span>
          </span>
          <div
            id="_3362_5604__MapPin"
            style={{
              position: "absolute",
              height: "18.92px",
              width: "18.92px",
              left: "62.02px",
              top: "32.51px",
            }}
          >
            <img
              id="I3362_5604_1502_72218__MapPin"
              src="assets/images/mappin_9.svg"
              alt="MapPin"
              style={{ position: "absolute" }}
            />
          </div>

          <span
            id="_3362_5605__Boston__USA"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "86.00px",
              position: "absolute",
              left: "85.15px",
              top: "34.62px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Boston, USA
            </span>
          </span>
        </div>

        <img
          id="_3362_5607__Group_14041"
          src="assets/images/group_14041_9.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.66)",
            top: "calc(100% * 0.63)",
          }}
        />
        <span
          id="_3362_5612__9__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "88.69px",
            position: "absolute",
            left: "1068.77px",
            top: "1552.37px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            9+ applicants
          </span>
        </span>

        <div
          id="_3362_5614__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1188.39px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5615__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3362_5616__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "1001.29px",
            top: "1605.15px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5617__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3362_5618__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "25.75px",
            width: "29.75px",
            left: "1314.41px",
            top: "1376.07px",
          }}
        >
          <img
            id="I3362_5618_1502_74271__BookmarkSimple"
            src="assets/images/bookmarksimple_9.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_5623__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "311.90px",
            width: "376.66px",
            left: "965.45px",
            top: "962.63px",
          }}
        ></div>

        <div
          id="_3362_5624__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "983.50px",
            top: "993.24px",
          }}
        >
          <div
            id="_3362_5625__Frame_675"
            style={{
              position: "absolute",
              height: "36.79px",
              width: "344.80px",
              left: "-0.50px",
              top: "25.23px",
            }}
          >
            <div
              id="_3362_5626__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1536154747009277px",
                height: "15.41px",
                width: "74.82px",
                left: "0.00px",
                top: "-0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3362_5627__Full-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "74.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.716872215270996px",
                    fontWeight: "600",
                    lineHeight: "14.72px",
                    textTransform: "uppercase",
                  }}
                >
                  Full-time
                </span>
              </span>
            </div>

            <span
              id="_3362_5628__Salary___30_000_-__5"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "185.00px",
                position: "absolute",
                left: "96.71px",
                top: "4.20px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.716872215270996px",
                  fontWeight: "400",
                  lineHeight: "14.72px",
                }}
              >
                Salary: $30,000 - $55,000
              </span>
            </span>
          </div>

          <span
            id="_3362_5629__Senior_UI_UX_Designe"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "208.00px",
              position: "absolute",
              left: "-0.50px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.921693801879883px",
                fontWeight: "500",
                lineHeight: "18.92px",
              }}
            >
              Senior UI/UX Designer
            </span>
          </span>
        </div>

        <div
          id="_3362_5630__Company"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "54.41px",
            width: "199.31px",
            left: "979.87px",
            top: "1063.45px",
          }}
        >
          <div
            id="_3362_5631__apple-logo_1"
            style={{
              position: "absolute",
              background: "url(assets/images/null) 100% / cover no-repeat",
              height: "41.66px",
              width: "41.66px",
              left: "8.73px",
              top: "7.68px",
            }}
          ></div>

          <span
            id="_3362_5633__Apple"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "17.00px",
              width: "50.00px",
              position: "absolute",
              left: "64.92px",
              top: "7.29px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "16.81928253173828px",
                fontWeight: "500",
                lineHeight: "16.82px",
              }}
            >
              Apple
            </span>
          </span>
          <div
            id="_3362_5634__MapPin"
            style={{
              position: "absolute",
              height: "18.92px",
              width: "18.92px",
              left: "62.02px",
              top: "32.51px",
            }}
          >
            <img
              id="I3362_5634_1502_72218__MapPin"
              src="assets/images/mappin_10.svg"
              alt="MapPin"
              style={{ position: "absolute" }}
            />
          </div>

          <span
            id="_3362_5635__Boston__USA"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "86.00px",
              position: "absolute",
              left: "85.15px",
              top: "34.62px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(118, 127, 140, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "400",
                lineHeight: "14.72px",
              }}
            >
              Boston, USA
            </span>
          </span>
        </div>

        <img
          id="_3362_5637__Group_14041"
          src="assets/images/group_14041_10.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.66)",
            top: "calc(100% * 0.47)",
          }}
        />
        <span
          id="_3362_5642__9__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "88.69px",
            position: "absolute",
            left: "1064.97px",
            top: "1158.74px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.614461898803711px",
              fontWeight: "500",
              lineHeight: "12.61px",
            }}
          >
            9+ applicants
          </span>
        </span>

        <div
          id="_3362_5644__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "-1.19px",
            width: "32.08px",
            left: "1184.60px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5645__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "79.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3362_5646__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0512051582336426px",
            borderRadius: "15px",
            height: "-3.29px",
            width: "29.98px",
            left: "997.50px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "21px 55px",
          }}
        >
          <span
            id="_3362_5647__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "91.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.716872215270996px",
                fontWeight: "600",
                lineHeight: "14.72px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3362_5648__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "25.75px",
            width: "29.75px",
            left: "1310.61px",
            top: "982.44px",
          }}
        >
          <img
            id="I3362_5648_1502_74271__BookmarkSimple"
            src="assets/images/bookmarksimple_10.svg"
            alt="BookmarkSimple"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3362_5650__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderColor: "#efe1f8ff",
            borderStyle: "solid",
            borderWidth: "1.0338482856750488px",
            borderRadius: "15px",
            height: "311.93px",
            width: "376.69px",
            left: "519.15px",
            top: "962.63px",
          }}
        ></div>

        <div
          id="_3362_5651__Heading"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "22.67px",
            width: "258.51px",
            left: "536.45px",
            top: "993.24px",
          }}
        >
          <div
            id="_3362_5652__Frame_675"
            style={{
              position: "absolute",
              height: "36.18px",
              width: "339.10px",
              left: "0.07px",
              top: "24.81px",
            }}
          >
            <div
              id="_3362_5653__Type"
              style={{
                position: "absolute",
                background: "rgba(241, 224, 255, 1.00)",
                borderRadius: "3.1015446186065674px",
                height: "15.27px",
                width: "79.54px",
                left: "-0.00px",
                top: "-0.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "4px 8px",
              }}
            >
              <span
                id="_3362_5654__Part-time"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "flex-start",
                  height: "15.00px",
                  width: "79.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(12, 70, 59, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontSize: "14.47387409210205px",
                    fontWeight: "600",
                    lineHeight: "14.47px",
                    textTransform: "uppercase",
                  }}
                >
                  Part-time
                </span>
              </span>
            </div>

            <span
              id="_3362_5655__Salary__15_000_INR_-"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "15.00px",
                width: "213.00px",
                position: "absolute",
                left: "95.11px",
                top: "4.14px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(118, 127, 140, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "14.47387409210205px",
                  fontWeight: "400",
                  lineHeight: "14.47px",
                }}
              >
                Salary: 15,000 INR - 35,000 INR
              </span>
            </span>
          </div>

          <span
            id="_3362_5656__Marketing_Officer"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "19.00px",
              width: "161.00px",
              position: "absolute",
              left: "0.07px",
              top: "0.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(24, 25, 28, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "18.60926628112793px",
                fontWeight: "500",
                lineHeight: "18.61px",
              }}
            >
              Marketing Officer
            </span>
          </span>
        </div>

        <img
          id="_3362_5658__Group_14049"
          src="assets/images/group_14049_1.svg"
          alt="Group_14049"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.56)",
          }}
        />
        <span
          id="_3362_5669__Intel_Corp"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "17.12px",
            width: "82.43px",
            position: "absolute",
            left: "604.09px",
            top: "1068.70px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "16.54157257080078px",
              fontWeight: "500",
              lineHeight: "16.54px",
            }}
          >
            Intel Corp
          </span>
        </span>
        <div
          id="_3362_5670__MapPin"
          style={{
            position: "absolute",
            borderRadius: "14.999999046325684px",
            height: "18.90px",
            width: "18.78px",
            left: "601.21px",
            top: "1093.90px",
          }}
        >
          <img
            id="I3362_5670_1502_72218__MapPin"
            src="assets/images/mappin_11.svg"
            alt="MapPin"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3362_5671__Bangalore__India"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "15.11px",
            width: "118.95px",
            position: "absolute",
            left: "624.16px",
            top: "1096.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(118, 127, 140, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "14.47387409210205px",
              fontWeight: "400",
              lineHeight: "14.47px",
            }}
          >
            Bangalore, India
          </span>
        </span>

        <img
          id="_3362_5673__Group_14041"
          src="assets/images/group_14041_11.svg"
          alt="Group_14041"
          style={{
            position: "absolute",
            left: "calc(100% * 0.36)",
            top: "calc(100% * 0.47)",
          }}
        />
        <span
          id="_3362_5678__30__applicants"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "13.60px",
            width: "95.99px",
            position: "absolute",
            left: "604.49px",
            top: "1158.74px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "12.40617847442627px",
              fontWeight: "500",
              lineHeight: "12.41px",
            }}
          >
            30+ applicants
          </span>
        </span>

        <div
          id="_3362_5680__Frame_13965"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "0.81px",
            width: "34.08px",
            left: "737.26px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 54px",
          }}
        >
          <span
            id="_3362_5681__Apply_now"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "78.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.47387409210205px",
                fontWeight: "600",
                lineHeight: "14.47px",
              }}
            >
              Apply now
            </span>
          </span>
        </div>

        <div
          id="_3362_5682__Frame_13966"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1.0338482856750488px",
            borderRadius: "15px",
            height: "-1.26px",
            width: "32.01px",
            left: "550.16px",
            top: "1211.52px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "20px 54px",
          }}
        >
          <span
            id="_3362_5683__View_details"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "flex-start",
              height: "15.00px",
              width: "90.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(48, 48, 48, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "14.47387409210205px",
                fontWeight: "600",
                lineHeight: "14.47px",
              }}
            >
              View details
            </span>
          </span>
        </div>

        <div
          id="_3362_5684__BookmarkSimple"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "27.25px",
            width: "31.47px",
            left: "863.62px",
            top: "981.28px",
          }}
        >
          <img
            id="I3362_5684_1502_74271__BookmarkSimple"
            src="assets/images/bookmarksimple_11.svg"
            alt="BookmarkSimple"
            style={{
              position: "absolute",
              left: "calc(100% * 0.25)",
              top: "calc(100% * 0.16)",
            }}
          />
        </div>

        <img
          id="_3362_5686__Arrow_2"
          src="assets/images/arrow_2_1.svg"
          alt="Arrow_2"
          style={{
            position: "absolute",
            left: "calc(100% * 0.89)",
            top: "calc(100% * 0.27)",
          }}
        />
        <div
          id="_3362_5693__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "74.34px",
            width: "1440.00px",
            left: "0.00px",
            top: "0.00px",
          }}
        ></div>

        <div
          id="_3362_5730__Frame_27"
          style={{
            position: "absolute",
            height: "41.76px",
            width: "343.50px",
            left: "calc(50% - 172.00px)",
            top: "16.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3362_5731__Frame_5"
            onClick={() => navigate("/")}
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3362_5732__Home"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </span>
          </div>

          <div
            id="_3362_5733__Frame_4"
            onClick={() => navigate("/SearchPage")}
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3362_5734__Jobs"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </span>
          </div>

          <div
            id="_3362_5735__Frame_3"
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3362_5736__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>

          <div
            id="_3362_5737__Frame_10"
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>

        <div
          id="_3362_5739__Frame_10"
          style={{
            position: "absolute",
            height: "9.00px",
            width: "-15.00px",
            left: "1164.00px",
            top: "23.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        ></div>

        <span
          id="_3362_5741__Job"
          onClick={() => navigate("/")}
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "27.56px",
            width: "51.68px",
            position: "absolute",
            left: "39.00px",
            top: "28.18px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job&nbsp;
          </span>
        </span>
        <span
          id="_3362_5742__Fiesta"
          onClick={() => navigate("/")}
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "28.00px",
            width: "131.00px",
            position: "absolute",
            left: "85.00px",
            top: "24.00px",
            cursor: "pointer",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>

        <div
          id="_3365_5606__Nav_Bar"
          style={{
            position: "absolute",
            overflow: "hidden",
            background: "rgba(12, 70, 59, 1.00)",
            height: "1037.00px",
            width: "248.00px",
            left: "92.00px",
            top: "554.00px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "62px",
            padding: "40px 20px",
          }}
        >
          <div
            id="_3365_5608__Frame_183"
            onClick={() => navigate("/AccountsettingsPage")}
            style={{
              position: "relative",
              background: "rgba(12, 70, 59, 1.00)",
              borderRadius: "10px",
              width: "calc(100% - 10px - 10px)",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3365_5609__Text"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "27.00px",
                width: "136.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(255, 255, 255, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Nunito Sans",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "600",
                  letterSpacing: "0.30000001192092896px",
                }}
              >
                Profile Update
              </span>
            </span>
          </div>

          <div
            id="_3365_5610__Frame_184"
            style={{
              position: "relative",
              borderRadius: "10px",
              width: "calc(100% - 10px - 10px)",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3365_5611__Text"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "27.00px",
                width: "93.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(255, 255, 255, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Nunito Sans",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "600",
                  letterSpacing: "0.30000001192092896px",
                }}
              >
                Messages
              </span>
            </span>
          </div>

          <div
            id="_3365_5612__Frame_185"
            onClick={() => navigate("/AccountsettingsPage")}
            style={{
              position: "relative",
              borderRadius: "10px",
              width: "calc(100% - 10px - 10px)",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
              cursor: "pointer",
            }}
          >
            <span
              id="_3365_5613__Text"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "27.00px",
                width: "160.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(255, 255, 255, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Nunito Sans",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "600",
                  letterSpacing: "0.30000001192092896px",
                }}
              >
                Account Settings
              </span>
            </span>
          </div>
        </div>

        <img
          id="_3377_2748__Group_6"
          src="assets/images/group_6_6.svg"
          alt="Group_6"
          style={{
            position: "absolute",
            left: "calc(100% * 0.97)",
            top: "calc(100% * 0.01)",
          }}
        />
        <div
          id="_3377_2710__Frame_11"
          onClick={() => navigate("/ResumeGenerationPage")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "26.00px",
            width: "209.00px",
            left: "1193.00px",
            top: "9.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3377_2711__Generate_Resume"
            onClick={() => navigate("/ResumeGenerationPage")}
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "173.00px",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Generate Resume
            </span>
          </span>
          <img
            id="_3377_2712__Group"
            src="assets/images/group_32.svg"
            alt="Group"
            style={{ position: "relative" }}
          />
        </div>

        <span
          id="_3377_2708__Browse_jobs"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "30.00px",
            width: "173.00px",
            position: "absolute",
            left: "997.00px",
            top: "17.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Browse jobs
          </span>
        </span>
      </div>
    </>
  );
};
export default JobSeekerDashBoardPage;
