//complete
import React from "react";
import { Link } from 'react-router-dom';

const LandingPage = () => {
  return (
    <>
      <div
        id="_3323_12__Landing_Page"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(247, 247, 247, 1.00)",
          height: "5715.0px",
          width: "100%",
        }}
      >
        <div
          id="_3323_14__Rectangle_19"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderRadius: "15px",
            height: "208.00px",
            width: "246.00px",
            left: "63.00px",
            top: "2858.00px",
          }}
        ></div>

        <div
          id="_3323_15__Rectangle_22"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderRadius: "15px",
            height: "208.00px",
            width: "246.00px",
            left: "900.00px",
            top: "2858.00px",
          }}
        ></div>

        <div
          id="_3323_19__Rectangle_4"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderRadius: "50px",
            boxShadow: "0.0px 0.0px 30.0px 2.0px rgba(0, 0, 0, 0.08)",
            height: "82.00px",
            width: "637.00px",
            left: "calc(50% - 439.00px)",
            top: "554.00px",
          }}
        ></div>

        <div
          id="_3323_20__Frame_13"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "62.00px",
            width: "172.53px",
            left: "934.47px",
            top: "554.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_21__Search"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "38.00px",
              width: "85.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "25.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Search
            </span>
          </span>
        </div>

        <span
          id="_3323_22__Job_Title__keywords_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "33.00px",
            width: "312.00px",
            position: "absolute",
            left: "468.00px",
            top: "579.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(81, 81, 81, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Job Title, keywords......
          </span>
        </span>
        <div
          id="_3323_23__Interface___Search_M"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "39.00px",
            width: "33.98px",
            left: "407.39px",
            top: "576.00px",
          }}
        >
          <img
            id="_3323_24__Vector"
            src="assets/Landingpageimages/vector.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.13)",
              top: "calc(100% * 0.13)",
            }}
          />
        </div>

        <div
          id="_3323_25__Frame_12"
          style={{
            position: "absolute",
            height: "38.00px",
            width: "0.00px",
            left: "calc(50% - 10.00px)",
            top: "433.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        ></div>

        <div
          id="_3323_29__Rectangle_16"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "15px",
            height: "374.00px",
            width: "510.00px",
            left: "1163.00px",
            top: "2235.00px",
          }}
        ></div>

        <div
          id="_3323_30__Frame_20"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "68.00px",
            left: "1207.00px",
            top: "2273.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 22px",
          }}
        >
          <span
            id="_3323_31__Part_Time"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "69.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Part Time
            </span>
          </span>
        </div>

        <div
          id="_3323_33__Frame_15"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "104.00px",
            left: "1341.00px",
            top: "2273.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 34px",
          }}
        >
          <span
            id="_3323_34__Grandview__CA"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Grandview, CA
            </span>
          </span>
        </div>

        <div
          id="_3323_37__Ellipse_2"
          style={{
            position: "absolute",
            borderColor: "#2a2a2aff",
            borderStyle: "solid",
            borderWidth: "3px",
            height: "58.00px",
            width: "58.00px",
            borderRadius: "50%",
            left: "1206.00px",
            top: "2352.00px",
          }}
        ></div>

        <div
          id="_3323_38__Social_Icons_Dribbbl"
          style={{
            position: "absolute",
            height: "39.00px",
            width: "39.00px",
            left: "1215.00px",
            top: "2362.00px",
          }}
        >
          <img id="I3323_38_29_408__Vector" style={{ position: "absolute" }} />
          <img
            id="I3323_38_29_409__Vector"
            src="assets/Landingpageimages/vector_1.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.02)",
              top: "calc(100% * 0.02)",
            }}
          />
          <img id="I3323_38_29_410__Vector" style={{ position: "absolute" }} />
          <img
            id="I3323_38_29_411__Vector"
            src="assets/Landingpageimages/vector_2.svg"
            alt="Vector"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3323_39__UI___UX_Designer"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "249.00px",
            position: "absolute",
            left: "1289.00px",
            top: "2362.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "30.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            UI / UX Designer&nbsp;
          </span>
        </span>

        <span
          id="_3323_41__Designer"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "76.00px",
            position: "absolute",
            left: "1206.00px",
            top: "2440.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Designer
          </span>
        </span>
        <span
          id="_3323_42___2_000_-_5_000"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "128.00px",
            position: "absolute",
            left: "1323.00px",
            top: "2440.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            $2,000 - 5,000
          </span>
        </span>
        <span
          id="_3323_43____Monthly"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "81.00px",
            position: "absolute",
            left: "1470.00px",
            top: "2440.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            / Monthly
          </span>
        </span>
        <img
          id="_3323_44__Vector_1"
          src="assets/Landingpageimages/vector_1_1.svg"
          alt="Vector_1"
          style={{ position: "absolute", left: "1308.00px", top: "2440.00px" }}
        />

        <div
          id="_3323_45__Frame_21"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "50px",
            height: "28.00px",
            width: "442.00px",
            left: "1186.00px",
            top: "2529.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_46__Apply_Now"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(42, 42, 42, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Apply Now
            </span>
          </span>
        </div>

        <img
          id="_3323_47__Group"
          src="assets/Landingpageimages/group.svg"
          alt="Group"
          style={{
            position: "absolute",
            left: "calc(100% * 0.82)",
            top: "calc(100% * 0.11)",
          }}
        />
        <span
          id="_3323_81__Web_Design"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "29.00px",
            width: "182.00px",
            position: "absolute",
            left: "95.00px",
            top: "2991.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Web Design
          </span>
        </span>
        <div
          id="_3323_83__Rectangle_15"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "15px",
            height: "374.00px",
            width: "510.00px",
            left: "63.00px",
            top: "2226.00px",
          }}
        ></div>

        <div
          id="_3323_84__Frame_18"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "68.00px",
            left: "107.00px",
            top: "2264.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 22px",
          }}
        >
          <span
            id="_3323_85__Part_Time"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "69.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Part Time
            </span>
          </span>
        </div>

        <div
          id="_3323_87__Frame_15"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "103.00px",
            left: "241.00px",
            top: "2264.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 34px",
          }}
        >
          <span
            id="_3323_88__Greenbriar__CA"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "104.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Greenbriar, CA
            </span>
          </span>
        </div>

        <div
          id="_3323_91__Ellipse_2"
          style={{
            position: "absolute",
            borderColor: "#2a2a2aff",
            borderStyle: "solid",
            borderWidth: "3px",
            height: "58.00px",
            width: "58.00px",
            borderRadius: "50%",
            left: "106.00px",
            top: "2343.00px",
          }}
        ></div>

        <div
          id="_3323_92__Social_Icons_Apple_O"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "34.00px",
            width: "34.00px",
            left: "118.00px",
            top: "2355.00px",
          }}
        >
          <img
            id="_3323_93__Vector"
            src="assets/Landingpageimages/vector_3.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.08)",
              top: "calc(100% * 0.00)",
            }}
          />
        </div>

        <span
          id="_3323_94__Software_Engineer"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "282.00px",
            position: "absolute",
            left: "189.00px",
            top: "2350.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "30.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Software Engineer
          </span>
        </span>

        <span
          id="_3323_96__Developer"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "87.00px",
            position: "absolute",
            left: "106.00px",
            top: "2431.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Developer
          </span>
        </span>
        <span
          id="_3323_97___2_000_-_5_000"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "128.00px",
            position: "absolute",
            left: "223.00px",
            top: "2431.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            $2,000 - 5,000
          </span>
        </span>
        <span
          id="_3323_98____Monthly"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "82.00px",
            position: "absolute",
            left: "370.00px",
            top: "2431.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "500",
              lineHeight: "150.00%",
            }}
          >
            / Monthly
          </span>
        </span>
        <img
          id="_3323_99__Vector_1"
          src="assets/Landingpageimages/vector_1_2.svg"
          alt="Vector_1"
          style={{ position: "absolute", left: "208.00px", top: "2431.00px" }}
        />

        <div
          id="_3323_100__Frame_19"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "50px",
            height: "28.00px",
            width: "442.00px",
            left: "86.00px",
            top: "2520.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_101__Apply_Now"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(42, 42, 42, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Apply Now
            </span>
          </span>
        </div>

        <div
          id="_3323_102__Rectangle_20"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "208.00px",
            width: "246.00px",
            left: "342.00px",
            top: "2858.00px",
          }}
        ></div>

        <div
          id="_3323_103__Frame_13"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "35.00px",
            width: "147.00px",
            left: "1613.00px",
            top: "1655.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <Link
          to="/SearchPage"
            id="_3323_104__View_All"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "79.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              View All
            </span>
          </Link>
          <div
            id="_3323_105__Arrow___Arrow_Right_"
            style={{
              position: "relative",
              overflow: "hidden",
              height: "24.00px",
              width: "24.00px",
            }}
          >
            <img
              id="_3323_106__Vector"
              src="assets/Landingpageimages/vector_4.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.13)",
                top: "calc(100% * 0.29)",
              }}
            />
          </div>
        </div>

        <div
          id="_3323_108__Rectangle_15"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "15px",
            height: "374.00px",
            width: "510.00px",
            left: "613.00px",
            top: "2235.00px",
          }}
        ></div>

        <div
          id="_3323_109__Frame_18"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "68.00px",
            left: "657.00px",
            top: "2273.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 22px",
          }}
        >
          <span
            id="_3323_110__Part_Time"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "69.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Part Time
            </span>
          </span>
        </div>

        <div
          id="_3323_112__Frame_15"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "111.00px",
            left: "791.00px",
            top: "2273.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 34px",
          }}
        >
          <span
            id="_3323_113__Rossmoyne__CA"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "112.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Rossmoyne, CA
            </span>
          </span>
        </div>

        <img
          id="_3323_115__Group_512926"
          src="assets/Landingpageimages/group_512926.svg"
          alt="Group_512926"
          style={{
            position: "absolute",
            left: "calc(100% * 0.46)",
            top: "calc(100% * 0.41)",
          }}
        />
        <span
          id="_3323_118__Customer_Support"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "278.00px",
            position: "absolute",
            left: "739.00px",
            top: "2359.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "30.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Customer Support&nbsp;
          </span>
        </span>

        <span
          id="_3323_120__Support"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "69.00px",
            position: "absolute",
            left: "656.00px",
            top: "2440.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Support
          </span>
        </span>
        <span
          id="_3323_121___2_000_-_5_000"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "128.00px",
            position: "absolute",
            left: "773.00px",
            top: "2440.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            $2,000 - 5,000
          </span>
        </span>
        <span
          id="_3323_122____Monthly"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "81.00px",
            position: "absolute",
            left: "919.00px",
            top: "2440.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            / Monthly
          </span>
        </span>
        <img
          id="_3323_123__Vector_1"
          src="assets/Landingpageimages/vector_1_3.svg"
          alt="Vector_1"
          style={{ position: "absolute", left: "758.00px", top: "2440.00px" }}
        />

        <div
          id="_3323_124__Frame_19"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "50px",
            height: "28.00px",
            width: "442.00px",
            left: "636.00px",
            top: "2529.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_125__Apply_Now"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(42, 42, 42, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Apply Now
            </span>
          </span>
        </div>

        <img
          id="_3323_126__Group"
          src="assets/Landingpageimages/group_1.svg"
          alt="Group"
          style={{
            position: "absolute",
            left: "calc(100% * 0.07)",
            top: "calc(100% * 0.11)",
          }}
        />
        <div
          id="_3323_161__Rectangle_15"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "15px",
            height: "374.00px",
            width: "510.00px",
            left: "613.00px",
            top: "1821.00px",
          }}
        ></div>

        <div
          id="_3323_162__Frame_18"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "68.00px",
            left: "657.00px",
            top: "1859.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 22px",
          }}
        >
          <span
            id="_3323_163__Part_Time"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "69.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Part Time
            </span>
          </span>
        </div>

        <div
          id="_3323_165__Frame_15"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "109.00px",
            left: "791.00px",
            top: "1859.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 34px",
          }}
        >
          <span
            id="_3323_166__Glen_wood__CA"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "110.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Glen wood, CA
            </span>
          </span>
        </div>

        <div
          id="_3323_169__Ellipse_2"
          style={{
            position: "absolute",
            borderColor: "#2a2a2aff",
            borderStyle: "solid",
            borderWidth: "3px",
            height: "58.00px",
            width: "58.00px",
            borderRadius: "50%",
            left: "656.00px",
            top: "1938.00px",
          }}
        ></div>

        <div
          id="_3323_170__Social_Icons_Pintere"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "39.00px",
            width: "39.00px",
            left: "665.00px",
            top: "1948.00px",
          }}
        >
          <img
            id="_3323_171__Vector"
            src="assets/Landingpageimages/vector_5.svg"
            alt="Vector"
            style={{ position: "absolute" }}
          />
          <img
            id="_3323_172__Vector"
            src="assets/Landingpageimages/vector_6.svg"
            alt="Vector"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3323_173__Product_Designer"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "262.00px",
            position: "absolute",
            left: "739.00px",
            top: "1945.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "30.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Product Designer&nbsp;
          </span>
        </span>

        <span
          id="_3323_175__Designer"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "76.00px",
            position: "absolute",
            left: "656.00px",
            top: "2026.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Designer
          </span>
        </span>
        <span
          id="_3323_176___2_000_-_5_000"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "128.00px",
            position: "absolute",
            left: "773.00px",
            top: "2026.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            $2,000 - 5,000
          </span>
        </span>
        <span
          id="_3323_177____Monthly"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "81.00px",
            position: "absolute",
            left: "919.00px",
            top: "2026.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            / Monthly
          </span>
        </span>
        <img
          id="_3323_178__Vector_1"
          src="assets/Landingpageimages/vector_1_4.svg"
          alt="Vector_1"
          style={{ position: "absolute", left: "758.00px", top: "2026.00px" }}
        />

        <div
          id="_3323_179__Frame_19"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "50px",
            height: "28.00px",
            width: "442.00px",
            left: "636.00px",
            top: "2115.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_180__Apply_Now"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(42, 42, 42, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Apply Now
            </span>
          </span>
        </div>

        <span
          id="_3323_181__Data_Entry"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "29.00px",
            width: "182.00px",
            position: "absolute",
            left: "932.00px",
            top: "2991.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Data Entry
          </span>
        </span>
        <span
          id="_3323_182__Web_Development"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "29.00px",
            width: "182.00px",
            position: "absolute",
            left: "374.00px",
            top: "2991.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(242, 255, 242, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Web Development
          </span>
        </span>
        <div
          id="_3323_184__Rectangle_9"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "15px",
            height: "374.00px",
            width: "510.00px",
            left: "63.00px",
            top: "1812.00px",
          }}
        ></div>

        <img
          id="_3323_186__Group_512926"
          src="assets/Landingpageimages/group_512926_1.svg"
          alt="Group_512926"
          style={{
            position: "absolute",
            left: "calc(100% * 0.07)",
            top: "calc(100% * 0.34)",
          }}
        />
        <div
          id="_3323_188__1298766_spotify_musi"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "42.00px",
            width: "42.00px",
            left: "114.00px",
            top: "1937.00px",
          }}
        >
          <img
            id="_3323_190__Spotify_1_"
            src="assets/Landingpageimages/spotify_1_.svg"
            alt="Spotify_1_"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3323_193__Frame_16"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "63.00px",
            left: "107.00px",
            top: "1850.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 22px",
          }}
        >
          <span
            id="_3323_194__Full_Time"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "64.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Full Time
            </span>
          </span>
        </div>

        <div
          id="_3323_196__Frame_15"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "91.00px",
            left: "241.00px",
            top: "1850.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 34px",
          }}
        >
          <span
            id="_3323_197__Glendale__CA"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "92.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Glendale, CA
            </span>
          </span>
        </div>

        <span
          id="_3323_199__Product_Manager"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "45.00px",
            width: "259.00px",
            position: "absolute",
            left: "187.00px",
            top: "1936.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "30.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Product Manager
          </span>
        </span>

        <span
          id="_3323_201__Marketing"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "86.00px",
            position: "absolute",
            left: "106.00px",
            top: "2017.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Marketing&nbsp;
          </span>
        </span>
        <span
          id="_3323_202___2_000_-_5_000"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "128.00px",
            position: "absolute",
            left: "223.00px",
            top: "2017.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            $2,000 - 5,000
          </span>
        </span>
        <span
          id="_3323_203____Monthly"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "81.00px",
            position: "absolute",
            left: "371.00px",
            top: "2017.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            / Monthly
          </span>
        </span>
        <img
          id="_3323_204__Vector_1"
          src="assets/Landingpageimages/vector_1_5.svg"
          alt="Vector_1"
          style={{ position: "absolute", left: "208.00px", top: "2017.00px" }}
        />

        <div
          id="_3323_205__Frame_17"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "30.00px",
            width: "444.00px",
            left: "86.00px",
            top: "2106.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_206__Apply_Now"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Apply Now
            </span>
          </span>
        </div>

        <img
          id="_3323_207__Group"
          src="assets/Landingpageimages/group_2.svg"
          alt="Group"
          style={{
            position: "absolute",
            left: "calc(100% * 0.79)",
            top: "calc(100% * 0.03)",
          }}
        />
        <div
          id="_3323_209__Ellipse_12"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            height: "80.00px",
            width: "80.00px",
            borderRadius: "50%",
            left: "147.00px",
            top: "2882.00px",
            boxShadow: "0.0px 0.0px 10.0px 0.0px rgba(0, 0, 0, 0.15)",
          }}
        ></div>

        <span
          id="_3323_210__Our_Categories"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "75.00px",
            width: "503.00px",
            position: "absolute",
            left: "calc(50% - 657.00px)",
            top: "2691.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "60.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Our Categories
          </span>
        </span>
        <img
          id="_3323_211__Group"
          src="assets/Landingpageimages/group_3.svg"
          alt="Group"
          style={{
            position: "absolute",
            left: "calc(100% * 0.09)",
            top: "calc(100% * 0.03)",
          }}
        />
        <div
          id="_3323_240__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "89.00px",
            width: "1449.00px",
            left: "-9.00px",
            top: "-6.00px",
          }}
        ></div>

        <div
          id="_3323_277__Frame_27"
          style={{
            position: "absolute",
            height: "50.00px",
            width: "345.65px",
            left: "calc(50% - 180.59px)",
            top: "21.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3323_278__Frame_5"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <Link
              to="/"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
                textDecoration: "none",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </Link>
          </div>


          <div
            id="_3323_280__Frame_4"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <Link
              to="/SearchPage"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
                textDecoration: "none", // 👈 Optional: removes underline
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </Link>
          </div>

          <div
            id="_3323_282__Frame_3"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3323_283__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>

          <div
            id="_3323_288__Frame_10"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>

        <div
          id="_3323_299__Frame_10"
          style={{
            position: "absolute",
            height: "30.00px",
            width: "85.66px",
            left: "1120.01px",
            top: "21.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <Link
          to="/SearchPage"
            id="_3323_300__Browse_jobs"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "120.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(12, 70, 59, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "700",
                lineHeight: "150.00%",
              }}
            >
              Browse jobs
            </span>
          </Link>
        </div>

        <span
          id="_3329_756__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "52.00px",
            position: "absolute",
            left: "30.00px",
            top: "28.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job&nbsp;
          </span>
        </span>
        <span
          id="_3329_757__Fiesta"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "124.00px",
            position: "absolute",
            left: "76.00px",
            top: "23.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>
        <div
          id="_3377_2837__Frame_11"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "35.00px",
            width: "150.06px",
            left: "1263.00px",
            top: "18.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <Link
          to="/login"
            id="_3377_2838__Log_In"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "59.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Log In
            </span>
          </Link>
        </div>

        <span
          id="_3323_301__Contact_Us"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "75.00px",
            width: "359.00px",
            position: "absolute",
            left: "calc(50% - 180.00px)",
            top: "3977.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "60.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Contact Us
          </span>
        </span>
        <div
          id="_3323_302__Rectangle_21"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderRadius: "15px",
            height: "208.00px",
            width: "246.00px",
            left: "621.00px",
            top: "2858.00px",
          }}
        ></div>

        <div
          id="_3323_303__Rectangle_4539"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderRadius: "15px",
            height: "208.00px",
            width: "246.00px",
            left: "1179.00px",
            top: "2858.00px",
          }}
        ></div>

        <div
          id="_3323_304__Rectangle_23"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            borderRadius: "10px",
            height: "211.00px",
            width: "246.00px",
            left: "1457.00px",
            top: "2858.00px",
          }}
        ></div>

        <span
          id="_3323_305__Marketing"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "29.00px",
            width: "182.00px",
            position: "absolute",
            left: "653.00px",
            top: "2991.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Marketing&nbsp;
          </span>
        </span>
        <span
          id="_3323_306__Software_Engineer"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "29.00px",
            width: "182.00px",
            position: "absolute",
            left: "1211.00px",
            top: "2991.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Software Engineer
          </span>
        </span>
        <span
          id="_3323_307__Graphic_Designer"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "27.00px",
            width: "172.00px",
            position: "absolute",
            left: "1494.00px",
            top: "2991.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Graphic Designer&nbsp;
          </span>
        </span>
        <div
          id="_3323_308__Ellipse_6"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            height: "80.00px",
            width: "80.00px",
            borderRadius: "50%",
            left: "1540.00px",
            top: "2882.00px",
            boxShadow: "0.0px 0.0px 10.0px 0.0px rgba(0, 0, 0, 0.15)",
          }}
        ></div>

        <div
          id="_3323_309__Frame_14"
          style={{
            position: "absolute",
            height: "215.00px",
            width: "687.00px",
            left: "calc(50% - 353.50px)",
            top: "167.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_310__Find_your_Perfecto_j"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "215.00px",
              width: "687.00px",
              position: "relative",
            }}
          >
            <span>
              <span
                style={{
                  background: "rgba(11, 11, 11, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "League Script",
                  fontStyle: "normal",
                  fontSize: "90.0px",
                  fontWeight: "400",
                  lineHeight: "125.00%",
                }}
              >
                Find your
              </span>
              <span
                style={{
                  background: "rgba(12, 70, 59, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "League Script",
                  fontStyle: "normal",
                  fontSize: "90.0px",
                  fontWeight: "400",
                  lineHeight: "125.00%",
                }}
              >
                &nbsp;
              </span>
              <span
                style={{
                  background: "rgba(12, 70, 59, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Strong",
                  fontStyle: "normal",
                  fontSize: "90.0px",
                  fontWeight: "400",
                  lineHeight: "125.00%",
                }}
              >
                Perfecto
              </span>
              <span
                style={{
                  background: "rgba(12, 70, 59, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "90.0px",
                  fontWeight: "600",
                  lineHeight: "125.00%",
                }}
              >
                &nbsp;
              </span>
              <span
                style={{
                  background: "rgba(0, 0, 0, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "League Script",
                  fontStyle: "normal",
                  fontSize: "90.0px",
                  fontWeight: "400",
                  lineHeight: "125.00%",
                }}
              >
                job
              </span>
            </span>
          </span>
        </div>

        <div
          id="_3323_311__Ellipse_10"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            height: "87.00px",
            width: "87.00px",
            borderRadius: "50%",
            left: "983.00px",
            top: "2882.00px",
            boxShadow: "0.0px 0.0px 10.0px 0.0px rgba(0, 0, 0, 0.15)",
          }}
        ></div>

        <div
          id="_3323_312__Ellipse_9"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "80.00px",
            width: "80.00px",
            borderRadius: "50%",
            left: "425.00px",
            top: "2882.00px",
          }}
        ></div>

        <span
          id="_3323_313__Our_Features_Jobs"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "75.00px",
            width: "569.00px",
            position: "absolute",
            left: "calc(50% - 657.00px)",
            top: "1657.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "60.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            Our Features Jobs
          </span>
        </span>
        <div
          id="_3323_314__Ellipse_11"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            height: "87.00px",
            width: "87.00px",
            borderRadius: "50%",
            left: "1262.00px",
            top: "2882.00px",
            boxShadow: "0.0px 0.0px 10.0px 0.0px rgba(0, 0, 0, 0.15)",
          }}
        ></div>

        <span
          id="_3323_315__What_our_Client_say"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "75.00px",
            width: "627.00px",
            position: "absolute",
            left: "calc(50% - 657.00px)",
            top: "3221.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "60.0px",
              fontWeight: "700",
              lineHeight: "125.00%",
            }}
          >
            What our Client say
          </span>
        </span>
        <div
          id="_3323_316__19184614_6101000_1"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "808.00px",
            width: "1265.00px",
            left: "calc(50% - 633.00px)",
            top: "674.00px",
          }}
        >
          <img
            id="_3323_318__Group"
            src="assets/Landingpageimages/group_4.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.24)",
              top: "calc(100% * 0.05)",
            }}
          />
          <img
            id="_3323_321__Group"
            src="assets/Landingpageimages/group_5.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.67)",
              top: "calc(100% * 0.05)",
            }}
          />

          <img
            id="_3323_324__Picture"
            src="assets/Landingpageimages/picture.svg"
            alt="Picture"
            style={{
              position: "absolute",
              left: "calc(100% * 0.75)",
              top: "calc(100% * 0.18)",
            }}
          />
          <img
            id="_3323_339__Group"
            src="assets/Landingpageimages/group_6.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.78)",
              top: "calc(100% * 0.51)",
            }}
          />
          <img
            id="_3323_373__Group"
            src="assets/Landingpageimages/group_7.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.83)",
              top: "calc(100% * 0.79)",
            }}
          />

          <img
            id="_3323_385__Group"
            src="assets/Landingpageimages/group_8.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.68)",
              top: "calc(100% * 0.41)",
            }}
          />
          <img
            id="_3323_390__Vector"
            src="assets/Landingpageimages/vector_7.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.70)",
              top: "calc(100% * 0.44)",
            }}
          />
          <img
            id="_3323_391__Vector"
            src="assets/Landingpageimages/vector_8.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.72)",
              top: "calc(100% * 0.38)",
            }}
          />
          <img
            id="_3323_392__Vector"
            src="assets/Landingpageimages/vector_9.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.72)",
              top: "calc(100% * 0.52)",
            }}
          />
          <img
            id="_3323_393__Vector"
            src="assets/Landingpageimages/vector_10.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.74)",
              top: "calc(100% * 0.53)",
            }}
          />
          <img
            id="_3323_394__Vector"
            src="assets/Landingpageimages/vector_11.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.74)",
              top: "calc(100% * 0.59)",
            }}
          />
          <img
            id="_3323_395__Vector"
            src="assets/Landingpageimages/vector_12.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.72)",
              top: "calc(100% * 0.85)",
            }}
          />
          <img
            id="_3323_396__Vector"
            src="assets/Landingpageimages/vector_13.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.74)",
              top: "calc(100% * 0.87)",
            }}
          />
          <img
            id="_3323_397__Vector"
            src="assets/Landingpageimages/vector_14.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.73)",
              top: "calc(100% * 0.37)",
            }}
          />
          <img
            id="_3323_398__Group"
            src="assets/Landingpageimages/group_9.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.72)",
              top: "calc(100% * 0.28)",
            }}
          />
          <img
            id="_3323_404__Vector"
            src="assets/Landingpageimages/vector_15.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.73)",
              top: "calc(100% * 0.26)",
            }}
          />
          <img
            id="_3323_405__Vector"
            src="assets/Landingpageimages/vector_16.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.74)",
              top: "calc(100% * 0.37)",
            }}
          />
          <img
            id="_3323_406__Group"
            src="assets/Landingpageimages/group_10.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.67)",
              top: "calc(100% * 0.43)",
            }}
          />
          <img
            id="_3323_411__Vector"
            src="assets/Landingpageimages/vector_17.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.70)",
              top: "calc(100% * 0.41)",
            }}
          />
          <img
            id="_3323_412__Vector"
            src="assets/Landingpageimages/vector_18.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.75)",
              top: "calc(100% * 0.60)",
            }}
          />

          <img
            id="_3323_415__Vector"
            src="assets/Landingpageimages/vector_19.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.56)",
              top: "calc(100% * 0.53)",
            }}
          />
          <img
            id="_3323_416__Group"
            src="assets/Landingpageimages/group_11.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.53)",
              top: "calc(100% * 0.36)",
            }}
          />
          <img
            id="_3323_426__Group"
            src="assets/Landingpageimages/group_12.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.59)",
              top: "calc(100% * 0.36)",
            }}
          />
          <img
            id="_3323_429__Group"
            src="assets/Landingpageimages/group_13.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.59)",
              top: "calc(100% * 0.23)",
            }}
          />
          <img
            id="_3323_438__Vector"
            src="assets/Landingpageimages/vector_20.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.61)",
              top: "calc(100% * 0.34)",
            }}
          />
          <img
            id="_3323_439__Group"
            src="assets/Landingpageimages/group_14.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.54)",
              top: "calc(100% * 0.51)",
            }}
          />
          <img
            id="_3323_443__Group"
            src="assets/Landingpageimages/group_15.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.58)",
              top: "calc(100% * 0.37)",
            }}
          />
          <img
            id="_3323_446__Vector"
            src="assets/Landingpageimages/vector_21.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.53)",
              top: "calc(100% * 0.50)",
            }}
          />
          <img
            id="_3323_447__Group"
            src="assets/Landingpageimages/group_16.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.49)",
              top: "calc(100% * 0.51)",
            }}
          />

          <img
            id="_3323_451__Vector"
            src="assets/Landingpageimages/vector_22.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.02)",
              top: "calc(100% * 0.87)",
            }}
          />
          <img
            id="_3323_453__Group"
            src="assets/Landingpageimages/group_17.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.21)",
              top: "calc(100% * 0.58)",
            }}
          />
          <img
            id="_3323_456__Vector"
            src="assets/Landingpageimages/vector_23.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.21)",
              top: "calc(100% * 0.38)",
            }}
          />
          <img
            id="_3323_457__Vector"
            src="assets/Landingpageimages/vector_24.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.13)",
              top: "calc(100% * 0.52)",
            }}
          />
          <img
            id="_3323_458__Group"
            src="assets/Landingpageimages/group_18.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.10)",
              top: "calc(100% * 0.34)",
            }}
          />
          <img
            id="_3323_468__Vector"
            src="assets/Landingpageimages/vector_25.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.18)",
              top: "calc(100% * 0.34)",
            }}
          />
          <img
            id="_3323_469__Vector"
            src="assets/Landingpageimages/vector_26.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.19)",
              top: "calc(100% * 0.35)",
            }}
          />
          <img
            id="_3323_470__Group"
            src="assets/Landingpageimages/group_19.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.13)",
              top: "calc(100% * 0.22)",
            }}
          />
          <img
            id="_3323_480__Vector"
            src="assets/Landingpageimages/vector_27.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.15)",
              top: "calc(100% * 0.33)",
            }}
          />
          <img
            id="_3323_481__Group"
            src="assets/Landingpageimages/group_20.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.07)",
              top: "calc(100% * 0.62)",
            }}
          />
          <img
            id="_3323_484__Vector"
            src="assets/Landingpageimages/vector_28.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.10)",
              top: "calc(100% * 0.59)",
            }}
          />

          <img
            id="_3323_485__Device"
            src="assets/Landingpageimages/device.svg"
            alt="Device"
            style={{
              position: "absolute",
              left: "calc(100% * 0.28)",
              top: "calc(100% * 0.41)",
            }}
          />
          <img
            id="_3323_492__Group"
            src="assets/Landingpageimages/group_21.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.44)",
              top: "calc(100% * 0.41)",
            }}
          />
          <img
            id="_3323_497__Vector"
            src="assets/Landingpageimages/vector_29.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.37)",
              top: "calc(100% * 0.75)",
            }}
          />
          <img
            id="_3323_498__Vector"
            src="assets/Landingpageimages/vector_30.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.36)",
              top: "calc(100% * 0.71)",
            }}
          />

          <img
            id="_3323_501__Vector"
            src="assets/Landingpageimages/vector_31.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.29)",
              top: "calc(100% * 0.63)",
            }}
          />
          <img
            id="_3323_502__Vector"
            src="assets/Landingpageimages/vector_32.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.58)",
              top: "calc(100% * 0.63)",
            }}
          />
          <img
            id="_3323_504__Vector"
            src="assets/Landingpageimages/vector_33.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.26)",
              top: "calc(100% * 0.59)",
            }}
          />

          <img
            id="_3323_505__Vector"
            src="assets/Landingpageimages/vector_34.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.26)",
              top: "calc(100% * 0.59)",
            }}
          />
          <img
            id="_3323_506__Vector"
            src="assets/Landingpageimages/vector_35.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.25)",
              top: "calc(100% * 0.58)",
            }}
          />

          <img
            id="_3323_508__Vector"
            src="assets/Landingpageimages/vector_36.svg"
            alt="Vector"
            style={{
              position: "absolute",
              transform: "rotate(81.93deg)",
              transformOrigin: "0 0",
              left: "calc(100% * 0.54)",
              top: "calc(100% * 0.04)",
            }}
          />
        </div>

        <div
          id="_3323_509__4552605_adaptive_des"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "43.00px",
            width: "43.00px",
            left: "165.00px",
            top: "2901.00px",
          }}
        >
          <img
            id="_3323_513__Vector"
            src="assets/Landingpageimages/vector_37.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.03)",
              top: "calc(100% * 0.06)",
            }}
          />

          <img
            id="_3323_514__Vector"
            src="assets/Landingpageimages/vector_38.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.31)",
              top: "calc(100% * 0.80)",
            }}
          />
          <img
            id="_3323_515__Vector"
            src="assets/Landingpageimages/vector_39.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.03)",
              top: "calc(100% * 0.66)",
            }}
          />

          <img
            id="_3323_519__Vector"
            src="assets/Landingpageimages/vector_40.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.66)",
              top: "calc(100% * 0.25)",
            }}
          />

          <img
            id="_3323_522__Vector"
            src="assets/Landingpageimages/vector_41.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.72)",
              top: "calc(100% * 0.88)",
            }}
          />

          <img
            id="_3323_523__Vector"
            src="assets/Landingpageimages/vector_42.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.53)",
              top: "calc(100% * 0.19)",
            }}
          />
        </div>

        <div
          id="_3323_525__Rectangle_16"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "15px",
            height: "374.00px",
            width: "510.00px",
            left: "1163.00px",
            top: "1821.00px",
          }}
        ></div>

        <div
          id="_3323_526__Frame_20"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "68.00px",
            left: "1207.00px",
            top: "1859.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 22px",
          }}
        >
          <span
            id="_3323_527__Part_Time"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "69.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Part Time
            </span>
          </span>
        </div>

        <div
          id="_3323_529__Frame_15"
          style={{
            position: "absolute",
            overflow: "hidden",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "0.5px",
            borderRadius: "50px",
            height: "22.00px",
            width: "82.00px",
            left: "1341.00px",
            top: "1859.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "8px 34px",
          }}
        >
          <span
            id="_3323_530__Tropico__CA"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "23.00px",
              width: "83.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(68, 68, 68, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "15.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Tropico, CA
            </span>
          </span>
        </div>

        <div
          id="_3323_533__Ellipse_2"
          style={{
            position: "absolute",
            borderColor: "#2a2a2aff",
            borderStyle: "solid",
            borderWidth: "3px",
            height: "58.00px",
            width: "58.00px",
            borderRadius: "50%",
            left: "1206.00px",
            top: "1938.00px",
          }}
        ></div>

        <div
          id="_3323_534__Social_Icons_Google_"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "39.00px",
            width: "39.00px",
            left: "1215.00px",
            top: "1948.00px",
          }}
        >
          <img
            id="_3323_535__Vector"
            src="assets/Landingpageimages/vector_43.svg"
            alt="Vector"
            style={{ position: "absolute" }}
          />
        </div>

        <span
          id="_3323_540__Recruiting_Coordinat"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "351.00px",
            position: "absolute",
            left: "1289.00px",
            top: "1945.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "30.0px",
              fontWeight: "700",
              lineHeight: "150.00%",
            }}
          >
            Recruiting Coordinator
          </span>
        </span>

        <span
          id="_3323_542__Customers_Service"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "164.00px",
            position: "absolute",
            left: "1206.00px",
            top: "2026.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "500",
              lineHeight: "150.00%",
            }}
          >
            Customers Service
          </span>
        </span>
        <span
          id="_3323_543___2_000_-_5_000"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "131.00px",
            position: "absolute",
            left: "1404.00px",
            top: "2026.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "500",
              lineHeight: "150.00%",
            }}
          >
            $2,000 - 5,000
          </span>
        </span>
        <span
          id="_3323_544____Monthly"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "27.00px",
            width: "82.00px",
            position: "absolute",
            left: "1550.00px",
            top: "2026.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(42, 42, 42, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "18.0px",
              fontWeight: "500",
              lineHeight: "150.00%",
            }}
          >
            / Monthly
          </span>
        </span>
        <img
          id="_3323_545__Vector_1"
          src="assets/Landingpageimages/vector_1_6.svg"
          alt="Vector_1"
          style={{ position: "absolute", left: "1387.00px", top: "2026.00px" }}
        />

        <div
          id="_3323_546__Frame_21"
          style={{
            position: "absolute",
            borderColor: "#0c463bff",
            borderStyle: "solid",
            borderWidth: "1px",
            borderRadius: "50px",
            height: "28.00px",
            width: "442.00px",
            left: "1186.00px",
            top: "2115.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_547__Apply_Now"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "105.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(42, 42, 42, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Apply Now
            </span>
          </span>
        </div>

        <div
          id="_3323_548__4960322_app_cogwheel"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "47.00px",
            width: "47.00px",
            left: "1282.00px",
            top: "2902.00px",
          }}
        >
          <img
            id="_3323_550__path1744"
            src="assets/Landingpageimages/path1744.svg"
            alt="path1744"
            style={{
              position: "absolute",
              left: "calc(100% * 0.05)",
              top: "calc(100% * 0.02)",
            }}
          />
        </div>

        <div
          id="_3323_551__2674051_object_web_d"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "36.00px",
            width: "36.00px",
            left: "1008.00px",
            top: "2908.00px",
          }}
        >
          <img
            id="_3323_552__3-Online_Document"
            src="assets/Landingpageimages/3online_document.svg"
            alt="_3-Online_Document"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3323_577__Frame_31"
          style={{
            position: "absolute",
            height: "314.00px",
            width: "515.00px",
            left: "-72.00px",
            top: "3451.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "60px",
          }}
        >
          <div
            id="_3323_578__Group_512944"
            style={{
              position: "relative",
              height: "314.00px",
              width: "515.00px",
            }}
          >
            <div
              id="_3323_579__Rectangle_4537"
              style={{
                position: "absolute",
                background: "rgba(242, 255, 242, 1.00)",
                height: "314.00px",
                width: "440.00px",
                left: "75.00px",
                top: "0.00px",
              }}
            ></div>

            <span
              id="_3323_581__h3"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "32.00px",
                width: "152.00px",
                position: "absolute",
                left: "118.00px",
                top: "52.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(12, 70, 59, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Martel",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "700",
                  lineHeight: "32.00px",
                  letterSpacing: "0.10000000149011612px",
                }}
              >
                Janis Reeves
              </span>
            </span>
            <span
              id="_3323_582__h6"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "24.00px",
                width: "64.00px",
                position: "absolute",
                left: "calc(50% - 139.50px)",
                top: "84.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(114, 114, 114, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Open Sans",
                  fontStyle: "normal",
                  fontSize: "14.0px",
                  fontWeight: "700",
                  lineHeight: "24.00px",
                  letterSpacing: "0.20000000298023224px",
                }}
              >
                Designer
              </span>
            </span>
            <div
              id="_3323_583__Frame_30"
              style={{
                position: "absolute",
                height: "20.00px",
                width: "120.00px",
                left: "118.00px",
                top: "124.83px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "5px",
              }}
            >
              <img
                id="_3323_584__Vector"
                src="assets/Landingpageimages/vector_44.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_585__Vector"
                src="assets/Landingpageimages/vector_45.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_586__Vector"
                src="assets/Landingpageimages/vector_46.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_587__Vector"
                src="assets/Landingpageimages/vector_47.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_588__Vector"
                src="assets/Landingpageimages/vector_48.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
            </div>

            <span
              id="_3323_589__paragraph"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "100.00px",
                width: "352.00px",
                position: "absolute",
                left: "calc(50% - 139.50px)",
                top: "174.00px",
              }}
            >
              <span
                style={{
                  background: "rgba(86, 86, 86, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "14.0px",
                  fontWeight: "400",
                  lineHeight: "20.00px",
                  letterSpacing: "0.20000000298023224px",
                }}
              >
                Lorem ipsum, or lipsum as it is sometimes known, is dummy text
                used in laying out print, graphic or web designs. The passage is
                attributed to an unknown typesetter in the 15th century who is
                thought to have scrambled parts of Cicero&#39;s De
                Finibus&nbsp;&nbsp;&nbsp;
              </span>
            </span>

            <div
              id="_3323_590__cover"
              style={{
                position: "absolute",
                background:
                  "url(assets/Landingpageimages/cover.png) 100% / cover no-repeat",
                borderColor: "#f2fff2ff",
                borderStyle: "solid",
                borderWidth: "4px",
                height: "30.57%",
                width: "18.64%",
                borderRadius: "50%",
                top: "calc(100% * 0.22)",
              }}
            ></div>
          </div>
        </div>

        <div
          id="_3323_591__Frame_31"
          style={{
            position: "absolute",
            height: "314.00px",
            width: "515.00px",
            left: "465.00px",
            top: "3451.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "60px",
          }}
        >
          <div
            id="_3323_592__Group_512944"
            style={{
              position: "relative",
              height: "314.00px",
              width: "515.00px",
            }}
          >
            <div
              id="_3323_593__Rectangle_4537"
              style={{
                position: "absolute",
                background: "rgba(242, 255, 242, 1.00)",
                height: "314.00px",
                width: "440.00px",
                left: "75.00px",
                top: "0.00px",
              }}
            ></div>

            <span
              id="_3323_595__h3"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "32.00px",
                width: "198.00px",
                position: "absolute",
                left: "118.00px",
                top: "52.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(12, 70, 59, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Martel",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "700",
                  lineHeight: "32.00px",
                  letterSpacing: "0.10000000149011612px",
                }}
              >
                Francis Guzman
              </span>
            </span>
            <span
              id="_3323_596__h6"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "24.00px",
                width: "64.00px",
                position: "absolute",
                left: "calc(50% - 139.50px)",
                top: "84.00px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(114, 114, 114, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Open Sans",
                  fontStyle: "normal",
                  fontSize: "14.0px",
                  fontWeight: "700",
                  lineHeight: "24.00px",
                  letterSpacing: "0.20000000298023224px",
                }}
              >
                Designer
              </span>
            </span>
            <div
              id="_3323_597__Frame_30"
              style={{
                position: "absolute",
                height: "20.00px",
                width: "120.00px",
                left: "118.00px",
                top: "124.83px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                gap: "5px",
              }}
            >
              <img
                id="_3323_598__Vector"
                src="assets/Landingpageimages/vector_49.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_599__Vector"
                src="assets/Landingpageimages/vector_50.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_600__Vector"
                src="assets/Landingpageimages/vector_51.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_601__Vector"
                src="assets/Landingpageimages/vector_52.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
              <img
                id="_3323_602__Vector"
                src="assets/Landingpageimages/vector_53.svg"
                alt="Vector"
                style={{ position: "relative" }}
              />
            </div>

            <span
              id="_3323_603__paragraph"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "flex-start",
                height: "100.00px",
                width: "352.00px",
                position: "absolute",
                left: "calc(50% - 139.50px)",
                top: "174.00px",
              }}
            >
              <span
                style={{
                  background: "rgba(86, 86, 86, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "14.0px",
                  fontWeight: "400",
                  lineHeight: "20.00px",
                  letterSpacing: "0.20000000298023224px",
                }}
              >
                Lorem ipsum, or lipsum as it is sometimes known, is dummy text
                used in laying out print, graphic or web designs. The passage is
                attributed to an unknown typesetter in the 15th century who is
                thought to have scrambled parts of Cicero&#39;s De
                Finibus&nbsp;&nbsp;&nbsp;
              </span>
            </span>

            <div
              id="_3323_604__cover"
              style={{
                position: "absolute",
                background:
                  "url(assets/Landingpageimages/cover_3.png) 100% / cover no-repeat, url(assets/Landingpageimages/cover_2.png) 100% / cover no-repeat, url(assets/Landingpageimages/null) 100% / cover no-repeat",
                borderColor: "#f2fff2ff",
                borderStyle: "solid",
                borderWidth: "4px",
                height: "30.57%",
                width: "18.64%",
                borderRadius: "50%",
                top: "calc(100% * 0.22)",
              }}
            ></div>
          </div>
        </div>

        <img
          id="_3323_605__Rectangle_4537"
          src="assets/Landingpageimages/rectangle_4537.svg"
          alt="Rectangle_4537"
          style={{ position: "absolute", left: "1067.00px", top: "3451.00px" }}
        />
        <span
          id="_3323_607__h3"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "32.00px",
            width: "165.00px",
            position: "absolute",
            left: "1117.00px",
            top: "3503.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(12, 70, 59, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "700",
              lineHeight: "32.00px",
              letterSpacing: "0.10000000149011612px",
            }}
          >
            Wilma Taylor
          </span>
        </span>
        <span
          id="_3323_608__h6"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "24.00px",
            width: "64.00px",
            position: "absolute",
            left: "calc(50% + 400.00px)",
            top: "3535.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(114, 114, 114, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Open Sans",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "700",
              lineHeight: "24.00px",
              letterSpacing: "0.20000000298023224px",
            }}
          >
            Designer
          </span>
        </span>
        <div
          id="_3323_609__Frame_30"
          style={{
            position: "absolute",
            height: "20.00px",
            width: "120.00px",
            left: "1117.00px",
            top: "3576.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "5px",
          }}
        >
          <img
            id="_3323_610__Vector"
            src="assets/Landingpageimages/vector_54.svg"
            alt="Vector"
            style={{ position: "relative" }}
          />
          <img
            id="_3323_611__Vector"
            src="assets/Landingpageimages/vector_55.svg"
            alt="Vector"
            style={{ position: "relative" }}
          />
          <img
            id="_3323_612__Vector"
            src="assets/Landingpageimages/vector_56.svg"
            alt="Vector"
            style={{ position: "relative" }}
          />
          <img
            id="_3323_613__Vector"
            src="assets/Landingpageimages/vector_57.svg"
            alt="Vector"
            style={{ position: "relative" }}
          />
          <img
            id="_3323_614__Vector"
            src="assets/Landingpageimages/vector_58.svg"
            alt="Vector"
            style={{ position: "relative" }}
          />
        </div>

        <span
          id="_3323_615__paragraph"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "100.00px",
            width: "352.00px",
            position: "absolute",
            left: "calc(50% + 397.00px)",
            top: "3625.00px",
          }}
        >
          <span
            style={{
              background: "rgba(86, 86, 86, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "14.0px",
              fontWeight: "400",
              lineHeight: "20.00px",
              letterSpacing: "0.20000000298023224px",
            }}
          >
            Lorem ipsum, or lipsum as it is sometimes known, is dummy text used
            in laying out print, graphic or web designs. The passage is
            attributed to an unknown typesetter in the 15th century who is
            thought to have scrambled parts of Cicero&#39;s De
            Finibus&nbsp;&nbsp;&nbsp;
          </span>
        </span>

        <div
          id="_3323_630__Frame_25"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "35.00px",
            width: "156.00px",
            left: "calc(50% - 88.00px)",
            top: "3843.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_631__See_More"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "92.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              See More
            </span>
          </span>
          <div
            id="_3323_632__Arrow___Arrow_Right_"
            style={{
              position: "relative",
              overflow: "hidden",
              height: "24.00px",
              width: "24.00px",
            }}
          >
            <img
              id="I3323_632_3323_106__Vector"
              src="assets/Landingpageimages/vector_59.svg"
              alt="Vector"
              style={{
                position: "absolute",
                left: "calc(100% * 0.13)",
                top: "calc(100% * 0.29)",
              }}
            />
          </div>
        </div>

        <div
          id="_3323_634__Rectangle_4538"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "60px",
            height: "768.00px",
            width: "1286.00px",
            left: "84.00px",
            top: "4095.00px",
          }}
        ></div>

        <div
          id="_3323_635__Frame_26"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "50px",
            height: "35.00px",
            width: "156.00px",
            left: "calc(50% - 84.00px)",
            top: "4764.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3323_636__Message_Us"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "119.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "150.00%",
              }}
            >
              Message Us
            </span>
          </span>
        </div>

        <div
          id="_3323_638__Rectangle_4539"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderRadius: "12px",
            height: "66.42px",
            width: "494.29px",
            left: "792.71px",
            top: "4236.00px",
          }}
        ></div>

        <div
          id="_3323_639__Rectangle_4540"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderRadius: "12px",
            height: "66.42px",
            width: "494.29px",
            left: "167.00px",
            top: "4236.00px",
          }}
        ></div>

        <div
          id="_3323_640__Rectangle_4541"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderRadius: "12px",
            height: "66.42px",
            width: "494.29px",
            left: "167.00px",
            top: "4371.85px",
          }}
        ></div>

        <div
          id="_3323_641__Rectangle_4543"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderRadius: "12px",
            height: "205.29px",
            width: "1120.00px",
            left: "167.00px",
            top: "4507.71px",
          }}
        ></div>

        <div
          id="_3323_642__Rectangle_4542"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            borderRadius: "12px",
            height: "66.42px",
            width: "494.29px",
            left: "792.71px",
            top: "4371.85px",
          }}
        ></div>

        <span
          id="_3323_643__Last_Name_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "30.00px",
            width: "135.00px",
            position: "absolute",
            left: "827.00px",
            top: "4254.00px",
          }}
        >
          <span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(81, 81, 81, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              Last Name
            </span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(250, 25, 25, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              *
            </span>
          </span>
        </span>
        <span
          id="_3323_644__First_Name_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "30.00px",
            width: "137.00px",
            position: "absolute",
            left: "201.00px",
            top: "4254.00px",
          }}
        >
          <span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(81, 81, 81, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              First Name
            </span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(250, 25, 25, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              *
            </span>
          </span>
        </span>
        <span
          id="_3323_645__Email_Address_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "30.00px",
            width: "190.00px",
            position: "absolute",
            left: "201.00px",
            top: "4390.00px",
          }}
        >
          <span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(81, 81, 81, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              Email Address
            </span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(250, 25, 25, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              *
            </span>
          </span>
        </span>
        <span
          id="_3323_646__Message"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "29.87px",
            width: "137.14px",
            position: "absolute",
            left: "201.29px",
            top: "4525.79px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(81, 81, 81, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Inter",
              fontStyle: "normal",
              fontSize: "20.0px",
              fontWeight: "500",
              lineHeight: "150.00%",
            }}
          >
            Message
          </span>
        </span>
        <span
          id="_3323_647__Location_"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "30.00px",
            width: "135.00px",
            position: "absolute",
            left: "827.00px",
            top: "4390.00px",
          }}
        >
          <span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(81, 81, 81, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              Location
            </span>
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(250, 25, 25, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "500",
                lineHeight: "150.00%",
              }}
            >
              *
            </span>
          </span>
        </span>
        <div
          id="_3323_648__Arrow___Caret_Down_M"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "28.18px",
            width: "20.91px",
            left: "1248.17px",
            top: "4255.12px",
          }}
        >
          <img
            id="_3323_649__Vector"
            src="assets/Landingpageimages/vector_60.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.33)",
              top: "calc(100% * 0.42)",
            }}
          />
        </div>

        <div
          id="_3323_650__Arrow___Caret_Down_M"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "28.18px",
            width: "20.91px",
            left: "622.47px",
            top: "4255.12px",
          }}
        >
          <img
            id="I3323_650_3323_649__Vector"
            src="assets/Landingpageimages/vector_61.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.33)",
              top: "calc(100% * 0.42)",
            }}
          />
        </div>

        <div
          id="_3323_651__Arrow___Caret_Down_M"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "28.18px",
            width: "20.91px",
            left: "622.47px",
            top: "4390.97px",
          }}
        >
          <img
            id="I3323_651_3323_649__Vector"
            src="assets/Landingpageimages/vector_62.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.33)",
              top: "calc(100% * 0.42)",
            }}
          />
        </div>

        <div
          id="_3323_652__Arrow___Caret_Down_M"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "28.18px",
            width: "20.91px",
            left: "1248.17px",
            top: "4390.97px",
          }}
        >
          <img
            id="I3323_652_3323_649__Vector"
            src="assets/Landingpageimages/vector_63.svg"
            alt="Vector"
            style={{
              position: "absolute",
              left: "calc(100% * 0.33)",
              top: "calc(100% * 0.42)",
            }}
          />
        </div>

        <div
          id="_3323_653__Footer"
          style={{
            position: "absolute",
            background: "rgba(18, 18, 18, 1.00)",
            height: "548.00px",
            width: "1436.00px",
            left: "2.00px",
            top: "5167.00px",
          }}
        >
          <span
            id="_3323_655__Heading_3___Company"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "71.00px",
              width: "118.00px",
              position: "absolute",
              left: "122.00px",
              top: "39.00px",
            }}
          >
            <span
              style={{
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Martel",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "28.00px",
              }}
            >
              Company
            </span>
          </span>
          <span
            id="_3323_656__Item___Link___About"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "78.00px",
              width: "78.00px",
              position: "absolute",
              left: "122.00px",
              top: "111.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Jobs
            </span>
          </span>
          <span
            id="_3323_657__Item___Link___Featur"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "78.00px",
              width: "118.00px",
              position: "absolute",
              left: "122.00px",
              top: "171.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Categories
            </span>
          </span>
          <span
            id="_3323_660__Heading_3___Help"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "71.00px",
              width: "82.00px",
              position: "absolute",
              left: "414.00px",
              top: "39.00px",
            }}
          >
            <span
              style={{
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Martel",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "28.00px",
              }}
            >
              Help
            </span>
          </span>
          <span
            id="_3323_661__Item___Link___Custom"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "78.00px",
              width: "168.00px",
              position: "absolute",
              left: "414.00px",
              top: "111.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Customer Support
            </span>
          </span>
          <span
            id="_3323_662__Item___Link___Delive"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "78.00px",
              width: "140.00px",
              position: "absolute",
              left: "414.00px",
              top: "171.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Contact Us
            </span>
          </span>
          <span
            id="_3323_663__Item___Link___Terms_"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "77.00px",
              width: "168.00px",
              position: "absolute",
              left: "414.00px",
              top: "231.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Terms &amp; Conditions
            </span>
          </span>
          <span
            id="_3323_664__Item___Link___Privac"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "77.00px",
              width: "140.00px",
              position: "absolute",
              left: "414.00px",
              top: "291.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Privacy Policy
            </span>
          </span>
          <span
            id="_3323_665__Heading_3___Resource"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "71.00px",
              width: "124.00px",
              position: "absolute",
              left: "756.00px",
              top: "39.00px",
            }}
          >
            <span
              style={{
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Martel",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "28.00px",
              }}
            >
              Resources
            </span>
          </span>
          <span
            id="_3323_666__Item___Link___About"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "78.00px",
              width: "69.00px",
              position: "absolute",
              left: "756.00px",
              top: "111.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Jobs
            </span>
          </span>
          <span
            id="_3323_667__Item___Link___Featur"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "78.00px",
              width: "124.00px",
              position: "absolute",
              left: "756.00px",
              top: "171.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Categories
            </span>
          </span>
          <span
            id="_3323_670__Heading_3___Resource"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "71.00px",
              width: "110.00px",
              position: "absolute",
              left: "1054.34px",
              top: "39.00px",
            }}
          >
            <span
              style={{
                background: "rgba(242, 255, 242, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Martel",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "600",
                lineHeight: "28.00px",
              }}
            >
              Resources
            </span>
          </span>
          <span
            id="_3323_671____Copyright_2025__Al"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "26.00px",
              width: "497.00px",
              position: "absolute",
              left: "calc(50% - 249.00px)",
              top: "475.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "500",
                lineHeight: "30.06px",
              }}
            >
              © Copyright 2025, All Rights Reserved by JobFiesta
            </span>
          </span>
          <div
            id="_3323_672__List"
            style={{
              position: "absolute",
              height: "38.08px",
              width: "133.17px",
              left: "1182.00px",
              top: "469.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "12px",
            }}
          >
            <div
              id="_3323_673__Item___Link"
              style={{
                position: "relative",
                background: "rgba(255, 255, 255, 0.10)",
                borderRadius: "500px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                padding: "8px 10px",
              }}
            >
              <span
                id="_3323_674___"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "center",
                  height: "13.00px",
                  width: "9.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(242, 255, 242, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Font Awesome 5 Brands",
                    fontStyle: "normal",
                    fontSize: "13.0px",
                    fontWeight: "400",
                    lineHeight: "13.00px",
                  }}
                >
                  
                </span>
              </span>
            </div>

            <div
              id="_3323_675__Item___Link"
              style={{
                position: "relative",
                background: "rgba(255, 255, 255, 0.10)",
                borderRadius: "500px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                padding: "8px",
              }}
            >
              <span
                id="_3323_676___"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "center",
                  height: "13.00px",
                  width: "13.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(242, 255, 242, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Font Awesome 5 Brands",
                    fontStyle: "normal",
                    fontSize: "13.0px",
                    fontWeight: "400",
                    lineHeight: "13.00px",
                  }}
                >
                  
                </span>
              </span>
            </div>

            <div
              id="_3323_677__Item___Link"
              style={{
                position: "relative",
                background: "rgba(255, 255, 255, 0.10)",
                borderRadius: "500px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                padding: "8px 8px 8px 9px",
              }}
            >
              <span
                id="_3323_678___"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "center",
                  height: "13.00px",
                  width: "12.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(242, 255, 242, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Font Awesome 5 Brands",
                    fontStyle: "normal",
                    fontSize: "13.0px",
                    fontWeight: "400",
                    lineHeight: "13.00px",
                  }}
                >
                  
                </span>
              </span>
            </div>

            <div
              id="_3323_679__Item___Link"
              style={{
                position: "relative",
                background: "rgba(255, 255, 255, 0.10)",
                borderRadius: "500px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                padding: "8px",
              }}
            >
              <span
                id="_3323_680___"
                style={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textAlign: "left",
                  alignItems: "center",
                  height: "13.00px",
                  width: "13.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(242, 255, 242, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Font Awesome 5 Brands",
                    fontStyle: "normal",
                    fontSize: "13.0px",
                    fontWeight: "400",
                    lineHeight: "13.00px",
                  }}
                >
                  
                </span>
              </span>
            </div>
          </div>

          <img
            id="_3323_690__Vector_7072"
            src="assets/Landingpageimages/vector_7072.svg"
            alt="Vector_7072"
            style={{ position: "absolute", left: "-25.00px", top: "431.79px" }}
          />
          <span
            id="_3323_692__Item___Link___Custom"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "91.00px",
              width: "217.93px",
              position: "absolute",
              left: "1054.42px",
              top: "111.00px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Customer Support
            </span>
          </span>
          <span
            id="_3323_693__Item___Link___Delive"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "90.42px",
              width: "112.89px",
              position: "absolute",
              left: "1054.00px",
              top: "181.10px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Contact Us
            </span>
          </span>
          <span
            id="_3323_694__Item___Link___Terms_"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "90.42px",
              width: "195.21px",
              position: "absolute",
              left: "1054.00px",
              top: "250.84px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Terms &amp; Conditions
            </span>
          </span>
          <span
            id="_3323_695__Item___Link___Privac"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "90.42px",
              width: "139.94px",
              position: "absolute",
              left: "1054.00px",
              top: "320.58px",
            }}
          >
            <span
              style={{
                background: "rgba(255, 255, 255, 0.80)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "18.0px",
                fontWeight: "400",
                lineHeight: "30.06px",
              }}
            >
              Privacy Policy
            </span>
          </span>

          <img
            id="_3323_696__Group"
            src="assets/Landingpageimages/group_22.svg"
            alt="Group"
            style={{
              position: "absolute",
              left: "calc(100% * 0.88)",
              top: "calc(100% * 0.25)",
            }}
          />
        </div>

        <img
          id="_3323_704__Group"
          src="assets/Landingpageimages/group_23.svg"
          alt="Group"
          style={{
            position: "absolute",
            left: "calc(100% * 0.01)",
            top: "calc(100% * 0.85)",
          }}
        />
        <img
          id="_3323_732__Group"
          src="assets/Landingpageimages/group_24.svg"
          alt="Group"
          style={{
            position: "absolute",
            left: "calc(100% * 0.79)",
            top: "calc(100% * 0.68)",
          }}
        />
        <div
          id="_3323_734__9264933_web_design_d"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "39.00px",
            width: "39.00px",
            left: "1560.00px",
            top: "2903.00px",
          }}
        >
          <img
            id="_3323_737__web_design"
            src="assets/Landingpageimages/web_design.svg"
            alt="web_design"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3323_738__5355692_code_coding_"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "44.00px",
            width: "44.00px",
            left: "443.00px",
            top: "2900.00px",
          }}
        >
          <img
            id="_3323_741__Development"
            src="assets/Landingpageimages/development.svg"
            alt="Development"
            style={{ position: "absolute" }}
          />
        </div>

        <div
          id="_3323_751__Ellipse_8"
          style={{
            position: "absolute",
            background: "rgba(247, 247, 247, 1.00)",
            height: "87.00px",
            width: "87.00px",
            borderRadius: "50%",
            left: "704.00px",
            top: "2882.00px",
            boxShadow: "0.0px 0.0px 10.0px 0.0px rgba(0, 0, 0, 0.15)",
          }}
        ></div>

        <div
          id="_3323_752__7898409_promotion_bu"
          style={{
            position: "absolute",
            overflow: "hidden",
            height: "55.00px",
            width: "55.00px",
            left: "722.00px",
            top: "2900.00px",
          }}
        >
          <img
            id="_3323_753__g2869"
            src="assets/Landingpageimages/g2869.svg"
            alt="g2869"
            style={{
              position: "absolute",
              left: "calc(100% * 0.06)",
              top: "calc(100% * 0.13)",
            }}
          />
        </div>

        <div
          id="_3323_629__cover"
          style={{
            position: "absolute",
            background:
              "url(assets/Landingpageimages/cover_5.png) 100% / cover no-repeat, url(assets/Landingpageimages/null) 100% / cover no-repeat",
            borderColor: "#ffffffff",
            borderStyle: "solid",
            borderWidth: "4px",
            height: "1.68%",
            width: "5.79%",
            borderRadius: "50%",
            left: "calc(100% * 0.70)",
            top: "calc(100% * 0.62)",
          }}
        ></div>

        <span
          id="_3331_917__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "52.00px",
            position: "absolute",
            left: "114.00px",
            top: "5641.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(203, 203, 203, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job&nbsp;
          </span>
        </span>
        <span
          id="_3331_918__Fiesta"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "126.00px",
            position: "absolute",
            left: "160.00px",
            top: "5636.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(203, 203, 203, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>
      </div>
    </>
  );
};
export default LandingPage;
