import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const PostJobPage = () => {
  const navigate = useNavigate();
  const { user, token } = useAuth();
  const [formData, setFormData] = useState({
    title: "",
    roleType: "",
    companyName: "",
    location: "",
    salaryRange: "",
    workEnvironment: "",
    applicationProcess: "",
    maritalStatus: "",
    gender: "",
    jobType: "",
    jobBenefits: "",
    applicationDeadline: "",
    experienceLevel: "",
    terms1: "",
    terms2: "",
    skillsRequired: [""],
    description: "",
  });
  const [error, setError] = useState(null);

  // Redirect if not a recruiter
  useEffect(() => {
    if (!user || user.userType !== "recruiter") {
      setError("Only recruiters can post jobs");
      navigate("/login");
    }
  }, [user, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSkillChange = (index, value) => {
    const newSkills = [...formData.skillsRequired];
    newSkills[index] = value;
    setFormData({ ...formData, skillsRequired: newSkills });
  };

  const addSkill = () => {
    setFormData({ ...formData, skillsRequired: [...formData.skillsRequired, ""] });
  };

  const removeSkill = (index) => {
    if (formData.skillsRequired.length > 1) {
      const newSkills = formData.skillsRequired.filter((_, i) => i !== index);
      setFormData({ ...formData, skillsRequired: newSkills });
    }
  };

  const handleSubmit = async () => {
    setError(null);
    // Validate required fields
    if (!formData.title || !formData.description || !formData.terms1 || !formData.terms2 || !formData.skillsRequired[0] || !formData.location) {
      setError("Please fill all required fields (Title, Description, Location, Terms, and at least one Skill)");
      return;
    }
    try {
      const response = await fetch("http://localhost:5000/api/jobs/post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });
      const result = await response.json();
      if (response.ok) {
        navigate("/recruiter-dashboard");
      } else {
        throw new Error(result.message || "Failed to post job");
      }
    } catch (err) {
      setError(err.message);
      console.error("Post job error:", err);
    }
  };

  const handleCancel = () => {
    navigate("/recruiter-dashboard");
  };

  return (
    <>
      <div
        id="_3345_7652__Post_Job_Page"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          borderRadius: "15px",
          height: "2289.0px",
          width: "100%",
        }}
      >
        {error && (
          <div
            style={{
              color: "red",
              position: "absolute",
              left: "calc(50% - 600px)",
              top: "260px",
              fontFamily: "Poppins",
              fontSize: "20px",
            }}
          >
            {error}
          </div>
        )}
        <span
          id="_3327_3147__Post_a_job"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "222.00px",
            position: "absolute",
            left: "calc(50% - 600.00px)",
            top: "154.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              color: "#303030",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Post a job
          </span>
        </span>
        <span
          id="_3327_3148__Find_the_best_talent"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "22.00px",
            width: "413.00px",
            position: "absolute",
            left: "calc(50% - 600.00px)",
            top: "219.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(94, 102, 112, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              color: "#5E6670",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "22.0px",
              fontWeight: "400",
              lineHeight: "22.00px",
            }}
          >
            Find the best talent for your company
          </span>
        </span>

        <div
          id="_3378_2585__Rectangle_4"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "40px",
            boxShadow: "0.0px 10.0px 40.0px 0.0px rgba(0, 0, 0, 0.15)",
            height: "1951.00px",
            width: "1267.00px",
            left: "calc(50% - 634.00px)",
            top: "289.00px",
          }}
        ></div>

        <button
          id="_3327_3216__Button__Post_"
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "82.00px",
            width: "320.00px",
            left: "814.00px",
            top: "2040.00px",
            border: "none",
            cursor: "pointer",
          }}
          onClick={handleSubmit}
        >
          <span
            id="_3327_3217__Post_Job"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "center",
              height: "46.00px",
              width: "144.00px",
              position: "absolute",
              left: "calc(50% - 72.00px)",
              top: "22.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#ffffff",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "33.74409866333008px",
                fontWeight: "700",
                lineHeight: "45.29px",
              }}
            >
              Post Job
            </span>
          </span>
        </button>

        <button
          id="_3347_7631__Button__submitbtn_"
          style={{
            position: "absolute",
            background: "rgba(233, 25, 29, 1.00)",
            borderRadius: "15px",
            height: "82.00px",
            width: "320.00px",
            left: "236.00px",
            top: "2040.00px",
            border: "none",
            cursor: "pointer",
          }}
          onClick={handleCancel}
        >
          <span
            id="_3347_7632__Cancel"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "center",
              height: "41.00px",
              width: "104.00px",
              position: "absolute",
              left: "calc(50% - 52.00px)",
              top: "20.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#ffffff",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "30.45404624938965px",
                fontWeight: "700",
                lineHeight: "40.88px",
              }}
            >
              Cancel
            </span>
          </span>
        </button>

        <div
          id="_3347_7634__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "396.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="title"
            placeholder="Enter Job Title"
            value={formData.title}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7637__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "781.00px",
            top: "395.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="roleType"
            placeholder="Enter Type of Role"
            value={formData.roleType}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7640__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "538.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="companyName"
            placeholder="Enter Company Name"
            value={formData.companyName}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7643__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "790.00px",
            top: "538.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="location"
            placeholder="Enter Location"
            value={formData.location}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7646__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "685.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="salaryRange"
            placeholder="Enter Salary Range"
            value={formData.salaryRange}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7649__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "832.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="workEnvironment"
            placeholder="Enter Work Environment"
            value={formData.workEnvironment}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7652__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "166.00px",
            top: "974.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="applicationProcess"
            placeholder="Enter Job Application Process"
            value={formData.applicationProcess}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7658__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "170.00px",
            top: "1121.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="maritalStatus"
            placeholder="Enter Marital Status"
            value={formData.maritalStatus}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7661__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "781.00px",
            top: "1124.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="gender"
            placeholder="Enter Required Gender"
            value={formData.gender}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7664__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "790.00px",
            top: "676.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="jobType"
            placeholder="Enter Job Type"
            value={formData.jobType}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7667__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "790.00px",
            top: "835.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="text"
            name="jobBenefits"
            placeholder="Enter Job Benefits"
            value={formData.jobBenefits}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3347_7670__Input__password_"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderColor: "#e7e7f1ff",
            borderStyle: "solid",
            borderWidth: "2.043895721435547px",
            borderRadius: "15px",
            height: "88.91px",
            width: "472.91px",
            left: "781.00px",
            top: "974.00px",
            display: "flex",
            alignItems: "center",
            padding: "0 17px",
          }}
        >
          <input
            type="date"
            name="applicationDeadline"
            value={formData.applicationDeadline}
            onChange={handleInputChange}
            style={{
              border: "none",
              outline: "none",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3357_5266__Menu_with_Text_field"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "296.00px",
            width: "332.00px",
            left: "166.00px",
            top: "1254.00px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            padding: "8px 0px 0px 0px",
          }}
        >
          <span
            id="_3353_5692__Job_Experience_Level"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "253.00px",
              position: "relative",
              top: "0px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#121224",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Job Experience Level
            </span>
          </span>
          <select
            name="experienceLevel"
            value={formData.experienceLevel}
            onChange={handleInputChange}
            style={{
              border: "3px solid #65558f",
              borderRadius: "4px",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "100%",
              height: "56px",
              padding: "4px 16px",
              marginTop: "8px",
            }}
          >
            <option value="">Select Experience Level</option>
            <option value="Beginner">Beginner level</option>
            <option value="Advanced">Advanced level</option>
          </select>
        </div>

        <div
          id="_3353_5693__Div__formField_"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "299.00px",
            width: "512.00px",
            left: "170.00px",
            top: "1478.00px",
          }}
        >
          <span
            id="_3353_5695__Terms_and_Conditions"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "280.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(240, 65, 65, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#F04141",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Terms and Conditions*
            </span>
          </span>

          <div
            id="_3353_5696__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "88.91px",
              width: "472.91px",
              left: "0.00px",
              top: "59.00px",
              display: "flex",
              alignItems: "center",
              padding: "0 17px",
            }}
          >
            <input
              type="text"
              name="terms1"
              placeholder="Enter Condition 1"
              value={formData.terms1}
              onChange={handleInputChange}
              style={{
                border: "none",
                outline: "none",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24px",
                fontWeight: "400",
                lineHeight: "24px",
                color: "#121224",
                width: "100%",
                background: "transparent",
              }}
            />
          </div>

          <div
            id="_3353_5701__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "8px",
              height: "88.91px",
              width: "472.91px",
              left: "0.00px",
              top: "164.00px",
              display: "flex",
              alignItems: "center",
              padding: "0 17px",
            }}
          >
            <input
              type="text"
              name="terms2"
              placeholder="Enter Condition 2"
              value={formData.terms2}
              onChange={handleInputChange}
              style={{
                border: "none",
                outline: "none",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24px",
                fontWeight: "400",
                lineHeight: "24px",
                color: "#121224",
                width: "100%",
                background: "transparent",
              }}
            />
          </div>
        </div>

        <div
          id="_3347_8589__Div__formField_"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "355.00px",
            width: "512.00px",
            left: "781.00px",
            top: "1323.00px",
          }}
        >
          <span
            id="_3347_8591__Skills_Required__"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "193.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(240, 65, 65, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#F04141",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Skills Required *
            </span>
          </span>

          {formData.skillsRequired.map((skill, index) => (
            <div
              key={index}
              id={`_3347_8592__Input__skill_${index}`}
              style={{
                position: "absolute",
                background: "rgba(255, 255, 255, 1.00)",
                borderColor: "#e7e7f1ff",
                borderStyle: "solid",
                borderWidth: "2.043895721435547px",
                borderRadius: "8px",
                height: "88.91px",
                width: "472.91px",
                left: "0.00px",
                top: `${59 + index * 105}px`,
                display: "flex",
                alignItems: "center",
                padding: "0 17px",
              }}
            >
              <input
                type="text"
                placeholder={`Enter Skill ${index + 1}`}
                value={skill}
                onChange={(e) => handleSkillChange(index, e.target.value)}
                style={{
                  border: "none",
                  outline: "none",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24px",
                  fontWeight: "400",
                  lineHeight: "24px",
                  color: "#121224",
                  width: "80%",
                  background: "transparent",
                }}
              />
              {formData.skillsRequired.length > 1 && (
                <button
                  onClick={() => removeSkill(index)}
                  style={{
                    border: "none",
                    background: "transparent",
                    color: "#E9191D",
                    fontFamily: "Poppins",
                    fontSize: "20px",
                    cursor: "pointer",
                  }}
                >
                  Remove
                </button>
              )}
            </div>
          ))}

          <button
            id="_3378_2587__Skill__"
            onClick={addSkill}
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "71.00px",
              position: "absolute",
              left: "17.00px",
              top: `${59 + formData.skillsRequired.length * 105}px`,
              border: "none",
              background: "transparent",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(0, 0, 0, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#000000",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "500",
                lineHeight: "24.00px",
              }}
            >
              Skill +
            </span>
          </button>
        </div>

        <div
          id="_3353_5706__Div__formInput_"
          style={{
            position: "absolute",
            borderRadius: "15px",
            height: "177.00px",
            width: "1083.00px",
            left: "135.00px",
            top: "1823.00px",
          }}
        >
          <span
            id="_3353_5708__Job_Description_"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "24.00px",
              width: "201.00px",
              position: "absolute",
              left: "0.00px",
              top: "4.98px",
            }}
          >
            <span>
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(48, 48, 48, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  color: "#303030",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "500",
                  lineHeight: "24.00px",
                }}
              >
                Job Description
              </span>
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(240, 65, 65, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  color: "#F04141",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "500",
                  lineHeight: "24.00px",
                }}
              >
                *
              </span>
            </span>
          </span>
          <textarea
            name="description"
            placeholder="Enter Job Description"
            value={formData.description}
            onChange={handleInputChange}
            style={{
              border: "2.043895721435547px solid #e7e7f1ff",
              borderRadius: "8px",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "24px",
              fontWeight: "400",
              lineHeight: "24px",
              color: "#121224",
              width: "calc(100% - 34px)",
              height: "89.91px",
              padding: "17px",
              resize: "vertical",
              background: "transparent",
            }}
          />
        </div>

        <div
          id="_3353_5712__arrow_back"
          style={{
            position: "absolute",
            height: "24.00px",
            width: "24.00px",
            left: "41.00px",
            top: "121.00px",
          }}
        >
          <img
            id="I3353_5712_54616_25400__icon"
            src="assets/jobpostimages/icon.svg"
            alt="icon"
            style={{
              position: "absolute",
              left: "calc(100% * 0.17)",
              top: "calc(100% * 0.17)",
            }}
          />
        </div>

        <div
          id="_3356_6163__Rectangle_1"
          style={{
            position: "absolute",
            background: "rgba(242, 255, 242, 1.00)",
            height: "89.00px",
            width: "1449.00px",
            left: "-9.00px",
            top: "-10.00px",
          }}
        ></div>

        <div
          id="_3356_6200__Frame_27"
          style={{
            position: "absolute",
            height: "50.00px",
            width: "345.65px",
            left: "calc(50% - 180.59px)",
            top: "17.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            gap: "20px",
          }}
        >
          <div
            id="_3356_6201__Frame_5"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3356_6202__Home"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "58.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  color: "#282828",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "700",
                  lineHeight: "150.00%",
                }}
              >
                Home
              </span>
            </span>
          </div>

          <div
            id="_3356_6203__Frame_4"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3356_6204__Jobs"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "47.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  color: "#282828",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Jobs
              </span>
            </span>
          </div>

          <div
            id="_3356_6205__Frame_3"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          >
            <span
              id="_3356_6206__Categories"
              style={{
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "flex-start",
                height: "30.00px",
                width: "105.00px",
                position: "relative",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(40, 40, 40, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  color: "#282828",
                  fontFamily: "Inter",
                  fontStyle: "normal",
                  fontSize: "20.0px",
                  fontWeight: "500",
                  lineHeight: "150.00%",
                }}
              >
                Categories
              </span>
            </span>
          </div>

          <div
            id="_3356_6207__Frame_10"
            style={{
              position: "relative",
              height: "30.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              gap: "10px",
              padding: "10px",
            }}
          ></div>
        </div>

        <div
          id="_3356_6209__Frame_10"
          style={{
            position: "absolute",
            height: "30.00px",
            width: "85.66px",
            left: "1120.01px",
            top: "17.00px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            gap: "10px",
            padding: "10px",
          }}
        >
          <span
            id="_3356_6210__Browse_jobs"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "30.00px",
              width: "120.00px",
              position: "relative",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(12, 70, 59, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                color: "#0C463B",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "20.0px",
                fontWeight: "700",
                lineHeight: "150.00%",
              }}
            >
              Browse jobs
            </span>
          </span>
        </div>

        <span
          id="_3356_6211__Job"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "52.00px",
            position: "absolute",
            left: "30.00px",
            top: "24.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              color: "#000000",
              fontFamily: "Martel",
              fontStyle: "normal",
              fontSize: "24.0px",
              fontWeight: "900",
              lineHeight: "150.00%",
            }}
          >
            Job
          </span>
        </span>
        <span
          id="_3356_6212__Fiesta"
          style={{
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
            alignItems: "flex-start",
            height: "33.00px",
            width: "124.00px",
            position: "absolute",
            left: "76.00px",
            top: "19.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(0, 0, 0, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              color: "#000000",
              fontFamily: "Matura MT Script Capitals",
              fontStyle: "normal",
              fontSize: "32.0px",
              fontWeight: "400",
              lineHeight: "150.00%",
            }}
          >
            Fiesta
          </span>
        </span>
      </div>
    </>
  );
};

export default PostJobPage;