import { useNavigate } from "react-router-dom";
import React, { useState } from "react";
import { Link } from "react-router-dom"
const ViewApplicationsPage = () => {
  const navigate = useNavigate();
  const [jobTitle, setJobTitle] = useState("Software Engineer");
  const [location, setLocation] = useState("Karachi, Pakistan");
  const [jobType, setJobType] = useState("Full-Time");
  const [salaryRange, setSalaryRange] = useState("PKR 100,000 - 150,000");
  const [preferredIndustry, setPreferredIndustry] = useState("Technology");
  const [education, setEducation] = useState("BSc Computer Science");
  const [gender, setGender] = useState("Male");
  const [city, setCity] = useState("Karachi");
  const [languages, setLanguages] = useState("English, Urdu");
  const [institution, setInstitution] = useState("University of Karachi");
  const [completionYear, setCompletionYear] = useState("2023");
  const [address, setAddress] = useState("123 Tech Street, Karachi");
  const [experienceLevel, setExperienceLevel] = useState("Beginner");
  const [goals, setGoals] = useState("To grow as a software developer");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = {
      jobTitle,
      location,
      jobType,
      salaryRange,
      preferredIndustry,
      education,
      gender,
      city,
      languages,
      institution,
      completionYear,
      address,
      experienceLevel,
      goals,
    };

    try {
      const response = await fetch("http://localhost:5000/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (response.ok) {
        alert("Application details updated successfully!");
        navigate("/RecruiterDashBoardPage");
      } else {
        throw new Error("Failed to update application details");
      }
    } catch (error) {
      console.error("Error updating application details:", error);
      alert("Error updating application details");
    }
  };

  return (
    <>
      <div
        id="_3362_5325__View_Applications_Pa"
        style={{
          position: "absolute",
          overflow: "hidden",
          background: "rgba(255, 255, 255, 1.00)",
          borderRadius: "15px",
          height: "2289.0px",
          width: "100%",
        }}
      >
        <span
          id="_3362_5327__Applicant_Name__Reha"
          style={{
            display: "flex",
            justifyContent: "flex-start",
            textAlign: "left",
            alignItems: "flex-start",
            height: "45.00px",
            width: "542.00px",
            position: "absolute",
            left: "calc(50% - 592.00px)",
            top: "165.00px",
          }}
        >
          <span
            style={{
              whiteSpace: "nowrap",
              background: "rgba(48, 48, 48, 1.00)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              textFillColor: "transparent",
              WebkitTextFillColor: "transparent",
              fontFamily: "Poppins",
              fontStyle: "normal",
              fontSize: "45.0px",
              fontWeight: "600",
              lineHeight: "45.00px",
            }}
          >
            Applicant Name: Rehan
          </span>
        </span>
        <div
          id="_3378_2608__Rectangle_5"
          style={{
            position: "absolute",
            background: "rgba(255, 255, 255, 1.00)",
            borderRadius: "40px",
            boxShadow: "0.0px 10.0px 40.0px 0.0px rgba(0, 0, 0, 0.15)",
            height: "1931.00px",
            width: "1311.00px",
            left: "calc(50% - 646.00px)",
            top: "269.00px",
          }}
        ></div>

        <div
          id="_3362_5328__Button__Post_"
          onClick={() => navigate("/chat-Interface1")}
          style={{
            position: "absolute",
            background: "rgba(12, 70, 59, 1.00)",
            borderRadius: "15px",
            height: "90.86px",
            width: "320.00px",
            left: "794.00px",
            top: "1994.00px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5329__Message"
            onClick={() => navigate("/chat-Interface1")}
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "46.00px",
              width: "151.00px",
              position: "absolute",
              left: "calc(50% - 72.00px)",
              top: "22.00px",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "33.74409866333008px",
                fontWeight: "700",
                lineHeight: "45.29px",
              }}
            >
              Message
            </span>
          </span>
        </div>

        <div
          id="_3362_5330__Button__submitbtn_"
          onClick={() => navigate("/RecruiterDashBoardPage")}
          style={{
            position: "absolute",
            background: "rgba(233, 25, 29, 1.00)",
            borderRadius: "15px",
            height: "90.00px",
            width: "320.00px",
            left: "268.00px",
            top: "1995.00px",
            cursor: "pointer",
          }}
        >
          <span
            id="_3362_5331__Cancel"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              height: "41.00px",
              width: "104.00px",
              position: "absolute",
              left: "calc(50% - 52.00px)",
              top: "20.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(255, 255, 255, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Inter",
                fontStyle: "normal",
                fontSize: "30.45404624938965px",
                fontWeight: "700",
                lineHeight: "40.88px",
              }}
            >
              Cancel
            </span>
          </span>
        </div>

        <form onSubmit={handleSubmit}>
          <div
            id="_3362_5332__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "169.00px",
              top: "324.00px",
            }}
          >
            <input
              type="text"
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              placeholder="Job Title"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5334__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "777.00px",
              top: "324.00px",
            }}
          >
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Location"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5336__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "169.00px",
              top: "479.00px",
            }}
          >
            <input
              type="text"
              value={jobType}
              onChange={(e) => setJobType(e.target.value)}
              placeholder="Job Type"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5338__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "771.00px",
              top: "479.00px",
            }}
          >
            <input
              type="text"
              value={salaryRange}
              onChange={(e) => setSalaryRange(e.target.value)}
              placeholder="Desired Salary Range"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5341__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "169.00px",
              top: "634.00px",
            }}
          >
            <input
              type="text"
              value={preferredIndustry}
              onChange={(e) => setPreferredIndustry(e.target.value)}
              placeholder="Preferred Industry"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5344__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "169.00px",
              top: "789.00px",
            }}
          >
            <input
              type="text"
              value={education}
              onChange={(e) => setEducation(e.target.value)}
              placeholder="Education"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5347__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "169.00px",
              top: "944.00px",
            }}
          >
            <input
              type="text"
              value={gender}
              onChange={(e) => setGender(e.target.value)}
              placeholder="Gender"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5349__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "777.00px",
              top: "1156.00px",
            }}
          >
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="City"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5351__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "777.00px",
              top: "633.00px",
            }}
          >
            <input
              type="text"
              value={languages}
              onChange={(e) => setLanguages(e.target.value)}
              placeholder="Languages"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5353__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "771.00px",
              top: "792.00px",
            }}
          >
            <input
              type="text"
              value={institution}
              onChange={(e) => setInstitution(e.target.value)}
              placeholder="Institution"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5355__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "472.91px",
              left: "777.00px",
              top: "944.00px",
            }}
          >
            <input
              type="text"
              value={completionYear}
              onChange={(e) => setCompletionYear(e.target.value)}
              placeholder="Completion Year"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "472.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3362_5358__Div__formField_"
            style={{
              position: "absolute",
              height: "239.00px",
              width: "413.00px",
              left: "871.00px",
              top: "1384.00px",
            }}
          >
            <span
              id="_3362_5360__Download_Resume__"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "center",
                height: "24.00px",
                width: "245.00px",
                position: "absolute",
                left: "0.00px",
                top: "4.98px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(240, 65, 65, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "500",
                  lineHeight: "24.00px",
                }}
              >
                Download Resume *
              </span>
            </span>

            <div
              id="_3363_5316__Download"
              style={{
                position: "absolute",
                overflow: "hidden",
                height: "48.00px",
                width: "48.00px",
                left: "260.00px",
                top: "-7.00px",
              }}
            >
              <img
                id="I3363_5316_7758_11498__Icon"
                src="assets/images/icon_21.svg"
                alt="Icon"
                style={{
                  position: "absolute",
                  left: "calc(100% * 0.13)",
                  top: "calc(100% * 0.13)",
                }}
              />
            </div>
          </div>

          <span
            id="_3362_5346__Job_Experience_Level"
            style={{
              display: "flex",
              justifyContent: "flex-start",
              textAlign: "left",
              alignItems: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              height: "24.00px",
              width: "253.00px",
              position: "absolute",
              left: "223.00px",
              top: "1344.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(18, 18, 36, 0.50)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                lineHeight: "24.00px",
              }}
            >
              Job Experience Level
            </span>
          </span>
          <div
            id="_3362_5379__Menu_with_Text_field"
            style={{
              position: "absolute",
              height: "296.00px",
              width: "331.00px",
              left: "202.00px",
              top: "1320.00px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              padding: "8px 0px 0px 0px",
            }}
          >
            <select
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value)}
              style={{
                position: "absolute",
                background: "rgba(255, 255, 255, 1.00)",
                borderColor: "#65558fff",
                borderStyle: "solid",
                borderWidth: "3px",
                borderRadius: "4px",
                height: "56.00px",
                width: "331.00px",
                fontFamily: "Roboto",
                fontStyle: "normal",
                fontSize: "16.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "16px",
                outline: "none",
              }}
            >
              <option value="Beginner">Beginner</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          <div
            id="_3362_5362__Div__formInput_"
            style={{
              position: "absolute",
              height: "177.00px",
              width: "1083.00px",
              left: "186.00px",
              top: "1695.00px",
            }}
          >
            <span
              id="_3362_5364__Goals_"
              style={{
                display: "flex",
                justifyContent: "flex-start",
                textAlign: "left",
                alignItems: "center",
                height: "24.00px",
                width: "82.00px",
                position: "absolute",
                left: "0.00px",
                top: "4.98px",
              }}
            >
              <span
                style={{
                  whiteSpace: "nowrap",
                  background: "rgba(240, 65, 65, 1.00)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  textFillColor: "transparent",
                  WebkitTextFillColor: "transparent",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "500",
                  lineHeight: "24.00px",
                }}
              >
                Goals*
              </span>
            </span>
            <div
              id="_3368_5566__Input__password_"
              style={{
                position: "absolute",
                background: "rgba(255, 255, 255, 1.00)",
                borderColor: "#e7e7f1ff",
                borderStyle: "solid",
                borderWidth: "2.043895721435547px",
                borderRadius: "8px",
                height: "89.91px",
                width: "1078.91px",
                left: "0.00px",
                top: "42.00px",
              }}
            >
              <input
                type="text"
                value={goals}
                onChange={(e) => setGoals(e.target.value)}
                placeholder="Goals"
                style={{
                  position: "absolute",
                  background: "none",
                  border: "none",
                  height: "89.91px",
                  width: "1078.91px",
                  left: "0px",
                  top: "0px",
                  fontFamily: "Poppins",
                  fontStyle: "normal",
                  fontSize: "24.0px",
                  fontWeight: "400",
                  color: "rgba(18, 18, 36, 0.90)",
                  paddingLeft: "17px",
                  outline: "none",
                }}
              />
            </div>
          </div>

          <div
            id="_3362_5365__arrow_back"
            style={{
              position: "absolute",
              height: "24.00px",
              width: "24.00px",
              left: "41.00px",
              top: "121.00px",
            }}
          >
            <img
              id="I3362_5365_54616_25400__icon"
              src="assets/images/icon_22.svg"
              alt="icon"
              style={{
                position: "absolute",
                left: "calc(100% * 0.17)",
                top: "calc(100% * 0.17)",
              }}
            />
          </div>

          <div
            id="_3362_5367__Rectangle_1"
            style={{
              position: "absolute",
              background: "rgba(242, 255, 242, 1.00)",
              height: "89.00px",
              width: "1449.00px",
              left: "-9.00px",
              top: "-10.00px",
            }}
          ></div>

          <div
            id="_3362_5368__Frame_27"
            style={{
              position: "absolute",
              height: "50.00px",
              width: "345.65px",
              left: "calc(50% - 180.59px)",
              top: "17.00px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              flexWrap: "nowrap",
              gap: "20px",
            }}
          >
            <div
              id="_3362_5369__Frame_5"
              style={{
                position: "relative",
                height: "30.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "10px",
              }}
            >
              <span
                id="_3362_5370__Home"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  textAlign: "center",
                  alignItems: "flex-start",
                  height: "30.00px",
                  width: "58.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(40, 40, 40, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Inter",
                    fontStyle: "normal",
                    fontSize: "20.0px",
                    fontWeight: "700",
                    lineHeight: "150.00%",
                  }}
                >
                  Home
                </span>
              </span>
            </div>

            <div
              id="_3362_5371__Frame_4"
              style={{
                position: "relative",
                height: "30.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "10px",
              }}
            >
              <Link
              to="/Searchpage"
                id="_3362_5372__Jobs"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  textAlign: "center",
                  alignItems: "flex-start",
                  height: "30.00px",
                  width: "47.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(40, 40, 40, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Inter",
                    fontStyle: "normal",
                    fontSize: "20.0px",
                    fontWeight: "500",
                    lineHeight: "150.00%",
                  }}
                >
                  Jobs
                </span>
              </Link>
            </div>

            <div
              id="_3362_5373__Frame_3"
              style={{
                position: "relative",
                height: "30.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "10px",
              }}
            >
              <span
                id="_3362_5374__Categories"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  textAlign: "center",
                  alignItems: "flex-start",
                  height: "30.00px",
                  width: "105.00px",
                  position: "relative",
                }}
              >
                <span
                  style={{
                    whiteSpace: "nowrap",
                    background: "rgba(40, 40, 40, 1.00)",
                    backgroundClip: "text",
                    WebkitBackgroundClip: "text",
                    textFillColor: "transparent",
                    WebkitTextFillColor: "transparent",
                    fontFamily: "Inter",
                    fontStyle: "normal",
                    fontSize: "20.0px",
                    fontWeight: "500",
                    lineHeight: "150.00%",
                  }}
                >
                  Categories
                </span>
              </span>
            </div>

            <div
              id="_3362_5375__Frame_10"
              style={{
                position: "relative",
                height: "30.00px",
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "nowrap",
                gap: "10px",
                padding: "10px",
              }}
            ></div>
          </div>

          <span
            id="_3362_5377__Job"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "33.00px",
              width: "52.00px",
              position: "absolute",
              left: "30.00px",
              top: "24.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(0, 0, 0, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Martel",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "900",
                lineHeight: "150.00%",
              }}
            >
              Job 
            </span>
          </span>
          <span
            id="_3362_5378__Fiesta"
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              alignItems: "flex-start",
              height: "33.00px",
              width: "124.00px",
              position: "absolute",
              left: "76.00px",
              top: "19.00px",
            }}
          >
            <span
              style={{
                whiteSpace: "nowrap",
                background: "rgba(0, 0, 0, 1.00)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                textFillColor: "transparent",
                WebkitTextFillColor: "transparent",
                fontFamily: "Matura MT Script Capitals",
                fontStyle: "normal",
                fontSize: "32.0px",
                fontWeight: "400",
                lineHeight: "150.00%",
              }}
            >
              Fiesta
            </span>
          </span>

          <div
            id="_3362_5382__Input__password_"
            style={{
              position: "absolute",
              background: "rgba(255, 255, 255, 1.00)",
              borderColor: "#e7e7f1ff",
              borderStyle: "solid",
              borderWidth: "2.043895721435547px",
              borderRadius: "15px",
              height: "88.91px",
              width: "571.91px",
              left: "169.00px",
              top: "1155.00px",
            }}
          >
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Address"
              style={{
                position: "absolute",
                background: "none",
                border: "none",
                height: "88.91px",
                width: "571.91px",
                left: "0px",
                top: "0px",
                fontFamily: "Poppins",
                fontStyle: "normal",
                fontSize: "24.0px",
                fontWeight: "400",
                color: "rgba(18, 18, 36, 0.90)",
                paddingLeft: "17px",
                outline: "none",
              }}
            />
          </div>

          <div
            id="_3377_2684__Frame_53"
            style={{
              position: "absolute",
              overflow: "hidden",
              height: "40.00px",
              width: "40.00px",
              left: "1384.00px",
              top: "12.00px",
            }}
          >
            <img
              id="_3377_2685__Group_6"
              src="assets/images/group_6_5.svg"
              alt="Group_6"
              style={{
                position: "absolute",
                left: "calc(100% * 0.02)",
                top: "calc(100% * 0.02)",
              }}
            />
          </div>
        </form>
      </div>
    </>
  );
};
export default ViewApplicationsPage;