const PDFDocument = require('pdfkit');
const Resume = require('../models/Resume');
const { HfInference } = require('@huggingface/inference');
require('dotenv').config();
const { authenticate } = require('../middleware/auth'); // For user context

// Initialize Hugging Face with proper error handling
let hf;
try {
  if (!process.env.HUGGINGFACE_API_KEY) {
    throw new Error('HUGGINGFACE_API_KEY is not set in environment variables');
  }
  hf = new HfInference(process.env.HUGGINGFACE_API_KEY);
} catch (error) {
  console.error('Error initializing HuggingFace:', error);
}

// Generate PDF based on template
const generatePDF = async (resumeData) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const chunks = [];

      doc.on('data', chunk => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(25).text(resumeData.fullName, { align: 'center' });
      doc.moveDown();

      doc.fontSize(12).text(`Email: ${resumeData.email}`);
      doc.text(`Phone: ${resumeData.phone}`);
      doc.text(`Address: ${resumeData.address}`);
      doc.moveDown();

      doc.fontSize(16).text('Profile');
      doc.fontSize(12).text(resumeData.profile);
      doc.moveDown();

      doc.fontSize(16).text('Education');
      resumeData.education.forEach(edu => {
        const startDate = new Date(edu.startDate);
        const endDate = new Date(edu.endDate);
        doc.fontSize(12)
          .text(`${edu.institution} - ${edu.degree}`)
          .text(`${startDate.toLocaleDateString()} to ${endDate.toLocaleDateString()}`);
        doc.moveDown();
      });

      doc.fontSize(16).text('Work Experience');
      resumeData.workExperience.forEach(exp => {
        const startDate = new Date(exp.startDate);
        const endDate = new Date(exp.endDate);
        doc.fontSize(12)
          .text(`${exp.companyName} - ${exp.jobTitle}`)
          .text(`${startDate.toLocaleDateString()} to ${endDate.toLocaleDateString()}`)
          .text(exp.experience);
        doc.moveDown();
      });

      doc.fontSize(16).text('Skills');
      doc.fontSize(12).text(resumeData.skills.join(', '));
      doc.moveDown();

      doc.fontSize(16).text('Hobbies');
      doc.fontSize(12).text(resumeData.hobbies.join(', '));

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
};

// Generate resume
exports.generateResume = async (req, res) => {
  try {
    const userId = req.user.userId; // From authenticate middleware
    const resumeData = { ...req.body, userId }; // Add userId to resume data

    // Parse date strings to Date objects
    resumeData.education = resumeData.education.map(edu => ({
      ...edu,
      startDate: new Date(edu.startDate),
      endDate: new Date(edu.endDate)
    }));
    resumeData.workExperience = resumeData.workExperience.map(exp => ({
      ...exp,
      startDate: new Date(exp.startDate),
      endDate: new Date(exp.endDate)
    }));
    if (resumeData.dob) {
      resumeData.dob = new Date(resumeData.dob);
    }

    const resume = new Resume(resumeData);

    const validationError = resume.validateSync();
    if (validationError) {
      return res.status(400).json({
        success: false,
        error: validationError.message
      });
    }

    await resume.save();
    console.log('Resume saved to database:', resume._id);

    const pdfBuffer = await generatePDF(resumeData);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${resumeData.fullName}_resume.pdf"`);
    res.send(pdfBuffer);
  } catch (error) {
    console.error('Error generating resume:', error);
    res.status(500).json({
      success: false,
      error: 'Error generating resume: ' + error.message
    });
  }
};

// Get all resumes (restricted to user)
exports.getAllResumes = async (req, res) => {
  try {
    const resumes = await Resume.find({ userId: req.user.userId });
    res.status(200).json({
      success: true,
      data: resumes
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error fetching resumes'
    });
  }
};

// Get single resume (restricted to user)
exports.getResume = async (req, res) => {
  try {
    const resume = await Resume.findOne({ _id: req.params.id, userId: req.user.userId });
    if (!resume) {
      return res.status(404).json({
        success: false,
        error: 'Resume not found'
      });
    }
    res.status(200).json({
      success: true,
      data: resume
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error fetching resume'
    });
  }
};

// Enhance profile using AI
exports.enhanceProfile = async (req, res) => {
  try {
    const { profile } = req.body;

    if (!profile) {
      return res.status(400).json({
        success: false,
        error: 'Profile text is required'
      });
    }

    if (!hf) {
      return res.status(500).json({
        success: false,
        error: 'AI service is not properly configured. Please check your API key.'
      });
    }

    // Try models in order, starting with a reliable one
    const models = ['facebook/bart-large-cnn', 'gpt2', 'distilgpt2'];
    let enhancedProfile = '';

    for (const model of models) {
      try {
        const prompt = `Task: Improve this resume profile to be more professional while keeping it clear and easy to understand.
        Guidelines:
        - Keep the original meaning and intent
        - Use simple, professional language
        - Make it more impactful but not more complex
        - Keep it concise (2-3 sentences)
        - Focus on achievements and skills
        - Avoid jargon and complex terms
        
        Original: "${profile}"
        
        Improved version:`;

        const result = await hf.textGeneration({
          model: model,
          inputs: prompt,
          parameters: {
            max_new_tokens: 100,
            temperature: 0.7,
            top_p: 0.9,
            repetition_penalty: 1.2,
            do_sample: true,
            return_full_text: false
          }
        });

        enhancedProfile = result.generated_text
          .trim()
          .replace(/^["']|["']$/g, '')
          .replace(/Improved version:/i, '')
          .replace(/^Original:.*$/im, '')
          .trim();

        if (enhancedProfile.length >= 10) break; // Use this result if valid
      } catch (error) {
        console.warn(`Failed to use model ${model}: ${error.message}`);
        if (model === models[models.length - 1]) {
          throw error; // Throw the last error if all models fail
        }
      }
    }

    if (enhancedProfile.length < 10) {
      enhancedProfile = enhanceText(profile);
    }

    res.status(200).json({
      success: true,
      data: {
        originalProfile: profile,
        enhancedProfile: enhancedProfile
      }
    });
  } catch (error) {
    console.error('Error enhancing profile:', error);
    res.status(500).json({
      success: false,
      error: `Error enhancing profile: ${error.message}. Please ensure your Hugging Face API key has access to the required models or try a different model. Check https://hf.co/settings for configuration.`
    });
  }
};

// Helper function to enhance text
function enhanceText(text) {
  let enhanced = text.trim().replace(/\s+/g, ' ');
  const introductions = ['Experienced professional with', 'Skilled professional specializing in', 'Results-driven professional with expertise in'];
  const actionVerbs = ['developed', 'led', 'created', 'analyzed'];
  const achievements = ['with measurable results', 'with proven success'];

  if (!enhanced.toLowerCase().includes(actionVerbs.some(v => enhanced.toLowerCase().includes(v)))) {
    const randomVerb = actionVerbs[Math.floor(Math.random() * actionVerbs.length)];
    enhanced = `${randomVerb.charAt(0).toUpperCase() + randomVerb.slice(1)}ed ${enhanced}`;
  }

  if (!/\d+/.test(enhanced)) {
    const randomAchievement = achievements[Math.floor(Math.random() * achievements.length)];
    enhanced = enhanced.replace(/\./g, ` ${randomAchievement}.`);
  }

  if (!introductions.some(intro => enhanced.toLowerCase().includes(intro.toLowerCase()))) {
    const randomIntro = introductions[Math.floor(Math.random() * introductions.length)];
    enhanced = `${randomIntro} ${enhanced}`;
  }

  return enhanced.replace(/\s+/g, ' ').replace(/\.+/g, '.').trim() + '.';
}