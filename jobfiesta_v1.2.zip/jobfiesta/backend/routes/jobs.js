const express = require('express');
const router = express.Router();
const Job = require('../models/Job');
const Application = require('../models/Application');
const { authenticate, restrictTo } = require('../middleware/auth');

// Create Job (Recruiter only)
router.post('/', authenticate, restrictTo('recruiter'), async (req, res) => {
  try {
    const {
      title, description, skillsRequired, location, salary,
      roleType, companyName, workEnvironment, applicationProcess,
      maritalStatus, gender, jobType, jobBenefits, applicationDeadline,
      experienceLevel, termsAndConditions
    } = req.body;
    const job = new Job({
      title, description, skillsRequired, location, salary,
      roleType, companyName, workEnvironment, applicationProcess,
      maritalStatus, gender, jobType, jobBenefits, applicationDeadline,
      experienceLevel, termsAndConditions,
      postedBy: req.user.userId
    });
    await job.save();
    res.status(201).json({ message: 'Job posted successfully', jobId: job._id });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Search Jobs
router.get('/', async (req, res) => {
  try {
    const { skills, location, keyword } = req.query;
    const query = {};
    if (skills) query.skillsRequired = { $in: skills.split(',') };
    if (location) query.location = new RegExp(location, 'i');
    if (keyword) query.title = new RegExp(keyword, 'i');
    const jobs = await Job.find(query).populate('postedBy', 'companyName');
    res.json(jobs);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get Job by ID
router.get('/:id', async (req, res) => {
  try {
    const job = await Job.findById(req.params.id).populate('postedBy', 'companyName');
    if (!job) return res.status(404).json({ message: 'Job not found' });
    res.json(job);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get Applications for a Job (Recruiter only)
router.get('/:id/applications', authenticate, restrictTo('recruiter'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job || job.postedBy.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }
    const applications = await Application.find({ jobId: req.params.id })
      .populate('jobSeekerId', 'name skills');
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;